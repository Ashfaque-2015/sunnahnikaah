# SunnahNikaah

a [Sails](http://sailsjs.org) application

Install:

1. Clone or Pull repository with latest change

2. Go to root directory where you have cloned/pulled latest changes

3. Run command "sudo npm install"

4. Run command "bower install"

Images source symlink Command:

ln -s /Users/apple/www/SunnahNikaah/uploads /Users/apple/www/SunnahNikaah/.tmp/public


5. Need to update geoip database
   go to node_modules/geoip-lite
   and run the command
   "npm run-script updatedb"

   In detail - https://github.com/bluesmoon/node-geoip


How to install eJabberd-Xmpp server
====================================
1. go to the link
https://www.digitalocean.com/community/tutorials/how-to-install-ejabberd-xmpp-server-on-ubuntu

2. replace the ejabberd.cfg file as
/bin/ejabberd.cfg to etc/ejabberd/ejabberd.cfg

3. check the line 496 as
{access, register, [{allow, all}]}.

it should be allow instead of deny, for allowing registration user outside ( user registration allow from website)

4. Create a user with password
   ejabberdctl register ashraf sunnahnikaah.com Hkj38djf

5. admin user creation

   %% Admin user
   {acl, admin, {user, "ashraf", "sunnahnikaah.com"}}.
   %% password Hkj38djf
   %% Hostname
   {hosts, ["localhost","45.55.203.43","sunnahnikaah.com"]}.

   here ashraf is the admin user
