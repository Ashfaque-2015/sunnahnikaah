/**
 * BlogTagController
 *
 * @description :: Server-side logic for managing Blogtags
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {

};

