/**
 * FIqhTagController
 *
 * @description :: Server-side logic for managing Fiqhtags
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {

};

