/**
 * RosterContactsController
 *
 * @description :: Server-side logic for managing Rostercontacts
 * @help        :: See http://links.sailsjs.org/docs/controllers
 */

module.exports = {
	
};

