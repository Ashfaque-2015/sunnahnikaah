/**
 * VideoTagController
 *
 * @description :: Server-side logic for managing Videotags
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {

};
