/**
 * AuthorController
 *
 * @description :: Server-side logic for managing authors
 * @help        :: See http://links.sailsjs.org/docs/controllers
 */

module.exports = {
	
};

