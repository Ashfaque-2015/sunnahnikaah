// Configuring $translateProvider
app.config(['$translateProvider', function ($translateProvider) {

  $translateProvider.translations('bn_BN', {
    'HEADLINE': 'ngTranslate',
    'SUB_HEADLINE': 'Internationalisierung für deine Angular Apps!',
    'AUTHOR_NAME': 'Pascal Precht',
    'GITHUB_LINK_TEXT': 'Code auf GitHub ansehen',
    'GETTING_STARTED_HEADLINE': 'Starten',
    'HEADLINE_FILTER': 'ngTranslate::translateFilter',
    'HEADLINE_USAGE': 'Benutzung:',
    'HEADLINE_FILTER_DYN_VALUES': 'Übersetzungen mit dynamischen Werten',
    'INFO_TEXT_TRANSLATE_FILTER': 'ngTranslate bietet einen filter der wie folgt verwendet werden kann:',
    'INFO_TEXT_TRANSLATE_FILTER_2': 'Manchmal haben Übersetzungen dynamische Werte. ngTranslate bietet mehrere Wege dynamische Werte an eine Übersetzung zu übergeben.',
    'INFO_TEXT_TRANSLATE_FILTER_3': 'Zuerst muss eine Übersetzung wissen, dass sie dynamische Werte haben kann. Dazu kann einfach die bekannte Interpolation-Directive verwendet werden:',
    'INFO_TEXT_TRANSLATE_FILTER_4': '"value" ist nun ein Identifier dem Werte zugewiesen werden können. Es gibt zwei Wegen, Werte durch einen Filter an einen Identifier zu geben. Zum einen sein String Ausdruck in Form eines Objektliterals, oder ein Objekthash am aktuellen Scope.',
    'HEADLINE_DIRECTIVE': 'ngTranslate::translateDirective',
    'INFO_TEXT_TRANSLATE_DIRECTIVE': 'Zu viele Filter können deine Angular App stark verlangsamen. In diesem Fall wäre es gut eine Direktive anstatt einen Filter zu verwenden. ngTranslate kommt mit einer "translate" Direktive, die in vielen verschiedenen Wegen verwendet werden kann:',
    'HEADLINE_DIRECTIVE_DYN_VALUES': 'Mit dynamischen Werten umgehen',
    'INFO_TEXT_TRANSLATE_DIRECTIVE_2': 'Um Werte durch die "translate" Direktive zu übergeben, wird das "values" Attribute verwendet. Auch hier kann entweder ein String Ausdruck oder eine Stringinterpolation verwendet werden:',
    'INFO_TEXT_TRANSLATE_DIRECTIVE_3': 'Das funktioniert in allen Kombinationen.'
  });

  //$translateProvider.use('de_DE'); //enable it if you want to set this as default
  //$translateProvider.rememberLanguage(true);
}]);
