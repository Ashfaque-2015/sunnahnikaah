/**
 * Created by rbn-imac on 10/11/15.
 */
angular.module('filters', []).filter('filterFav', function() {
  return function(input) {

    console.log(input);

    //return input ? '\u2713' : '\u2718';
    return false;
  };
});
