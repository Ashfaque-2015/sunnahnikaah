var app = angular.module('app',
  [
    '720kb.socialshare',
    'filters',
    'angularUtils.directives.dirPagination',
    'dcbImgFallback',
    'angular-loading-bar',
    'ngDialog',
    'ui.router',
    'pascalprecht.translate',
    'angularFileUpload',
    'ui.bootstrap',
    'ui.grid',
    'ui.grid.edit',
    'youtube-embed',
    'ngAudio',
    'decipher.tags',
    'ui.bootstrap.typeahead',
    'ui.bootstrap.tpls',
    'ui.bootstrap.transition',
    'ngAnimate',
    'toastr',
    'slick'
  ])
  .config(function(toastrConfig) {
    angular.extend(toastrConfig, {
      autoDismiss: false,
      containerId: 'toast-container',
      maxOpened: 0,
      newestOnTop: true,
      positionClass: 'toast-bottom-right',
      preventDuplicates: true,
      preventOpenDuplicates: true,
      target: 'body'
    });
  })
  .run(function ($rootScope, $state, Auth, $window) {
    $rootScope.hideSidebar = false;
    $rootScope.bodyclass = "guest-body";

    $rootScope.online = navigator.onLine;
    $window.addEventListener("offline", function () {
      $rootScope.$apply(function() {
        $rootScope.online = false;
      });
    }, false);
    $window.addEventListener("online", function () {
      $rootScope.$apply(function() {
        $rootScope.online = true;
      });
    }, false);

    $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {

      $rootScope.hideSidebar = false;

      if (!Auth.authorize(toState.data.access)) {
        event.preventDefault();
        $state.go('base.login');
      }

      //state user.messages router will be always redirected to base.user.messages.detail with last user chat
      if (toState.name == 'base.user.messages') {
        event.preventDefault();
        $state.go('base.user.messages.detail');
      }
    });

  });
