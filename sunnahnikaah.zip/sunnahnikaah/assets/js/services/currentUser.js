angular.module('app')
  .factory('CurrentUser', ['$rootScope', '$state', 'LocalService', function($rootScope,$state, LocalService) {
    return {
      user: function() {
        if (LocalService.get('auth_token')) {
          return angular.fromJson(LocalService.get('auth_token')).user;
        } else {
          return {};
        }
      },
      setBodyClass : function(){
        if($state.current.data.access == 0)
          $rootScope.bodyclass = "guest-body";
        else if($state.current.data.access == 1)
          $rootScope.bodyclass = "user-body";
        else if($state.current.data.access == 2)
          $rootScope.bodyclass = "admin-body";
      }
    };
  }]);
