var GlobalChat = null;
angular.module('app')
  .service('Chat', ['LocalService', 'Auth', 'CurrentUser', '$http', function(LocalService,Auth,CurrentUser,$http) {
    var Gab;
    Gab = {
      connection: null,
      handlers: [],
      handlersObj: {},
      BOSH_SERVICE : 'http://sunnahnikaah.com:5280/http-bind',
      //BOSH_SERVICE: 'http://sunnahnikaah.com:5280/xmpp-httpbind',
      //BOSH_SERVICE : 'http://bosh.metajack.im:5280/xmpp-httpbind',
      //BOSH_SERVICE : 'http://amartaxi.com:5280/http-bind',

      contacts: [],
      contact_list_area: "",

      jid_to_id: function (jid) {
        return Strophe.getBareJidFromJid(jid)
          .replace(/@/g, "-")
          .replace(/\./g, "-");
      },
      on_roster: function (iq) {
        //console.log("iq:onroster");
        $(iq).find('item').each(function () {
          var jid = $(this).attr('jid');
          var name = $(this).attr('name') || jid;

          // transform jid into an id
          var jid_id = Gab.jid_to_id(jid);

          //console.log("on_roster",jid);
          //console.log(iq);

          var contact = $("<li id='" + jid_id + "'>" +
          "<div class='roster-contact offline'>" +
          "<div class='roster-name'>" +
          name +
          "</div><div class='roster-jid'>" +
          jid +
          "</div></div></li>");

          Gab.insert_contact(contact);

          //adding to contact list
          Gab.add_new_contact(jid, name);
        });

        // set up presence handler and send initial presence
        if(!Gab.handlersObj.hasOwnProperty('p_chat_on_presence') ){
          var onmsghandler = Gab.connection.addHandler(Gab.on_presence, null, "presence");
          if(onmsghandler){
            Gab.handlers.push({p_chat_on_presence:onmsghandler});
            Gab.handlersObj.p_chat_on_presence = onmsghandler;
          }
        }
        Gab.connection.send($pres({"priority": "10"}));
      },

      pending_subscriber: null,

      on_presence: function (presence) {
        //console.log('on presence');
        //console.log(presence);

        var ptype = $(presence).attr('type');
        var from = $(presence).attr('from');
        var jid_id = Gab.jid_to_id(from);

        if (ptype === 'subscribe') {
          // populate pending_subscriber, the approve-jid span, and
          // open the dialog
          Gab.pending_subscriber = from;
          $('#approve-jid').text(Strophe.getBareJidFromJid(from));
          $('#approve_dialog').dialog('open');
        }
        else if (ptype !== 'error') {
          var contact = $('#roster-area li#' + jid_id + ' .roster-contact')
            .removeClass("online")
            .removeClass("away")
            .removeClass("offline");
          if (ptype === 'unavailable') {
            contact.addClass("offline");
          } else {
            var show = $(presence).find("show").text();
            if (show === "" || show === "chat") {
              contact.addClass("online");
            } else {
              contact.addClass("away");
            }
          }

          var li = contact.parent();
          li.remove();
          Gab.insert_contact(li);
        }

        // reset addressing for user since their presence changed
        //var jid_id = Gab.jid_to_id(from);
        //$('#chat-' + jid_id).data('jid', Strophe.getBareJidFromJid(from));

        return true;
      },

      on_roster_changed: function (iq) {
        console.log("iq:on roster change");
        console.log(iq);
        $(iq).find('item').each(function () {
          var sub = $(this).attr('subscription');
          var jid = $(this).attr('jid');
          var name = $(this).attr('name') || jid;
          var jid_id = Gab.jid_to_id(jid);

          console.log("on_roster_changed", jid);

          if (sub === 'remove') {
            // contact is being removed
            $('#' + jid_id).remove();
          } else {
            // contact is being added or modified
            var contact_html = "<li id='" + jid_id + "'>" +
              "<div class='" +
              ($('#' + jid_id).attr('class') || "roster-contact offline") +
              "'>" +
              "<div class='roster-name'>" +
              name +
              "</div><div class='roster-jid'>" +
              jid +
              "</div></div></li>";

            if ($('#' + jid_id).length > 0) {
              $('#' + jid_id).replaceWith(contact_html);
            }
            else {
              Gab.insert_contact($(contact_html));
            }

            //adding to contact list
            Gab.add_new_contact(jid, name);

          }
        });

        return true;
      },

      //updating message on mongodb

      //received message will be updated in mongodb and the status will as read
      on_message: function (message) {
        //console.log("receive on message",message);
        //var full_jid = $(message).attr('from');
        //var from_jid = Strophe.getBareJidFromJid(full_jid);
        ////var jid_id = Gab.jid_to_id(from_jid);
        //var me_jid = Strophe.getBareJidFromJid($(message).attr('to'));
        //
        //
        ////place the calculated height for chat area
        //var body = $(message).find("html > body");
        //var recMessages = [];
        //
        //if (body.length === 0) {
        //  console.log("body.lenth === 0");
        //  body = $(message).find('body');
        //  if (body.length > 0) {
        //    body = body.text();
        //    recMessages.push(body);
        //  }
        //  else {
        //    body = null;
        //  }
        //}
        //else {
        //  body = body.contents();
        //  //var span = $("<span></span>");
        //  body.each(function () {
        //    if (document.importNode) {
        //      //$(document.importNode(this, true)).appendTo(span);
        //      recMessages.push(this);
        //      recMessages.push("ash");
        //    }
        //    else {
        //      // IE workaround
        //      span.append(this.xml);
        //      recMessages.push(this.xml);
        //      recMessages.push("dash");
        //    }
        //  });
        //
        //  //body = span;
        //}
        //
        //console.log("recMessages.length",recMessages.length);
        //
        //if (recMessages.length) {
        //  var msgThread = $(message).find("thread");
        //  var msgidText = $(message).find("msgid");
        //  var threadId = -1,msgid=-1;
        //
        //  console.log(msgThread,msgidText);
        //  console.log(msgThread.text(), msgidText.text());
        //
        //  //login imposed, only those chat message will be saved which will be under sunnahnikaah web or mobile app
        //  if(msgThread.text() && msgidText.text()){
        //    threadId = msgThread.text();
        //    msgid= msgidText.text();
        //
        //    console.log('threadId:',threadId,'msgid:',msgid);
        //
        //    if(threadId!= -1 && msgid != -1){
        //      console.log("ekhaneo aise");
        //      Gab.update_message_archive(recMessages, from_jid, me_jid,threadId,"receivemsg",msgid,Gab.update_message_archive_cb);
        //    }
        //  }
        //}

        return true;
      },

      update_message_archive: function (messages, from, me, threadId, msgType, msgId, from_jid_msg_viewing ,sendMessage_cb) {
        //console.log('threadId',threadId);
        if(msgType=="sendmsg")
          messages_jids = {"messages": messages, "from_jid": from, "me_jid": me, "thread": threadId, "msgType":msgType ,"msgId":msgId,"msgViewing":from_jid_msg_viewing};
        else
          messages_jids = {"from_jid": from, "me_jid": me, "thread": threadId, "msgType":msgType , "msgId":msgId, "msgViewing":from_jid_msg_viewing};

        console.log('updating messages_jids',messages_jids);
        $http.post("/message/updatemessage", messages_jids)
          .success(function (data, status, headers, config) {
            //if(msgType=="sendmsg")
            //  console.log("successfully created", data);
            //else
            //  console.log("successfully update", data);
            sendMessage_cb(data,messages);
            return data;
          })
          .error(function (data, status, headers, config) {
            console.log("failed to update", data);
            return false;
          });
      },

      //on_notification_message: function (message) {
      //  //console.log(message);
      //  var full_jid = $(message).attr('from');
      //  var jid = Strophe.getBareJidFromJid(full_jid);
      //  var jid_id = Gab.jid_to_id(jid);
      //
      //  var body = $(message).find("html > body");
      //
      //  if (body.length === 0) {
      //
      //    body = $(message).find('body');
      //    if (body.length > 0) {
      //      body = body.text();
      //      //console.log("body contents",body);
      //    } else {
      //      body = null;
      //    }
      //  } else {
      //    body = body.contents();
      //    //console.log("body contents",body);
      //    var span = $("<span></span>");
      //    body.each(function () {
      //      if (document.importNode) {
      //        $(document.importNode(this, true)).appendTo(span);
      //      } else {
      //        // IE workaround
      //        span.append(this.xml);
      //      }
      //    });
      //
      //    body = span;
      //  }
      //
      //
      //  return true;
      //},

      presence_value: function (elem) {
        //console.log("presensce value :",elem);

        if (elem.hasClass('online')) {
          return 2;
        } else if (elem.hasClass('away')) {
          return 1;
        }

        return 0;
      },

      insert_contact: function (elem) {
        //console.log("insert_contact",elem);
        var jid = elem.find('.roster-jid').text();
        var pres = Gab.presence_value(elem.find('.roster-contact'));

        var contacts = $('#roster-area li');

        //console.log("insert_contact",jid);

        //roster contact shuffled according to presence value
        if (contacts.length > 0) {
          var inserted = false;
          contacts.each(function () {
            var cmp_pres = Gab.presence_value($(this).find('.roster-contact'));
            var cmp_jid = $(this).find('.roster-jid').text();

            if (pres > cmp_pres) {
              $(this).before(elem);
              inserted = true;
              return false;
            } else if (pres === cmp_pres) {
              if (jid < cmp_jid) {
                $(this).before(elem);
                inserted = true;
                return false;
              }
            }
          });

          if (!inserted) {
            $('#roster-area ul').append(elem);
          }
        } else {
          $('#roster-area ul').append(elem);
          //adding all contacts at array
          //Gab.add_new_contact(jid,name);
        }
      },

      //adding all roster contact
      add_new_contact: function (jid, name) {
        //Gab.contacts.push({"jid":jid,"name":name});
        //console.log(Gab.contacts);
      },

      //this function will be implemented later
      //this function will polulated loggedin users contact list at roster area
      loadRoster: function (roster_area) {
        Gab.contact_list_area = roster_area;
      },

      is_already_loggedin: function () {

        if (this.connection)
          return this.connection.connected;
        else
          return false;

        //var token;
        //if (LocalService.get('auth_chat_token')) {
        //  token = angular.fromJson(LocalService.get('auth_chat_token'));
        //  return token;
        //}
        //return false;
      },

      getChatToken: function () {
        var token;
        if (LocalService.get('auth_chat_token')) {
          token = angular.fromJson(LocalService.get('auth_chat_token'));
          return token;
        }
        return false;
      },

      connect_me_now: function (userJid, userPass,autoDisconnectChatServerNotification_cb) {
        //console.log("new connecting");

        var conn = new Strophe.Connection(
          Gab.BOSH_SERVICE);
        Gab.connection = conn;
        //'http://sunnahnikaah.com:5280/http-bind');
        //'http://bosh.metajack.im:5280/xmpp-httpbind');
        //'https://conversejs.org/http-bind');
        //'http://128.199.125.77:5505/http-bind');//our bosh server running with
        //console.log("Connection object created");
        //console.log(conn);

        conn.rawInput = Gab.rawInput;
        conn.rawOutput = Gab.rawOutput;

        //console.log("aisilo ekhane userJid, userPass",userJid, userPass, conn);

        conn.connect(userJid, userPass, function (status) {
          if (status === Strophe.Status.CONNECTED) {
            //console.log("login hoyechhe ejabberd server e",conn);
            Gab.connection = conn;
            $(document).trigger('connected');

            conn.roster.get(Gab.onGetRoster, 0);

            //getting necessary info from current session and set at local storage
            LocalService.set('auth_chat_token', JSON.stringify(
              {
                'sid': Gab.connection._proto.sid,
                'rid': Gab.connection._proto.rid,
                'jid': Gab.connection.jid,
                'pass': Gab.connection.pass,
                'authcid': Gab.connection.authcid,
                'authzid': Gab.connection.authzid,
                'authenticated': Gab.connection.authenticated
              }
            ));

            $('.chat-login-form').hide();
            $('.chat-logout-form').show();
          }
          else if (status === Strophe.Status.DISCONNECTED) {
            console.log("Strophe.Status.DISCONNECTED");
            autoDisconnectChatServerNotification_cb();
            $(document).trigger('disconnected');
          }
        });



      },
      get_archive_data: function (threadId,mlimit,mskip,get_archive_data_cb) {
        //console.log(jid);
        //Gab.connection.archive.listCollections(jid, null, function (collections, responseRsm) {
        //  console.log("archive collections", collections);
        //  console.log("archive rm", responseRsm);
        //
        //  // // Now you can iterate over the collections. Here we retrieve
        //  // // all the messages contained in each collection.
        //  // collections.forEach(function(collection) {
        //  //     collection.retrieveMessages(function(null, function(messages) {
        //  //         // Your callback here to process all the messages in this collection.
        //  //         console.log(messages);
        //  //     });
        //  // });
        //});
        $http.post('/message/get20Message',{'threadId':threadId,'limit':mlimit,'skip':mskip})
          .success(function(data, status, headers, config){
            //console.log(data);
            get_archive_data_cb(data);
          })
          .error(function(data, status, headers, config){
            console.log("message archive result failed");
            get_archive_data_cb([]);
          });
      },
      onGetRoster: function (items) {
        if (!items || items.length == 0)
          return;
        Gab.contacts = items;
      },

      //not successfully working, will see later
      attach_me_with_previous_session: function (userJid, userSid, userRid) {
        //userRid = userRid;
        console.log("attaching");
        var conn = new Strophe.Connection(Gab.BOSH_SERVICE);
        //'http://sunnahnikaah.com:5280/http-bind');

        conn.rawInput = Gab.rawInput;
        conn.rawOutput = Gab.rawOutput;

        //Gab.connection.attach(userJid,userSid,userRid);
        console.log('Strophe');
        console.log(conn); //3816415660 //3119338771
        console.log(userJid, userSid, userRid);
        Gab.connection = conn.attach(userJid, userSid, userRid, function (status) {
          console.log(status);
          if (status === Strophe.Status.CONNECTED) {
            $(document).trigger('connected');

            //getting necessary info from current session and set at local storage
            console.log("ashche ki ekhane : conn.attach");
            LocalService.set('auth_chat_token', JSON.stringify(
              {
                'sid': Gab.connection._proto.sid,
                'rid': Gab.connection._proto.rid,
                'jid': Gab.connection.jid,
                'pass': Gab.connection.pass,
                'authcid': Gab.connection.authcid,
                'authzid': Gab.connection.authzid,
                'authenticated': Gab.connection.authenticated
              }
            ));

            $('.chat-login-form').hide();
            $('.chat-logout-form').show();

          }
          else if (status === Strophe.Status.DISCONNECTED) {
            $(document).trigger('disconnected');
            Strophe.getSID();
          }
        });
      },

      register_me: function (userId, jusername, jpassword, registerCallback,register_cb_param) {
        console.log("registration is starting userId,jusername,jpassword",userId,jusername,jpassword);
        var connection = new Strophe.Connection(
          //"http://bosh.metajack.im:5280/xmpp-httpbind");
          //"http://localhost/http-bind");
          Gab.BOSH_SERVICE);
        //'http://sunnahnikaah.com:5280/http-bind');
//        'http://128.199.125.77:5505/http-bind');
        console.log(connection);

        var registrationCallback = function (status) {
          if (status === Strophe.Status.REGISTER) {
            console.log('Strophe.Status.REGISTER');
            // fill out the fields
            connection.register.fields.username = jusername;
            connection.register.fields.password = jpassword;
            // calling submit will continue the registration process
            connection.register.submit();
          }
          else if (status === Strophe.Status.REGISTERED) {
            console.log("Strophe.Status.REGISTERED");

            //comment below section cause now we are not now auto login
            //// calling login will authenticate the registered JID.
            //connection.authenticate();
            ////getting necessary info from current session and set at local storage
            //LocalService.set('auth_chat_token', JSON.stringify(
            //  {
            //    'sid': Gab.connection._proto.sid,
            //    'rid': Gab.connection._proto.rid,
            //    'jid': Gab.connection.jid,
            //    'pass': Gab.connection.pass,
            //    'authcid': Gab.connection.authcid,
            //    'authzid': Gab.connection.authzid,
            //    'authenticated': Gab.connection.authenticated
            //  }
            //));
            registerCallback(userId, jusername + "@sunnahnikaah.com", jpassword,register_cb_param);
          }
          else if (status === Strophe.Status.CONFLICT) {
            console.log("Contact already existed!");
          }
          else if (status === Strophe.Status.NOTACCEPTABLE) {
            console.log("Registration form not properly filled out.")
          }
          else if (status === Strophe.Status.REGIFAIL) {
            console.log("The Server does not support In-Band Registration")
          }
          else if (status === Strophe.Status.CONNECTED) {
            console.log('Strophe.Status.CONNECTED');
            //this is comment cause now we are not auto login
            //registerCallback(userId, jusername + "@sunnahnikaah.com", jpassword,register_cb_param);
          }
          else {
            // Do other stuff
          }
        };

        connection.register.connect("sunnahnikaah.com", registrationCallback, 60, 1);


        Gab.connection = connection;
      },

      disconnect_me: function () {
        Gab.connection.disconnect();
        Gab.connection = null;
        Gab.handlers = [];
        Gab.handlersObj = {};
      },

      rawInput: function (data) {
        //console.log('RECV: ' + data);
      },

      rawOutput: function (data) {
        //console.log("row output");
        //console.log('SENT: ' + data);

        //this code was written for auto attach previous ejabberd login
        //but as we still unable to fix the attach issue so till then this code should be commented
        //if (Gab.connection) {
        //  LocalService.unset('auth_chat_token');
        //  //console.log("sid rid",Gab.connection._proto.sid,Gab.connection._proto.rid);
        //  LocalService.set('auth_chat_token', JSON.stringify(
        //    {
        //      'sid': Gab.connection._proto.sid,
        //      'rid': Gab.connection._proto.rid,
        //      'jid': Gab.connection.jid,
        //      'pass': Gab.connection.pass,
        //      'authcid': Gab.connection.authcid,
        //      'authzid': Gab.connection.authzid,
        //      'authenticated': Gab.connection.authenticated
        //    }
        //  ));
        //}
      }

    };


    $( window ).unload(function() {

      LocalService.unset('auth_chat_token');
      LocalService.set('auth_chat_token', JSON.stringify(
        {
          'authcid':Gab.connection.authcid,
          'authzid':Gab.connection.authzid,
          'authenticated':Gab.connection.authenticated,
          'jid':Gab.connection.jid,
          'pass':Gab.connection.pass,
          'sid':Gab.connection._proto.sid,
          'rid':Gab.connection._proto.rid
        }
      ));

      Gab.disconnect_me();
      return true;
    });

    var Chat_Token = Gab.getChatToken();

    if(Auth.isAuthenticated() && Chat_Token){
      //console.log(Gab);
      //console.log("Chat token ",Chat_Token);
      //Chat.attach_me_with_previous_session(Chat_Token.jid,Chat_Token.sid,Chat_Token.rid);
      Gab.connect_me_now(CurrentUser.user().jid,CurrentUser.user().jpassword);
    }
    else if(Auth.isAuthenticated() && !Gab.is_already_loggedin()){
      if(CurrentUser.user().hasOwnProperty("jid") && CurrentUser.user().jid != "" && CurrentUser.user().hasOwnProperty("jpassword") && CurrentUser.user().jpassword != "") {
        Gab.connect_me_now(CurrentUser.user().jid, CurrentUser.user().jpassword);
      }
    }



    //initially checking and if user refresh the page and the user already loggedin then it will automatically login with xmpp server
    //var currentLoggedInUser = Gab.is_already_loggedin();
    //if(currentLoggedInUser){
    // Gab.connect_me_now(currentLoggedInUser.jid,currentLoggedInUser.pass);
    //}

    //$(document).bind('connect', function (ev, data) {
    //  Gab.connect_me_now(data.jid,data.password);
    //});

    //var currentLoggedInUser = Gab.is_already_loggedin();
    //if(currentLoggedInUser){
    //  Gab.attach_me_with_previous_session(currentLoggedInUser.jid,currentLoggedInUser.sid,currentLoggedInUser.rid);
    //  //Gab.connect_me_now(currentLoggedInUser.jid,currentLoggedInUser.pass);
    //  $('.chat-login-form').hide();
    //  $('.chat-logout-form').show();
    //}

    $(document).bind('connected', function () {
      var iq = $iq({type: 'get'}).c('query', {xmlns: 'jabber:iq:roster'});
      Gab.connection.sendIQ(iq, Gab.on_roster);

      if(!Gab.handlersObj.hasOwnProperty('iq_chat_on_roster_changed') ){
        var onmsghandler = Gab.connection.addHandler(Gab.on_roster_changed,"jabber:iq:roster", "iq", "set");
        if(onmsghandler){
          Gab.handlers.push({iq_chat_on_roster_changed:onmsghandler});
          Gab.handlersObj.iq_chat_on_roster_changed = onmsghandler;
        }
      }

      if(!Gab.handlersObj.hasOwnProperty('m_chat_on_message') ){
        var onmsghandler = Gab.connection.addHandler(Gab.on_message, null, "message", "chat");
        if(onmsghandler){
          Gab.handlers.push({m_chat_on_message:onmsghandler});
          Gab.handlersObj.m_chat_on_message = onmsghandler;
        }
      }


    });

    $(document).bind('disconnected', function () {
      Gab.connection = null;
      Gab.pending_subscriber = null;

      //$('#roster-area ul').empty();
      //$('#chat-area ul').empty();
      //$('#chat-area div').remove();
      //
      //$('#login_dialog').dialog('open');
    });

    $(document).bind('contact_added', function (ev, data) {
      //add contact to own list
      var iq = $iq({type: "set"}).c("query", {xmlns: "jabber:iq:roster"})
        .c("item", data);
      console.log("contact add request at roster");
      console.log(iq);
      Gab.connection.sendIQ(iq);

      //send subscription request for chatting
      var subscribe = $pres({to: data.jid, "type": "subscribe", "priority":"10"});
      console.log("send subscribe request for chatting");
      console.log(subscribe);
      Gab.connection.send(subscribe);
    });

    return GlobalChat = Gab;
  }]);
