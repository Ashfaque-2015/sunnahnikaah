angular.module('app')
  .factory('Options', ['$http', 'LocalService', 'AccessLevels', function($http, LocalService, AccessLevels) {
    return {
      getAllContinents: function() {
        //$http.get('/bower_components/countries/countries.min.json').
        //  success(function(data, status, headers, config) {
        //    console.log(data);
        //    console.log("ash");
        //    return data;
        //  })
        //return false;
      },
      getAllCountries: function() {
        //$http.get('/bower_components/countries/countries.min.json').
        //  success(function(data, status, headers, config) {
        //    return data.countries;
        //  })
        //return false;
      },
      getAllCountriesContinentWise: function() {
        //$http.get('/bower_components/countries/countries.min.json').
        //  success(function(data, status, headers, config) {
        //    var continents = data.continents;
        //    //console.log(data.continents);
        //    continents.forEach(function(obj) {
        //      console.log(obj);
        //    });
        //    return data.countries;
        //  })
        //return false;
      },
      convertToSlug: function (Text)
        {
          return Text
            .toLowerCase()
            .replace(/[^\w ]+/g,'')
            .replace(/ +/g,'-')
            ;
      }
    }
  }]);
