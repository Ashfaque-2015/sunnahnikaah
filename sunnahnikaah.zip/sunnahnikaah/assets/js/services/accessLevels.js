angular.module('app')
  .constant('AccessLevels', {
    anon: 0,
    user: 1,
    admin:2
  });

