angular.module('app')
  .controller('FavoriteProfilesController', ['$scope', '$stateParams', 'CurrentUser', '$http', function($scope, $stateParams, CurrentUser, $http) {
    var currentUser = CurrentUser.user();
    $scope.demoAvatar = "images/demo-profile-pic.png";
    $scope.demoAvatarMale = "images/user/profile-pic-male.png";
    $scope.demoAvatarFemale = "images/user/profile-pic-female.png";
    $scope.meFavoriteList = [];
    $scope.withFavoriteList = [];

    //var queryString = {"me":currentUser.id,"favorite_status":true}
    //console.log(queryString);
    //$http.post('/friend/getFavoriteList', queryString).success(function(data,response) {
    //  $scope.favoriteList = data;
    //  //console.log(response);
    //  console.log(data);
    //});

    $http.get("/friend?me="+currentUser.id+"&favorite_status=true").success(function(data, status, headers, config) {
      $scope.meFavoriteList = data;
    });

    $http.get("/friend?with="+currentUser.id+"&favorite_status=true").success(function(data, status, headers, config) {
      $scope.withFavoriteList = data;
      console.log(data);
    });
  }]);
