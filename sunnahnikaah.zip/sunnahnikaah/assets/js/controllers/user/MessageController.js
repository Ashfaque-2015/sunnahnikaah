angular.module('app')
  .controller('MessageController', ['$scope', '$state', '$stateParams', 'CurrentUser', '$http', '$rootScope', 'Chat', '$timeout', function ($scope, $state, $stateParams, CurrentUser, $http, $rootScope, Chat, $timeout) {

    angular.element(document).ready(function () {
      $("#show_hide").hide();
      $("button").click(function(){
        $("#show_hide").toggle();
      });


      $("#show_hide_list").click(function(){
        //$("#show_hide_list").toggle();
        $("#show_hide_list").hide();
      });
    });

    if ($state.current.data.hideSidebar) {
      $rootScope.hideSidebar = true;
    }

    console.log($stateParams);
    $scope.roster_user_list = [];
    $scope.roster_thread_list2 = [];
    $scope.demoAvatar = "images/demo-profile-pic.png";
    $scope.demoAvatarMale = "images/user/profile-pic-male.png";
    $scope.demoAvatarFemale = "images/user/profile-pic-female.png";

    if(!$rootScope.currentChatUser)
    {
      if($stateParams.hasOwnProperty("username") && $stateParams.username != ""){
        $http.get("/user?username=" + $stateParams.username)
          .success(function (data, status, headers, config) {
            if (data.length) {
              //saving globally so that we can use from message controller and nav controller
              $rootScope.currentChatUser = data[0];
            }
          });
      }
    }
    var CurntUser = CurrentUser.user();

    $scope.getRosterContacts = function (limit) {

      $scope.showSpinner = true;
      $scope.emptyThread = false;
      //console.log("getRosterContacts");
      var CurntUser = CurrentUser.user();
      $http.post('/thread/populateMyRosterContacts',{userId:CurntUser.id}).success(function(data){
        console.log(data);
        if(data.length){
          $scope.roster_thread_list2 = data;

          for (var index in $scope.roster_thread_list2) {
            $scope.roster_thread_list2[index].totalNotification = 0;
            $scope.roster_thread_list2[index].roster_activity_class = "default-thread-msg";

            if (CurntUser.id != $scope.roster_thread_list2[index].me.id && CurntUser.id == $scope.roster_thread_list2[index].other_user.id) {
              $scope.roster_thread_list2[index].roster_contact_detail = $scope.roster_thread_list2[index].me;
              if($scope.roster_thread_list2[index].hasOwnProperty('other_user_unread_notification') && $scope.roster_thread_list2[index].other_user_unread_notification){
                $scope.roster_thread_list2[index].totalNotification = $scope.roster_thread_list2[index].other_user_unread_notification;
              }
            }
            else if (CurntUser.id == $scope.roster_thread_list2[index].me.id && CurntUser.id != $scope.roster_thread_list2[index].other_user.id) {

              $scope.roster_thread_list2[index].roster_contact_detail = $scope.roster_thread_list2[index].other_user;
              if($scope.roster_thread_list2[index].hasOwnProperty('me_unread_notification') && $scope.roster_thread_list2[index].me_unread_notification){
                $scope.roster_thread_list2[index].totalNotification = $scope.roster_thread_list2[index].me_unread_notification;
              }
            }
            $scope.showSpinner = false;
          }

          $scope.roster_thread_list2.forEach(function (eachThread) {
            eachThread.totalNotification = 0;
            eachThread.roster_activity_class = "default-thread-msg";

            if (CurntUser.id != eachThread.me.id && CurntUser.id == eachThread.other_user.id) {
              if (eachThread.hasOwnProperty('other_user_unread_notification') && eachThread.other_user_unread_notification) {
                eachThread.totalNotification = eachThread.other_user_unread_notification;
              }
            }
            else if (CurntUser.id == eachThread.me.id && CurntUser.id != eachThread.other_user.id) {
              if (eachThread.hasOwnProperty('me_unread_notification') && eachThread.me_unread_notification) {
                eachThread.totalNotification = eachThread.me_unread_notification;
              }
            }

            if(eachThread.totalNotification)
              eachThread.roster_activity_class = "unread-thread-msg";

          });

          //console.log($scope.roster_thread_list2);

          if($scope.roster_thread_list2.length){
            if($rootScope.currentChatUser){
              $scope.roster_thread_list2.filter(function( obj ) {
                if($rootScope.currentChatUser.id == obj.me.id && $rootScope.currentChatUser.id != obj.other_user.id){
                  obj.roster_activity_class = "current-thread-msg";
                }
                else if($rootScope.currentChatUser.id != obj.me.id && $rootScope.currentChatUser.id == obj.other_user.id){
                  obj.roster_activity_class = "current-thread-msg";
                }
              });
            }
          }


        }
        else{
          $scope.showSpinner = false;
          $scope.emptyThread = true;
        }

      });
    }

    //$scope.getRosterContacts = function () {
    //  $http.get('/user/' + CurrentUser.user().id)
    //    .success(function (data) {
    //
    //      //find threads
    //      if (data.threads1.length) {
    //        data.threads1.forEach(function (eachObj) {
    //          $scope.roster_thread_list2.push(eachObj);
    //        });
    //      }
    //      if (data.threads2.length) {
    //        data.threads2.forEach(function (eachObj) {
    //          $scope.roster_thread_list2.push(eachObj);
    //        });
    //      }
    //
    //      //sorting threads based on updatedAt time
    //      $scope.roster_thread_list2.sort($scope.compare);
    //
    //      //var myContacts = [];
    //      //$scope.roster_thread_list2.forEach(function (eachThread) {
    //      //  eachThread.roster_activity_class = "default-thread-msg";
    //      //  if (CurntUser.id != eachThread.me && CurntUser.id == eachThread.other_user) {
    //      //    myContacts.push(eachThread.me);
    //      //  }
    //      //  else if (CurntUser.id == eachThread.me && CurntUser.id != eachThread.other_user) {
    //      //    myContacts.push(eachThread.other_user);
    //      //  }
    //      //});
    //
    //      var myContacts = [];
    //      $scope.roster_thread_list2.forEach(function (eachThread) {
    //        eachThread.totalNotification = 0;
    //        eachThread.roster_activity_class = "default-thread-msg";
    //
    //        if (CurntUser.id != eachThread.me && CurntUser.id == eachThread.other_user) {
    //          myContacts.push(eachThread.me);
    //          if (eachThread.hasOwnProperty('other_user_unread_notification') && eachThread.other_user_unread_notification) {
    //            eachThread.totalNotification = eachThread.other_user_unread_notification;
    //          }
    //        }
    //        else if (CurntUser.id == eachThread.me && CurntUser.id != eachThread.other_user) {
    //          myContacts.push(eachThread.other_user);
    //          if (eachThread.hasOwnProperty('me_unread_notification') && eachThread.me_unread_notification) {
    //            eachThread.totalNotification = eachThread.me_unread_notification;
    //          }
    //        }
    //
    //        if(eachThread.totalNotification)
    //          eachThread.roster_activity_class = "unread-thread-msg";
    //
    //      });
    //
    //      //console.log($scope.roster_thread_list2);
    //
    //      if($scope.roster_thread_list2.length){
    //        if($rootScope.currentChatUser){
    //          $scope.roster_thread_list2.filter(function( obj ) {
    //            if($rootScope.currentChatUser.id == obj.me && $rootScope.currentChatUser.id != obj.other_user){
    //              obj.roster_activity_class = "current-thread-msg";
    //            }
    //            else if($rootScope.currentChatUser.id != obj.me && $rootScope.currentChatUser.id == obj.other_user){
    //              obj.roster_activity_class = "current-thread-msg";
    //            }
    //          });
    //        }
    //      }
    //
    //      $http.get('/user?where={"id":' + JSON.stringify(myContacts) + '}').success(function (result) {
    //        //console.log("roster list ", result);
    //        $scope.roster_user_list = result;
    //
    //        //map thread and user
    //        $scope.roster_thread_list2.forEach(function (eachThread) {
    //          $scope.getRosterContactDetail(eachThread, $scope.roster_user_list);
    //        });
    //      });
    //    })
    //    .error(function (err) {
    //      console.log(err);
    //    });
    //};

    //====================rootscope watch =====================//

    //select add class for current user
    $scope.rootscopeCurrentChatUser_cb = function(newValue, oldValue) {
      console.log('rootscope.currentchatuser change hoyeche');
      $scope.roster_thread_list2.filter(function( obj ) {

        //reset previous
        if(obj.roster_activity_class!="unread-thread-msg"){
          obj.roster_activity_class = "default-thread-msg";
        }

        if($rootScope.currentChatUser.id == obj.me.id && $rootScope.currentChatUser.id != obj.other_user.id){
          obj.roster_activity_class = "current-thread-msg";
        }
        else if($rootScope.currentChatUser.id != obj.me.id && $rootScope.currentChatUser.id == obj.other_user.id){
          obj.roster_activity_class = "current-thread-msg";
        }
      });
    };

    $rootScope.$watch('currentChatUser', $scope.rootscopeCurrentChatUser_cb);

    //====================rootscope watch end =====================//

    $scope.getRosterContactDetail = function (eachThread, roster_user_list) {
      //console.log(eachThread, roster_user_list);
      roster_user_list.forEach(function (eachUser) {
        if ((eachUser.id != eachThread.me && eachUser.id == eachThread.other_user) || (eachUser.id != eachThread.other_user && eachUser.id == eachThread.me)) {
          eachThread.roster_contact_detail = eachUser;
          eachThread.roster_contact_detail.jid_class = Chat.jid_to_id(eachThread.roster_contact_detail.jid);
        }
      });
    };

    $scope.compare = function (a, b) {
      return new Date(b.updatedAt) - new Date(a.updatedAt);
    };

    $scope.getRosterContacts();


    $scope.getUserDetail = function(recentChatUser, me_its_thread){
      $http.get("/user/" + recentChatUser)
        .success(function (data, status, headers, config) {
          if (data) {
            //saving globally so that we can use from message controller and nav controller
            me_its_thread.roster_contact_detail = data;
            return me_its_thread;
          }
        });
    }

    //$scope.isThreadExist = function(userJid){
    //  var foundThread = $('#roster-contact-'+userJid);
    //  if(foundThread){
    //    return true;
    //  }
    //  return false;
    //}

    $scope.isThreadExist = function(threadId){
      for (var index in $scope.roster_thread_list2) {
        //console.log($scope.roster_thread_list2[index].id);
        if ($scope.roster_thread_list2[index].id == threadId) {
          //threadAlreadyExist = true;
          return true;
        }
      }
      return false;
    }

    $scope.addThreadToRoster = function(thread){
      $http.post("/thread/"+thread).success(function (data, status, headers, config) {
        if (data) {
          console.log("thread exist na so adding new thread at roster");

          var other_user = {};
          if (data.me.id == CurntUser.id && data.other_user.id != CurntUser.id)
            other_user = data.other_user;
          else if (data.me.id != CurntUser.id && data.other_user.id == CurntUser.id)
            other_user = data.me;

          if (other_user) {
            //console.log("ekhane ki aise");
            data.roster_contact_detail = other_user;
            data.roster_contact_detail.jid_class = Chat.jid_to_id(other_user.jid);
            data.roster_activity_class = "unread-thread-msg";
            //console.log(other_user);
            $scope.roster_thread_list2.unshift(data);

            //console.log($scope.roster_thread_list2);
          }
        }
      });
    }

    //================event handler=======================//

    //update lastmessage
    //order the thread as last message thread should be at first
    $scope.eventUpdateLastMessage_cb = function (event, args) {
      console.log("eventUpdateLastMessage_cb");
      console.log(args);
      if(!$scope.isThreadExist(args.thread)){
        console.log("painai thread so adding...");
        $scope.addThreadToRoster(args.thread);
        console.log("new thread added");
      }
      var threadId, deletedThreads = [];

      //threadId = $('#roster-contact-' + args.thread).data("threadid");
      console.log(args.thread);

      //finding the thread and delete from the list
      for (var i = 0; i < $scope.roster_thread_list2.length; i++) {
        if ($scope.roster_thread_list2[i].id == args.thread) {
          if(i==0){ //if already the first item then no need to delete, just update the last message and roster class
            console.log("ekhane ashena ken");
            $scope.roster_thread_list2[i].last_message = args.message;
            $scope.roster_thread_list2[i].roster_activity_class = args.roster_class;
          }else{
            console.log("thread delete korte aise");
            deletedThreads = $scope.roster_thread_list2.splice(i, 1); //as the splice return an array that's why the name 'deletedThreads' as plural but here deleting one thread here
          }
        }
      }

      //append the deleted thread at first
      deletedThreads.forEach(function (thisThread) {
        $timeout(function () {
          thisThread.last_message = args.message;
          thisThread.roster_activity_class = args.roster_class;
          console.log(thisThread);
          $scope.roster_thread_list2.unshift(thisThread);
        });
      });
    };
    $scope.$on("eventLastMessageUpdate", $scope.eventUpdateLastMessage_cb);

    //adding new contact into roster list which was not exist
    $scope.eventUpdateThreadAndNotification_cb = function (event, args) {
      console.log('eventUpdateThreadAndNotification_cb');
      console.log(args);
      var threadAlreadyExist = false;
      //$scope.roster_thread_list2.forEach(function (eachThread) {
      //  if (eachThread.id == args.thread.id) {
      //    threadAlreadyExist = true;
      //    $timeout(function(){
      //      //console.log("ekhane o ki aise thread er notification resent dekhanor jonno");
      //
      //      eachThread = args.thread;
      //      console.log(eachThread);
      //      console.log($scope.roster_thread_list2);
      //    });
      //  }
      //});

      $timeout(function () {
        for (var index in $scope.roster_thread_list2) {
          //console.log("index", index);

          if ($scope.roster_thread_list2[index].id == args.thread.id) {
            //console.log("index", index);
            //console.log(args.thread);
            threadAlreadyExist = true;

            $scope.roster_thread_list2[index].me_unread_notification = args.thread.me_unread_notification;
            $scope.roster_thread_list2[index].other_user_unread_notification = args.thread.other_user_unread_notification;

            $scope.roster_thread_list2[index].totalNotification = 0;
            //console.log($scope.roster_thread_list2[index]);
            //console.log($scope.roster_thread_list2);
          }
        }
        //if the thread not exist then push
        if (!threadAlreadyExist) {
          console.log("thread exist na so adding new thread at roster");
          console.log(args);
          if (args.thread.me.id == CurntUser.id && args.thread.other_user.id != CurntUser.id){
            args.thread.roster_contact_detail = args.thread.other_user;
            args.thread.roster_contact_detail.jid_class = Chat.jid_to_id(args.thread.other_user.jid);
          }
          else if (args.thread.me.id != CurntUser.id && args.thread.other_user.id == CurntUser.id){
            args.thread.roster_contact_detail = args.thread.me;
            args.thread.roster_contact_detail.jid_class = Chat.jid_to_id(args.thread.me.jid);
          }
          args.thread.roster_activity_class = "current-thread-msg";
          $scope.roster_thread_list2.unshift(args.thread);

          //if (other_user_id) {
          //  $http.get('/user/' + other_user_id)
          //    .success(function (data) {
          //      if (data) {
          //        args.thread.roster_contact_detail = data;
          //        args.thread.roster_contact_detail.jid_class = Chat.jid_to_id(data.jid);
          //        //console.log(args.thread);
          //        $scope.roster_thread_list2.unshift(args.thread);
          //      }
          //    })
          //    .error(function (err) {
          //      console.log(err);
          //    });
          //}
        }
      });

    };
    $scope.$on("eventUpdateThreadAndNotification", $scope.eventUpdateThreadAndNotification_cb);

    //unread message notificaiton count
    $scope.unread_message_notification_cb = function (event, args) {
      console.log('unread_message_notification_cb');
      console.log(args);
      $timeout(function () {
        var notFoundThread = true;
        if ($scope.roster_thread_list2.length) {

          $scope.roster_thread_list2.filter(function( obj ) {
            //return obj.id == args.threadmsg.thread[0].id;

            if(obj.id == args.threadmsg.thread[0].id){
              notFoundThread = false;
              if (args.threadmsg.message[0].from == args.threadmsg.thread[0].other_user_jid) {
                obj.totalNotification = args.threadmsg.thread[0].me_unread_notification;
              }
              else {
                obj.totalNotification = args.threadmsg.thread[0].other_user_unread_notification;
              }
            }
          });

          //if(expectedThread){
          //  notFoundThread = false;
          //  if (args.threadmsg.message[0].from == args.threadmsg.thread[0].other_user_jid) {
          //    expectedThread.totalNotification = args.threadmsg.thread[0].me_unread_notification;
          //  }
          //  else {
          //    expectedThread.totalNotification = args.threadmsg.thread[0].other_user_unread_notification;
          //  }
          //}

          //$scope.roster_thread_list2.forEach(function (eachThread) {
          //  if (eachThread.id == args.threadmsg.thread[0].id) {
          //    notFoundThread = false;
          //    if (args.threadmsg.message[0].from == args.threadmsg.thread[0].other_user_jid) {
          //      eachThread.totalNotification = args.threadmsg.thread[0].me_unread_notification;
          //    }
          //    else {
          //      eachThread.totalNotification = args.threadmsg.thread[0].other_user_unread_notification;
          //    }
          //  }
          //});
        }
        //if(notFoundThread){
        //  console.log("thread push korte aise");
        //  console.log(args.threadmsg);
        //
        //  if(args.threadmsg.thread[0].me == CurntUser.id )
        //    args.threadmsg.thread[0] = $scope.getUserDetail(args.threadmsg.thread[0].other_user, args.threadmsg.thread[0])
        //  else
        //    args.threadmsg.thread[0] = $scope.getUserDetail(args.threadmsg.thread[0].me, args.threadmsg.thread[0])
        //
        //  $scope.roster_thread_list2.unshift(args.threadmsg.thread[0]);
        //
        //  if ($scope.roster_thread_list2[0].id == args.threadmsg.thread[0].id) {
        //    if (args.threadmsg.message[0].from == args.threadmsg.thread[0].other_user_jid) {
        //      $scope.roster_thread_list2[0].totalNotification = args.threadmsg.thread[0].me_unread_notification;
        //    }
        //    else {
        //      $scope.roster_thread_list2[0].totalNotification = args.threadmsg.thread[0].other_user_unread_notification;
        //    }
        //  }
        //}
      });
    }
    $scope.$on("unread_message_notification", $scope.unread_message_notification_cb);

    //================end event handler=======================//


    //================chat on message handler=======================//

    $scope.on_message_roster = function (message) {
      console.log('on_message_roster');
      console.log(message);
      var full_jid = $(message).attr('from');
      var jid = Strophe.getBareJidFromJid(full_jid);
      var jid_id = Chat.jid_to_id(jid);

      //checking the user with which currently chatting or not
      if ($state.current.name == 'base.user.messages.detail' && $rootScope.currentChatUser.hasOwnProperty("jid") && $rootScope.currentChatUser.jid == jid) {
        //console.log("ami currently er shathei chat korchi");
        //already message is coming from message detail controller so no need to push form here too
      }
      else if ($state.current.name == 'base.user.messages.detail' && $rootScope.currentChatUser.hasOwnProperty("jid") && $rootScope.currentChatUser.jid != jid) {
        //console.log("ami currently er shathe chat korchi na");

        var body = $(message).find("html > body");
        var threadId = $(message).find('thread').text();
        if (body.length === 0) {
          body = $(message).find('body');
          if (body.length > 0) {
            body = body.text()
          }
          else {
            body = null;
          }
        }
        else {
          body = body.contents();

          var span = $("<span></span>");
          body.each(function () {
            if (document.importNode) {
              $(document.importNode(this, true)).appendTo(span);
            }
            else {
              // IE workaround
              span.append(this.xml);
            }
          });

          body = span;
        }

        if (body) {
          console.log("emit korte ashche");
          $scope.$emit('eventLastMessageUpdate', {message: body, jid_id: jid_id, roster_class: "unread-thread-msg",thread:threadId});
        }
      }
      return true;
    };

    if(Chat.connection){

      if(!Chat.handlersObj.hasOwnProperty('m_messagectl_on_message_roster') ){
        var onmsghandler =  Chat.connection.addHandler($scope.on_message_roster, null, "message", "chat");
        if(onmsghandler){
          Chat.handlers.push({m_messagectl_on_message_roster:onmsghandler});
          Chat.handlersObj.m_messagectl_on_message_roster = onmsghandler;
        }
      }


    }


    //================end chat on message handler=======================//


    angular.element(document).ready(function () {

      //$('#login_dialog').dialog({
      //  autoOpen: true,
      //  draggable: false,
      //  modal: true,
      //  title: 'Connect to XMPP',
      //  buttons: {
      //    "Connect": function () {
      //      $(document).trigger('connect', {
      //        jid: $('#jid').val().toLowerCase(),
      //        password: $('#password').val()
      //      });
      //
      //      $('#password').val('');
      //      $(this).dialog('close');
      //    }
      //  }
      //});

      $('#contact_dialog').dialog({
        autoOpen: false,
        draggable: false,
        modal: true,
        title: 'Add a Contact',
        buttons: {
          "Add": function () {
            $(document).trigger('contact_added', {
              jid: $('#contact-jid').val().toLowerCase(),
              name: $('#contact-name').val()
            });

            $('#contact-jid').val('');
            $('#contact-name').val('');

            $(this).dialog('close');
          }
        }
      });

      $('#new-contact').click(function (ev) {
        $('#contact_dialog').dialog('open');
      });

      $('#chat-area').tabs().find('.ui-tabs-nav').sortable({axis: 'x'});

      $(document).on('click', '.roster-contact', function () {
        var jid = $(this).find(".roster-jid").text();
        var name = $(this).find(".roster-name").text();
        var jid_id = Chat.jid_to_id(jid);

        if ($('#chat-' + jid_id).length === 0) {
          $('.chat-cont-inner2').append('' +
          '<div class="chat-area-item2" data-jid="' + jid + '" id="chat-' + jid_id + '">' +
          '<h4 class="chat-item-title">' + name + '<span class="btn-icon-remove"><i class="fa fa-remove"></i></span></h4>' +
          '<div class="chat-messages" id="chat-message-' + jid_id + '"></div>' +
          '<input type="text" class="chat-input" id="chat-input-' + jid_id + '">' +
          '</div>');
        }

        $(".chat-area-item2").each(function () {
          $(this).css("display", "none");
        });

        $('#chat-' + jid_id).css("display", "block");
        //$('#chat-' + jid_id).css("height","300px");
        //$('#chat-' + jid_id).css("margin-top","-250px");
        $('#chat-' + jid_id + ' input').focus();

        //place the calculated height for chat area
        var chatAreaHeight = $(window).height();// $('.chat-area-item2').height();
        chatAreaHeight = chatAreaHeight - $(".chat-area-item2 .chat-item-title").height() - $(".chat-area-item2 .chat-input").height() - $("#main_nav").height() - 28;

        $('.chat-area-item2 .chat-messages').height(chatAreaHeight);

      });

      //chat box collopse me
      $(document).on('click', '.chat-item-title', function () {
        var chat_box = $(this).parent();
        if (chat_box.css("height") == "38px") {
          chat_box.css("height", "300px");
          //chat_box.css("margin-top","-250px");
        } else {
          chat_box.css("height", "38px");
          chat_box.css("margin-top", "0px");
        }
      });

      //chat box hide me
      //$(document).on('click', '.btn-icon-remove', function () {
      //  var chat_box = $(this).parent().parent();
      //  chat_box.hide();
      //
      //});

      //$(document).on('keypress', '.chat-input', function (ev) {
      //  var jid = $(this).parent().data('jid');
      //
      //  if (ev.which === 13) {
      //    ev.preventDefault();
      //
      //    var body = $(this).val();
      //
      //    var message = $msg({
      //      to: jid,
      //      "type": "chat"
      //    })
      //      .c('body').t(body).up()
      //      .c('active', {xmlns: "http://jabber.org/protocol/chatstates"});
      //    Chat.connection.send(message);
      //
      //    $(this).parent().find('.chat-messages').append(
      //      "<div class='chat-message'>&lt;" +
      //      "<span class='chat-name me'>" +
      //      Strophe.getNodeFromJid(Chat.connection.jid) +
      //      "</span>&gt;<span class='chat-text'>" +
      //      body +
      //      "</span></div>");
      //    Chat.scroll_chat(Chat.jid_to_id(jid));
      //
      //    $(this).val('');
      //    $(this).parent().data('composing', false);
      //  }
      //  else {
      //    var composing = $(this).parent().data('composing');
      //    if (!composing) {
      //      var notify = $msg({to: jid, "type": "chat"})
      //        .c('composing', {xmlns: "http://jabber.org/protocol/chatstates"});
      //      Chat.connection.send(notify);
      //
      //      $(this).parent().data('composing', true);
      //    }
      //  }
      //});

      //$('#disconnect').click(function () {
      //  //Chat.auth();
      //  //alert("ashraf");
      //  //console.log("disconnecting");
      //  //console.log(Chat);
      //  //Chat.connection.disconnect();
      //  //Chat.connection = null;
      //
      //  Chat.disconnect_me();
      //
      //});

      $('#chat_dialog').dialog({
        autoOpen: false,
        draggable: false,
        modal: true,
        title: 'Start a Chat',
        buttons: {
          "Start": function () {
            var jid = $('#chat-jid').val().toLowerCase();
            var jid_id = Chat.jid_to_id(jid);

            //$('#chat-area').tabs('add', '#chat-' + jid_id, jid);
            $("<li><a href='/remote/tab.html'>New Tab</a></li>")
              .appendTo("#chat-area .ui-tabs-nav");
            $('#chat-area').tabs("refresh");

            $('#chat-' + jid_id).append(
              "<div class='chat-messages'></div>" +
              "<input type='text' class='chat-input'>");

            $('#chat-' + jid_id).data('jid', jid);

            //$('#chat-area').tabs('select', '#chat-' + jid_id);
            $("#chat-area").tabs("option", "active", 2);

            $('#chat-' + jid_id + ' input').focus();


            $('#chat-jid').val('');

            $(this).dialog('close');
          }
        }
      });

      $('#new-chat').click(function () {
        console.log("new-chat");
        $('#chat_dialog').dialog('open');
      });
    });

  }]);
