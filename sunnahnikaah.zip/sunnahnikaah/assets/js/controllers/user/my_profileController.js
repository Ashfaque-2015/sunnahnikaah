angular.module('app')
  .controller('MyProfileController', ['$scope', '$state', '$rootScope', 'CurrentUser', '$http', function($scope,$state,$rootScope,CurrentUser,$http)
  {

    //if ($state.current.data.hideSidebar) {
    //  $rootScope.hideSidebar = false;
    //}

    var currentUser = CurrentUser.user();
    $scope.my_id = currentUser.id;

    console.log(currentUser);

  $http.get('/user/'+currentUser.id).success(function(response){

    console.log(response);
    $scope.profile = response;


    }) ;


/*   $http.get('/profile?user='+currentUser.id).

success(function(response) {
  $scope.user_profile=  response;

}).
error(function(data, status, headers, config) {

});
*/


$scope.updateProfile = function() {

  console.log('ki re');

//alert($scope.user);
    //  $http.put('/user/update/'+currentUser.id+'?details='+$scope.user.details).
    $http.put('/user/update/'+currentUser.id+'?',$scope.profile).

  success(function(data, status, headers, config) {
    alert($scope.profile.details);
  }).
  error(function(data, status, headers, config) {
    // called asynchronously if an error occurs
    // or server returns response with an error status.
  });


        };



    }]);
