angular.module('app')
  .controller('MyaccountController', ['$scope', '$state', '$rootScope', 'CurrentUser', function($scope,$state,$rootScope,CurrentUser) {
    console.log("MyaccountController");
    CurrentUser.setBodyClass();









    }]);
