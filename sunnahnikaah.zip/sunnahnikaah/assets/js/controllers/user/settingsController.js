angular.module('app')
  .controller('SettingsController', ['$scope', '$http', 'CurrentUser', function($scope,$http,CurrentUser) {

    $scope.alerts =[];
    var currentUser = CurrentUser.user();

    $scope.profile = {};
    $scope.updatedProfile = {};

    $http.get('/user/'+currentUser.id).success(function(response){
      $scope.profile = response;
      $scope.dt = response.dob;
      $scope.profile.dob = new Date(response.dob);

      $scope.updatedProfile.first_name = response.first_name;
      $scope.updatedProfile.last_name = response.last_name;
      $scope.updatedProfile.maharam_email = response.maharam_email;
      $scope.updatedProfile.dob = new Date(response.dob);
      $scope.updatedProfile.gender = response.gender;
      $scope.updatedProfile.country = response.country;
    });

    //console.log($scope.profile);
    //datepicker
    //$scope.today = function() {
    //  $scope.dt = new Date();
    //};
    ////$scope.today();
    //
    //$scope.clear = function () {
    //  $scope.dt = null;
    //};
    //// Disable weekend selection
    //$scope.disabled = function(date, mode) {
    //  return ( mode === 'day' && ( date.getDay() === 0 || date.getDay() === 6 ) );
    //};
    //$scope.toggleMin = function() {
    //  $scope.minDate = $scope.minDate ? null : new Date();
    //};
    //$scope.toggleMin();
    //$scope.open = function($event) {
    //  $event.preventDefault();
    //  $event.stopPropagation();
    //  $scope.opened = true;
    //};
    //$scope.dateOptions = {
    //  formatYear: 'yy',
    //  startingDay: 1
    //};
    //$scope.formats = ['dd-MMMM-yyyy','yyyy/MM/dd','dd.MM.yyyy','dd/MM/yyyy','shortDate'];
    //$scope.format = $scope.formats[3];


    //dropdown country
    //$scope.items = ["Afghanistan","Armenia","Azerbaijan","..."];
    //$scope.status = {
    //  isopen: false
    //};
    //$scope.toggled = function(open) {
    //  $log.log('Dropdown is now: ', open);
    //};
    //$scope.toggleDropdown = function($event) {
    //  $event.preventDefault();
    //  $event.stopPropagation();
    //  $scope.status.isopen = !$scope.status.isopen;
    //};


    $scope.findUniqueUsername = function(){
      //check unique username
      $("#check-username").html('<i class="fa fa-refresh fa-spin"></i>');
      $http.post('/user/find?username='+$scope.profile.username).
        success(function (data, status, headers, config) {
          console.log("successfull");
          console.log(data[0].id);
          if(data[0].id!==currentUser.id)
            $("#check-username").html('Not Available');//.delay(10000).html("Check");
        }).
        error(function (err, data, status, headers, config) {
          // called asynchronously if an error occurs
          // or server returns response with an error status.
        });
    };



    $scope.saveSettings = function(){

      //if($scope.profile.hasOwnProperty("dob") && $scope.profile.dob!=""){
      //  $scope.profile.dob_timestamp = new Date($scope.profile.dob).getTime();
      //  $scope.profile.dob = new Date($scope.profile.dob);
      //}

      //console.log($scope.profile);
      //console.log('user/update/'+currentUser.id);
      $http.put('user/update/'+currentUser.id,$scope.updatedProfile).
        success(function(data, status, headers, config) {
          //console.log("successfully updated");
          //
          //console.log(data);
          //console.log($scope.profile.password);
          //console.log($scope.profile.confirmPassword);
          $scope.alerts.push({ type: 'success', msg: 'Well done! You have successfully saved the settings for  '+data.username });
        }).
        error(function(data, status, headers, config) {
          console.log('error data',data);
          console.log('error status',status);
          //console.log("error:",data,status,header,config);
          // called asynchronously if an error occurs
          // or server returns response with an error status.
          $scope.alerts.push({ type: 'danger', msg: 'Oh snap! Failed to save the setting.' });
        })
    };

    $scope.closeAlert = function (index) {
      $scope.alerts.splice(index, 1);
    };

    //$scope.setDOB = function(){
    //  console.log($scope.dt);
    //  console.log($scope.profile.dob);
    //};

  }]);
