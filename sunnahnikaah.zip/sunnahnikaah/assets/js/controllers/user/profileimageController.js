angular.module('app')
  .controller('ProfileImageController', ['$http', '$scope', '$upload', '$location', 'CurrentUser', 'ngDialog', function ($http, $scope, $upload, $location, CurrentUser,ngDialog) {

    $scope.isUploading = false;

    $scope.fileLoc = "images/demo-profile-pic.png";
    $scope.demoAvatarMale = "images/user/profile-pic-male.png";
    $scope.demoAvatarFemale = "images/user/profile-pic-female.png";

    $scope.defaultAvatars = [];

    $scope.loggedinUser = {};
    //$scope.myprofile_image;

    $scope.alert = [];

    var currentUser = CurrentUser.user();

    $scope.getProfileImages = function(){
      $http.post('/user/find?id=' + currentUser.id).success(function (data, status, headers, config) {
        $scope.loggedinUser = data;
        console.log($scope.loggedinUser);

        $scope.profilePics = [];
        if ($scope.loggedinUser.profile_images.length)
          $scope.profilePics = $scope.loggedinUser.profile_images;
        console.log($scope.profilePics);
      })
        .error(function (data, status, headers, config) {
          // called asynchronously if an error occurs
          // or server returns response with an error status.
        });
    };

    $scope.getProfileImages();


    //$scope.getDefaultMaleAvatars = function(){
    //  $http.post('profileimages/getDefaultMaleAvatar').success(function(data, status, headers, config){
    //    console.log(data);
    //
    //    if(data.images){
    //      $scope.defaultAvatars = data.images;
    //      $scope.imgdir = data.imgdir;
    //    }
    //
    //  });
    //};

    $scope.getDefaultAvatars = function(){

      var getAvatar;

      if(currentUser.gender == 'male')
        getAvatar = $http.post('profileimages/getDefaultMaleAvatar');
      else
        getAvatar = $http.post('profileimages/getDefaultFemaleAvatar');

      getAvatar.success(function(data, status, headers, config){
        console.log(data);

        if(data.images){
          $scope.defaultAvatars = data.images;
          $scope.imgdir = data.imgdir;
        }

      });
    };

      $scope.getDefaultAvatars();


    //file uploading
    $scope.$watch('files', function () {
      $scope.upload($scope.files);
    });

    $scope.upload = function (files) {


      if (files && files.length) {
        $scope.isUploading = true;

        for (var i = 0; i < files.length; i++) {
          var file = files[i];
          console.log("take file");
          console.log($upload);
          $upload.upload({
            url: '/file/upload',
            fields: {
              'userId': currentUser.id
            },
            file: file
          }).progress(function (evt) {
            //  $("#profile-img-cont").empty().html('<i class="fa fa-refresh fa-spin"></i>');
            var progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
            //console.log('progress: ' + progressPercentage + '% ' +
            //evt.config.file.name);
          }).success(function (data, status, headers, config) {
            $scope.isUploading = false;
            //console.log('filename: ' + config.file.name + ' uploaded. Response: ' +
            // JSON.stringify(data));
            $scope.profilePics.push(data.newImageRecord);
            console.log($scope.profilePics);
            $scope.loggedinUser.myprofile_image = data.file;
          });
        }
      }
    };

    //changing profile pi
    $scope.chooseThis = function (img_path) {
      console.log(img_path);
      $scope.loggedinUser.myprofile_image = img_path;

      var query = {myprofile_image: img_path};
      console.log($scope.loggedinUser.id);
      $http.put('/user/update/' + $scope.loggedinUser.id, query).success(function (data) {
        console.log(data);
      })
    };

    $scope.deleteThis = function (img) {
      console.log('imgPath', img.img_path);
      //console.log(imgId);
      //$http.post('/profileimages/destroy?id='+imgId).success(function (data, status, headers, config) {
      //  console.log("successfull");
      //  console.log(data);
      //}).error(function (data, status, headers, config) {
      //  // called asynchronously if an error occurs
      //  // or server returns response with an error status.
      //});

      if ($scope.loggedinUser.myprofile_image === img.img_path) {
        ngDialog.open({
          template: '<div>Sorry! you can&#39;t delete current profile image</div>',
          plain: true
        });
      }
      else{
        $http.post('/profileimages/deleteImage', {"profileimageId": img.id,"profileimagePath": img.img_path }).success(function(data) {

          //console.log(data);
          var index = $scope.profilePics.indexOf(img);

          $scope.profilePics.splice(index, 1);

          //console.log($scope.profilePics);
          ngDialog.open({
            template: '<div>Image deleted successfully</div>',
            plain: true
          });

        });
      }
      //calling backend "deleteImage" function
      //$http.post('/profileimages/deleteImagefromDB',{"profileimageId":imgId});
      //console.log($scope.profilePics)

    }

  }]);
