angular.module('app')
  .controller('LookingForController', ['$scope', 'CurrentUser', '$http', function ($scope, CurrentUser, $http) {
    $scope.alerts = [];
    $scope.test = 23423;
    var currentUser = CurrentUser.user();
    $scope.currentUser = CurrentUser.user();

    //edited

    if (currentUser.gender == "female") {
      console.log('ami maiya');

    }
    //edited
    $http.get('/user/' + currentUser.id).success(function (response) {
      $scope.profile = response;


      if (response.lookingfor_preferred_locations) {
        $scope.selection = response.lookingfor_preferred_locations;
      } else {
        $scope.selection = [];
      }
      if (response.lookingfor_ethnicity) {
        $scope.selectedEthnicity = response.lookingfor_ethnicity;
      }
      else {
        $scope.selectedEthnicity = [];
      }
      if (response.lookingfor_preferred_professions) {
        $scope.selectedProfessions = response.lookingfor_preferred_professions;
      }
      else {
        $scope.selectedProfessions = [];
      }
    });


    $scope.asia = ["Afghanistan", "Armenia", "Azerbaijan", "Bahrain", "Bangladesh", "Bhutan", "Brunei", "Cambodia", "China", "Christmas Island", "Cocos ( Keeling) Islands", "Cyprus", "Georgia", "Hong Kong", "India", "Indonesia", "Iran", "Iraq", "Israel", "Japan", "Jordan", "Kazakhstan", "North Korea", "South Korea", "Kuwait", "Kyrgyzstan", "Laos", "Lebanon", "Macau SAR China", "Malaysia", "Maldives", "Mongolia", "Myanmar (Burma)", "Nepal", "Oman", "Pakistan", "Palestinian Territories", "Philippines", "Qatar", "Saudi Arabia", "Singapore", "Sri Lanka", "Syria", "Taiwan", "Tajikistan", "Thailand", "Timor-Leste", "Turkey", "Turkmenistan", "United Arab Emirates", "Uzbekistan", "Vietnam", "Yemen"];
    $scope.africa = ["Algeria", "Angola", "Benin", "Botswana", "Burkina Faso", "Burundi", "Cameroon", "Cape Verde", "Central African Republic", "Chad", "Comoros", "Congo - Brazzaville", "Congo - Kinshasa", "Côte d’Ivoire", "Djibouti", "Egypt", "Equatorial Guinea", "Eritrea", "Ethiopia", "Gabon", "Gambia", "Ghana", "Guinea", "Guinea-Bissau", "Kenya", "Lesotho", "Liberia", "Libya", "Madagascar", "Malawi", "Mali", "Mauritania", "Mauritius", "Mayotte", "Morocco", "Mozambique", "Namibia", "Niger", "Nigeria", "Réunion", "Rwanda", "Saint Helena", "São Tomé and Príncipe", "Senegal", "Seychelles", "Sierra Leone", "Somalia", "South Africa", "Sudan", "South Sudan", "Swaziland", "Tanzania", "Togo", "Tunisia", "Uganda", "Western Sahara", "Zimbabwe", "Zambia"];
    $scope.europe = ["Åland Islands", "Albania", "Andorra", "Austria", "Belarus", "Belgium", "Bosnia and Herzegovina", "Bulgaria", "Croatia", "Czech Republic", "Denmark", "Estonia", "Faroe Islands", "Finland", "France", "Germany", "Gibraltar", "Greece", "Guernsey", "Hungary", "Iceland", "Ireland", "Isle of Man", "Italy", "Jersey", "Kosovo", "Latvia", "Liechtenstein", "Lithuania", "Luxembourg", "Macedonia", "Malta", "Moldova", "Monaco", "Montenegro", "Netherlands", "Norway", "Poland", "Portugal", "Romania", "Russia", "San Marino", "Serbia", "Slovakia", "Slovenia", "Spain", "Svalbard and Jan Mayen", "Sweden", "Switzerland", "Ukraine", "United Kingdom", "Vatican City"];
    $scope.north = ["Anguilla", "Antigua and Barbuda", "Aruba", "Bahamas", "Barbados", "Belize", "Bermuda", "British Virgin Islands", "Canada", "Canary Islands", "Cayman Islands", "Costa Rica", "Cuba", "Dominica", "Dominican Republic", "El Salvador", "Greenland", "Grenada", "Guadeloupe", "Guatemala", "Haiti", "Honduras", "Jamaica", "Martinique", "Mexico", "Montserrat", "Netherlands Antilles", "Nicaragua", "Panama", "Puerto Rico", "Saint Barthélemy", "Saint Kitts and Nevis", "Saint Lucia", "Saint Martin", "Saint Pierre and Miquelon", "Saint Vincent and the Grenadines", "Trinidad and Tobago", "U.S. Virgin Islands", "United States"];
    $scope.south = ["Argentina", "Bolivia", "Brazil", "Chile", "Colombia", "Ecuador", "Falkland Islands", "French Guiana", "Guyana", "Paraguay", "Peru", "Suriname", "Uruguay", "Venezuela"];
    $scope.pacific = ["Samoa", "Australia", "Cook Islands", "Fiji", "French Polynesia", "Guam", "Kiribati", "Marshall Islands", "Micronesia", "Nauru", "New Caledonia", "New Zealand", "Niue"];

    $scope.asian = ["Asian - Afghan", "Asian - Bangladeshi", "Asian - Chinese", "Asian - Indian", "Asian - Indonesian", "Asian - Kurdish", "Asian - Kyrgyz", "Asian - Malay", "Asian - Maldives", "Asian - Pakistani", "Asian - Turkish", "Asian - Sri Lankan", "Asian - Other Background"];
    $scope.white = ["White - American", "White - Australian", "White - British", "White - Canadian", "White - Hispanic", "White - Other Background"];
    $scope.black = ["Black - African", "Black - American", "Black - British", "Black - Caribbean", "Black - Ethiopian", "Black - Somali", "Black - Other Background", "Other Ethnic Group"];
    $scope.other = ["Arab", "Bosnian", "Any Other Ethnic Group"];
    $scope.professions = ["Actor", "Accountant", "Administration Professional", "Advertising Professional", "Air Hostess", "Architect", "Artisan", "Audiologist", "Banker", "Beautician", "Biologist / Botanist", "Business Person", "Chartered Accountant", "Civil Engineer", "Clerical Official", "Commercial Pilot", "Company Secretary", "Computer Professional", "Consultant", "Contractor", "Cost Accountant", "Creative Person", "Engineer (Mechanical)", "Engineer (Project)", "Entertainment Professional", "Event Manager", "Executive", "Factory worker", "Farmer", "Fashion Designer", "Finance Professional", "Flight Attendant", "Government Employee", "Customer Support Professional", "Defense Employee", "Dentist", "Designer", "Doctor", "Economist", "Engineer", "Health Care Professional", "Home Maker", "Human Resources Professional", "Interior Designer", "Investment Professional", "IT / Telecom Professional", "Journalist", "Lawyer", "Lecturer", "LegalProfessional", "Manager", "Marketing Professional", "Media Professional", "Medical Professional", "Medical Transcriptionist", "Merchant Naval Officer", "Non-mainstream professional", "Not working", "Nurse", "Occupational Therapist", "Optician", "Pharmacist", "Physician Assistant", "Physicist", "Physiotherapist", "Pilot", "Politician", "Production professional", "Professor", "Psychologist", "Public Relations Professional", "Real Estate Professional", "Research Scholar", "Retail Professional", "Retired Person", "Sales Professional", "Scientist", "Self-employed Person", "Social Worker", "Software Consultant", "Sportsman", "Student", "Teacher", "Technician", "Training Professional", "Transportation Professional", "Veterinary Doctor", "Volunteer", "Writer", "Zoologist", "Other"];


    // toggle selection for a given fruit by name
    $scope.toggleSelection = function toggleSelection(fruitName) {
      var idx = $scope.selection.indexOf(fruitName);

      // is currently selected
      if (idx > -1) {
        $scope.selection.splice(idx, 1);
      }

      // is newly selected
      else {
        $scope.selection.push(fruitName);
      }
    };
    $scope.toggleEthnicity = function toggleEthnicity(fruitName) {
      var idx = $scope.selectedEthnicity.indexOf(fruitName);

      // is currently selected
      if (idx > -1) {
        $scope.selectedEthnicity.splice(idx, 1);
      }

      // is newly selected
      else {
        $scope.selectedEthnicity.push(fruitName);
      }
    };
    $scope.toggleProfessions = function toggleEthnicity(fruitName) {
      var idx = $scope.selectedProfessions.indexOf(fruitName);

      // is currently selected
      if (idx > -1) {
        $scope.selectedProfessions.splice(idx, 1);
      }

      // is newly selected
      else {
        $scope.selectedProfessions.push(fruitName);
      }
    };
    $scope.updatelooking = function () {
      //console.log('looking for details', $scope.profile.looking_for_details);
      // check description length
      if ($scope.profile.looking_for_details) {
        //alert('aise');
        if ($scope.profile.looking_for_details.split(" ").length < 10 && !$scope.profile.looking_for_details == '') {
          $scope.alerts.push({type: 'danger', msg: 'Write at least 50 words about who are you looking for'});
          return;
        }
      }
      //

      //console.log($scope.selectedProfessions);
      //console.log($scope.profile);
      //return;
      //alert($scope.profile.id);
      var countries = [];
      for (eachCountry in $scope.profile.lookingfor_preferred_locations) {
        countries.push(eachCountry);
        //console.log(eachCountry);
      }
      $scope.profile.lookingfor_preferred_locations = $scope.selection;
      $scope.profile.lookingfor_ethnicity = $scope.selectedEthnicity;
      $scope.profile.lookingfor_preferred_professions = $scope.selectedProfessions;

      //console.log($scope.profile);

      //delete me_with field to avoid error
      delete $scope.profile.me_with;
      delete $scope.profile.my_friends;
      //

      $http.put('/user/update/' + currentUser.id , $scope.profile).
        success(function (data, status, headers, config) {
          //console.log(data);
          //console.log(status);
          //console.log(headers);
          //console.log(config);
          $scope.alerts.push({
            type: 'success',
            msg: 'Well done! You have successfully updated looking for profile for ' + data.username
          });
        }).
        error(function (data, status, headers, config) {
          console.log('err data', data);
          console.log('err status', status);
          // called asynchronously if an error occurs
          // or server returns response with an error status.
          $scope.alerts.push({type: 'danger', msg: 'Oh snap! Failed to update profile.'});
        });


      //console.log('locations show: ', $scope.profile.lookingfor_preferred_locations);
    };

    $scope.changeTab = function (id) {
      document.getElementById('asia').className = "tab-pane";
      document.getElementById('africa').className = "tab-pane";
      document.getElementById('europe').className = "tab-pane";
      document.getElementById('north').className = "tab-pane";
      document.getElementById('south').className = "tab-pane";
      document.getElementById('pacific').className = "tab-pane";
      var NAME = document.getElementById(id);
      NAME.className = "tab-pane active";
    };

    $scope.closeAlert = function (index) {
      $scope.alerts.splice(index, 1);
    };
  }]);




