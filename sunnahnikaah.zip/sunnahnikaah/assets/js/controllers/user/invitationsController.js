angular.module('app')
  .controller('InvitationsController', ['$scope', '$stateParams', 'CurrentUser', '$http', function($scope, $stateParams, CurrentUser, $http) {
    var currentUser = CurrentUser.user();
    $scope.demoAvatar = "images/demo-profile-pic.png";
    $scope.meInvitedList = [];
    $scope.withInvitedList = [];
    $scope.myAcceptedInvitationList = [];
    $scope.invitation_status = "pending";

    //I invited
    $http.get("/friend?me="+currentUser.id+"&invitation_status=pending").success(function(data, status, headers, config) {
      $scope.meInvitedList = data;
    });

    //Invited me
    $http.get("/friend?with="+currentUser.id+"&invitation_status=pending").success(function(data, status, headers, config) {
      $scope.withInvitedList = data;
      console.log(data);
    });


    //accepted invitaion

    $http.get("/friend?with="+currentUser.id+"&invitation_status=accepted").success(function(data, status, headers, config) {
      $scope.myAcceptedInvitationList = data;
      console.log('accepted invitation received-----------------------',data);
    });

    $scope.acceptRequest = function(frndId, requestedUserId){
      console.log("sending invitation request");
      var queryString = {"me" : requestedUserId, "with" : currentUser.id, "invitation_status" : "accepted"};

      //update
      $http.put('/friend/update/'+frndId+'?',queryString).
        success(function(data, status, headers, config) {
          console.log("successfully updated");
          console.log(data);
          $scope.invitation_status = data.invitation_status;
          $.each($scope.withInvitedList, function(index, value){
            if(this.id===frndId)
              $scope.withInvitedList[index].invitation_status = data.invitation_status;
          });

          $.each($scope.meInvitedList, function(index, value){
            if(this.id===frndId)
              $scope.meInvitedList[index].invitation_status = data.invitation_status;

            console.log(meInvitedList);
          });

        }).
        error(function(data, status, headers, config) {
          // called asynchronously if an error occurs
          // or server returns response with an error status.
        });
    }

    $scope.declineRequest = function(frndId, requestedUserId){
      //console.log('muri khabo');

      var queryString = {"me" : requestedUserId, "with" : currentUser.id, "invitation_status" : "declined"};

      //update
      $http.put('/friend/update/'+frndId+'?',queryString).
        success(function(data, status, headers, config) {
          console.log("successfully updated");
          console.log(data);
          $scope.invitation_status = data.invitation_status;
          $.each($scope.withInvitedList, function(index, value){
            if(this.id===frndId)
              $scope.withInvitedList[index].invitation_status = data.invitation_status;
          });
        }).
        error(function(data, status, headers, config) {
          // called asynchronously if an error occurs
          // or server returns response with an error status.
        })

    };


    $scope.removeFavorite=function(profile,dex){
        //console.log('asce',profile);
        var queryString ={"with" : profile.with.id, "me" :profile.me.id, "invitation_status" : "withdraw"};
      //update

      $http.put('/friend/update/'+profile.id+'?',queryString).
        success(function(data, status, headers, config) {
          //console.log("successfully updated");
          //console.log(data);
          $scope.myAcceptedInvitationList.splice(dex,1);


          $scope.invitation_status = data.invitation_status;
          $.each($scope.meInvitedList, function(index, value){
            if(this.id===frndId)
              $scope.meInvitedList[index].invitation_status = data.invitation_status;
          });
        }).
        error(function(data, status, headers, config) {
          // called asynchronously if an error occurs
          // or server returns response with an error status.
        })


    }




  }]);
