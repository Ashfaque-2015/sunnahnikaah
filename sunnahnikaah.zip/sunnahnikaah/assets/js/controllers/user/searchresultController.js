angular.module('app')
  .controller('SearchResultController', ['$scope', function($scope) {









    }]);
