angular.module('app')
  .controller('MyaccountDashboardController', ['$http', '$scope', '$state', '$rootScope', 'CurrentUser', 'Chat', '$modal', '$log','toastr', function($http, $scope,$state,$rootScope,CurrentUser,Chat, $modal,$log,toastr) {
    CurrentUser.setBodyClass();

    console.log($state.current.data);
    $scope.demoAvatarMale = "images/user/profile-pic-male.png";
    $scope.demoAvatarFemale = "images/user/profile-pic-female.png";


    //chat disconnect modal
    $scope.items = ['item1', 'item2', 'item3'];

    $scope.animationsEnabled = true;

    $scope.showDialogAtAutoDisconnectChatServer = function (size) {

      //var modalInstance = $modal.open({
      //  animation: $scope.animationsEnabled,
      //  //templateUrl: 'templates/other/modalChatDisconnect.html',
      //  template: '<h2>Chat Server Disconnected</h2><p>Reconnecting...</p>',
      //  controller: 'ChatDisconnectModalInstanceCtrl',
      //  size: size,
      //  resolve: {
      //    items: function () {
      //      return $scope.items;
      //    }
      //  }
      //});
      //
      //console.log(modalInstance);
      //
      //modalInstance.result.then(function (selectedItem) {
      //  $scope.selected = selectedItem;
      //}, function () {
      //  $log.info('Modal dismissed at: ' + new Date());
      //});

      toastr.error('Chat Server Disconnected...','Disconnected!', {
        closeButton: true
      });

    };

    $scope.autoDisconnectChatServerNotification_cb = function(){
      //console.log("here come");
      $scope.showDialogAtAutoDisconnectChatServer();
    }

    var currentUser = CurrentUser.user();
    console.log("currentUser",currentUser);

    if(currentUser.hasOwnProperty("jid") && currentUser.jid != "" && currentUser.hasOwnProperty("jpassword") && currentUser.jpassword != ""){
      Chat.connect_me_now(currentUser.jid, currentUser.jpassword,$scope.autoDisconnectChatServerNotification_cb);
      //initialize roster
      $scope.$emit("eventInitializeRoster");
      toastr.success('Chat Server Connected...','Connected!', {
        closeButton: true
      });
    }


    //if(!$state.current.data.hideSidebar){
    //  $rootScope.hideSidebar = false;
    //}


    $scope._calculateAge = function(dob_timestamp) { // birthday is a date
      var ageDifMs = Date.now() - dob_timestamp;
      var ageDate = new Date(ageDifMs); // miliseconds from epoch
      return Math.abs(ageDate.getUTCFullYear() - 1970);
    }
    $scope.viewProfiles = [];

    $scope.whoHasViewedMyProfile = function(){

      $http.post('/viewprofile/find',{me:currentUser.id})
        .success(function (data, status, headers, config) {
          //console.log(data);
          //console.log(data.length);
          var i=0,j=0,k=0;
          if(data.length) {
            //$scope.viewProfiles = data;
            $scope.viewProfiles = [];
            for(i=0,k=0; i<data.length;k++){
              $scope.viewProfiles[k] =[];
              for(j=0; i<data.length && j<4 ;j++,i++){
                data[i].visitor.age = $scope._calculateAge(data[i].visitor.dob_timestamp);
                data[i].visitor_country = data[i].visit_time_ip[0].country;
                $scope.viewProfiles[k][j] = data[i];
              }
              if(j<4){
                for(; j<4 ;j++){
                  $scope.viewProfiles[k][j] = {};
                }
              }
            }

            //$http.get('/friend?me='+currentUser.id).success(function(data,status,headers, config){
            //  console.log('response',data);
            //
            //  var i = 1;
            //  $scope.viewProfiles[0].forEach(function(val){
            //
            //    console.log("i am value "+i+" ",val.visitor.id);
            //    i +=1;
            //  });
            //
            //  //for(var val in $scope.viewProfiles[0]){
            //  //  console.log("i am value "+i+" "+val);
            //  //  i +=1;
            //  //}
            //
            //});

            console.log('-----------------------------------------',$scope.viewProfiles);
          }
        })
        .error(function (err, data, status, headers, config) {
        });
    };

    //quick view modal

    $scope.open = function (size,profileId) {

      var modalInstance = $modal.open({
        animation: true,
        templateUrl: 'templates/user/quick_view_profile.html',
        controller: 'QuickViewProfileController',
        size: size,
        resolve: {
          profId: function () {
            return profileId;
          }
        }
      });

      modalInstance.result.then(function (selectedItem) {
        $scope.selected = selectedItem;
      }, function () {
        $log.info('Modal dismissed at: ' + new Date());
      });
    };

    //quick view modal end

    //fav

    $scope.checkFavStatus = function(item){
      console.log('item',item);

      return false;
    }


    //$scope.favorite_status = false;
    //
    //$http.get('/user/' + currentUser.id).success(function(response) {
    //  $scope.current_user = response;
    //  //check already listed as friend
    //  $.each($scope.current_user.my_friends, function( index, value ) {
    //    if(value.with==other_user_id){
    //      alreadyExistId=value.id;
    //      if(value.invitation_status)
    //        $scope.invitation_status = value.invitation_status;
    //      if(value.favorite_status)
    //        $scope.favorite_status = value.favorite_status;
    //      if(value.show_photo_status)
    //        $scope.show_photo_status = value.show_photo_status;
    //    }
    //  });
    //});

    //$scope.favoriteProfileById = function(other_user){
    //
    //  var queryString = {"me":currentUser.id,"with":other_user.id,"favorite_status":"true"};
    //
    //  if(alreadyExistId){
    //    //update
    //    $http.put('/friend/update/'+alreadyExistId+'?',queryString).
    //
    //      success(function(data, status, headers, config) {
    //        //console.log("successfully updated");
    //        //console.log(data);
    //        $scope.favorite_status = data.favorite_status;
    //      }).
    //      error(function(data, status, headers, config) {
    //        // called asynchronously if an error occurs
    //        // or server returns response with an error status.
    //      });
    //  }else{
    //    //create new
    //
    //    $http.post("/friend/create",queryString).
    //      success(function(data, status, headers, config) {
    //        // this callback will be called asynchronously
    //        // when the response is available
    //        //console.log("friend record created")
    //        //console.log(data);
    //        $scope.favorite_status = data.favorite_status;
    //      }).
    //      error(function(data, status, headers, config) {
    //        // called asynchronously if an error occurs
    //        // or server returns response with an error status.
    //      });
    //  }
    //}
    //
    //$scope.unfavoriteProfileById = function(other_user){
    //
    //  var queryString = {"me":currentUser.id,"with":other_user.id,"favorite_status":"false"};
    //
    //  if(alreadyExistId){
    //    //update
    //    $http.put('/friend/update/'+alreadyExistId+'?',queryString).
    //
    //      success(function(data, status, headers, config) {
    //        console.log("successfully updated");
    //        console.log(data);
    //        $scope.favorite_status = data.favorite_status;
    //      }).
    //      error(function(data, status, headers, config) {
    //        // called asynchronously if an error occurs
    //        // or server returns response with an error status.
    //      });
    //  }else{
    //    //create new
    //    $http.post("/friend/create",queryString).
    //      success(function(data, status, headers, config) {
    //        // this callback will be called asynchronously
    //        // when the response is available
    //        console.log("friend record removed");
    //        //console.log(data);
    //
    //        $scope.favorite_status = data.favorite_status;
    //      }).
    //      error(function(data, status, headers, config) {
    //        // called asynchronously if an error occurs
    //        // or server returns response with an error status.
    //      });
    //  }
    //};

    //fav end



    $scope.whoHasViewedMyProfile();

    $scope.myInterval = 50000;
    $scope.noWrapSlides = false;

  }]);
