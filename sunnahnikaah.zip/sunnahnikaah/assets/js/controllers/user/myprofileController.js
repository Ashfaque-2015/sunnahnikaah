angular.module('app')
  .controller('MyProfileController', ['$scope', 'CurrentUser', '$http', 'Options', '$timeout', function ($scope, CurrentUser, $http, Options,$timeout) {

    var currentUser = CurrentUser.user();
    $scope.currentUser = CurrentUser.user();
    $scope.alerts = [];
    $scope.fileLoc;

    console.log(currentUser);


    $scope.fileLoc = "images/demo-profile-pic.png";

    $http.get('/user/' + currentUser.id).success(function (response) {

      $scope.profile = response;
      $scope.dt = response.dob;
      $scope.profile.photo = $scope.myPhoto($scope.profile.gender);
      //$scope.profile.gender;
    });

    //todo: country will be populated from countries json from bower components
    //$http.get('/bower_components/countries/countries.min.json').
    //  success(function(data, status, headers, config) {
    //    $scope.continents=data.continents;
    //    $scope.countries=data.countries;
    //  });

    //todo: country will be fetch from Options service
    //Options.getAllContinents();
    //console.log(Options.getAllContinents());
    //console.log("======");


    /*   $http.get('/profile?user='+currentUser.id).

     success(function(response) {
     $scope.user_profile=  response;

     }).
     error(function(data, status, headers, config) {

     });
     */


    $scope.updateProfile = function () {
      $scope.profile.dob = $scope.dt;

      // check description length
      if ($scope.profile.details) {
        if ($scope.profile.details.split(" ").length < 10 && !$scope.profile.details === '') {
          $scope.alerts.push({type: 'danger', msg: 'Write at least 50 words about you'});
          return;
        }
      }
      //
      //delete me_with field to avoid error
      delete $scope.profile.me_with;
      delete $scope.profile.my_friends;
      //

      //console.log($scope.profile);
      //alert($scope.user);
      //  $http.put('/user/update/'+currentUser.id+'?details='+$scope.user.details).
      $http.post('/user/update/' + currentUser.id, $scope.profile).

        success(function (data, status, headers, config) {
          //console.log("successfully updated");
          $scope.alerts.push({
            type: 'success',
            msg: 'Well done! You have successfully updated profile for ' + data.username
          });
          $timeout(hide, 2000);
        }).
        error(function (data, status, headers, config) {
          //console.log('err data', data);
          //console.log('err status', status);
          // called asynchronously if an error occurs
          // or server returns response with an error status.
          $scope.alerts.push({type: 'danger', msg: 'Oh snap! Failed to update profile.'});
        });
    };

    function hide(){
      $("#alert").fadeOut(2000);
    }
    //datepicker
    $scope.today = function () {
      $scope.dt = new Date();
    };
    //$scope.today();

    $scope.clear = function () {
      $scope.dt = null;
    };

    // Disable weekend selection
    $scope.disabled = function (date, mode) {
      return ( mode === 'day' && ( date.getDay() === 0 || date.getDay() === 6 ) );
    };

    $scope.toggleMin = function () {
      $scope.minDate = $scope.minDate ? null : new Date();
    };
    $scope.toggleMin();

    $scope.open = function ($event) {
      $event.preventDefault();
      $event.stopPropagation();

      $scope.opened = true;
    };

    $scope.dateOptions = {
      formatYear: 'yy',
      startingDay: 1
    };

    $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
    $scope.format = $scope.formats[2];


    $scope.myPhoto = function myPhoto(gender) {

      console.log(gender);

      if (gender === "female") {
        $scope.fileLoc = "images/user/profile-pic-female.png";
      }
      else {
        //alert("vagmu naaa");
        $scope.fileLoc = "images/user/profile-pic-male.png";
      }
    };

    $scope.closeAlert = function (index) {
      $scope.alerts.splice(index, 1);
    };


  }]);
