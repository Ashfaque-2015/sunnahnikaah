angular.module('app')
  .controller('PhotoRequestController', ['$scope', '$stateParams', 'CurrentUser', '$http', function($scope, $stateParams, CurrentUser, $http) {
    var currentUser = CurrentUser.user();
    $scope.demoAvatar = "images/demo-profile-pic.png";
    $scope.meRequestedList = [];
    $scope.withRequestedList = [];
    $scope.show_photo_status = "pending";

    //I requested
    $http.get("/friend?me="+currentUser.id+"&show_photo_status=pending").success(function(data, status, headers, config) {
      $scope.meRequestedList = data;
    });

    //Requested me
    $http.get("/friend?with="+currentUser.id+"&show_photo_status=pending").success(function(data, status, headers, config) {
      $scope.withRequestedList = data;
    });


    $scope.acceptRequest = function(frndId, requestedUserId){
    console.log("sending photo request");
    var queryString = {"me" : requestedUserId, "with" : currentUser.id, "show_photo_status" : "accepted"};

      //update
      $http.put('/friend/update/'+frndId+'?',queryString).
        success(function(data, status, headers, config) {
          console.log("successfully updated");
          console.log(data);
          $scope.show_photo_status = data.show_photo_status;
          $.each($scope.withRequestedList, function(index, value){
            if(this.id===frndId)
              $scope.withRequestedList[index].show_photo_status = data.show_photo_status;
          });
        }).
        error(function(data, status, headers, config) {
          // called asynchronously if an error occurs
          // or server returns response with an error status.
        });
    };

    $scope.declineRequest = function(frndId, requestedUserId){
      console.log('muri khabo');

      var queryString = {"me" : requestedUserId, "with" : currentUser.id, "show_photo_status" : "declined"};

      //update
      $http.post('/friend/update/'+frndId,queryString).
        success(function(data, status, headers, config) {
          console.log("successfully updated");
          console.log(data);
          $scope.show_photo_status = data.show_photo_status;
          $.each($scope.withRequestedList, function(index, value){
            if(this.id===frndId)
              $scope.withRequestedList[index].show_photo_status = data.show_photo_status;
          });
        }).
        error(function(data, status, headers, config) {
          // called asynchronously if an error occurs
          // or server returns response with an error status.
        })

    };

    $scope.withdrawRequest = function(profile){

      console.log("withdraw photo request",profile);
      var queryString = {"me": profile.me.id, "with": profile.with.id, "show_photo_status": "withdrawn"};

        console.log(queryString);
      $http.post('/friend/update/'+profile.id,queryString).
          success(function (data, status, headers, config) {
            // this callback will be called asynchronously
            // when the response is available
            console.log(data);
            $scope.show_photo_status = data.show_photo_status;

          }).
          error(function (data, status, headers, config) {
            // called asynchronously if an error occurs
            // or server returns response with an error status.
          });
      }


  }]);
