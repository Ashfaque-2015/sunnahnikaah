angular.module('app')
  .controller('ViewProfileController', function($scope, $stateParams, CurrentUser, $http) {

    var currentUser = CurrentUser.user();
    var other_user_id = $stateParams.other_user_id;
    var alreadyExistId = false;
    $scope.currentUser = currentUser;


    $scope.storeVisitStatistics = function(me_id, who_visit_me_id){
      if(me_id != who_visit_me_id){ // will not save my own record
        $http.post('/viewprofile/storeVisitStat',{me:who_visit_me_id,visitor:me_id})
          .success(function (data, status, headers, config) {
          });
      }
    };


    $scope.invitation_status = false;
    $scope.favorite_status = false;
    $scope.show_photo_status = "not_send";

    $scope.fileLoc = "images/demo-profile-pic.png";

    $http.get('/user/' + currentUser.id).success(function(response) {
      $scope.current_user = response;
      //check already listed as friend
      $.each($scope.current_user.my_friends, function( index, value ) {
        if(value.with==other_user_id){
          alreadyExistId=value.id;
          if(value.invitation_status)
            $scope.invitation_status = value.invitation_status;
          if(value.favorite_status)
            $scope.favorite_status = value.favorite_status;
          if(value.show_photo_status)
            $scope.show_photo_status = value.show_photo_status;
        }
      });
    });

    $http.get('/user/' + other_user_id).success(function(response) {

      $scope.profile = response;
      $scope.profile.myprofile_height = $scope.heightFormat($scope.profile.myprofile_height );
      $scope.profile.dob=$scope.calculateAge($scope.profile.dob_timestamp);
      $scope.profile.photo=$scope.myPhoto($scope.profile.gender);

      $scope.storeVisitStatistics(currentUser.id, response.id);

    });

    ////check already invited or favorite

    //$scope.friend={}
    //var queryString1 = {"me":currentUser.id,"with":other_user_id};
    //var queryString2 = 'me='+currentUser.id+'with='+other_user_id;
    //
    //console.log(queryString1);
    ////$http.get("/friend/find",queryString1).success(function(data, status, headers, config) {
    //$http.get("/friend/search?"+queryString2).success(function(data, status, headers, config) {
    //  // this callback will be called asynchronously
    //  // when the response is available
    //  console.log("friend search success see data as below")
    //  console.log(data)
    //  if(data){
    //    $scope.invitation_status = data[0].invitation_status;
    //    console.log("already friend");
    //    console.log(data);
    //    $scope.friend =data[0];
    //  }
    //})

    $scope.heightFormat = function heightFormat(height) {
      if(height){
        var heights = height.split('_');
        return Number(heights[0]) + " feet " + Number(heights[1]) + " inch";
      }
      else{
        return "";
      }
    };

    //invitation process
    $scope.sendInvitation = function(){
      console.log("sending invitation");
      var queryString = {"me": currentUser.id, "with": other_user_id, "invitation_status": "pending"};

      if(alreadyExistId){
        //update
        $http.put('/friend/update/'+alreadyExistId+'?',queryString).

          success(function(data, status, headers, config) {
            console.log("successfully updated");
            console.log(data);
            $scope.invitation_status = data.invitation_status;

          }).
          error(function(data, status, headers, config) {
            // called asynchronously if an error occurs
            // or server returns response with an error status.
          });
      }else {
        //create new

        console.log(queryString);
        $http.post("/friend/create", queryString).
          success(function (data, status, headers, config) {
            // this callback will be called asynchronously
            // when the response is available
            console.log(data);
            $scope.invitation_status = data.invitation_status;

          }).
          error(function (data, status, headers, config) {
            // called asynchronously if an error occurs
            // or server returns response with an error status.
          });
      }
    };

    $scope.cancelInvitation = function(){
      console.log("canceling invitation");
      var queryString = {"me": currentUser.id, "with": other_user_id, "invitation_status": "withdrawn"};

      if(alreadyExistId){
        //update
        $http.put('/friend/update/'+alreadyExistId+'?',queryString).

          success(function(data, status, headers, config) {
            console.log("successfully updated");
            console.log(data);
            $scope.invitation_status = data.invitation_status;

          }).
          error(function(data, status, headers, config) {
            // called asynchronously if an error occurs
            // or server returns response with an error status.
          });
      }else {
        //create new

        console.log(queryString);
        $http.post("/friend/create", queryString).
          success(function (data, status, headers, config) {
            // this callback will be called asynchronously
            // when the response is available
            console.log(data);
            $scope.invitation_status = data.invitation_status;

          }).
          error(function (data, status, headers, config) {
            // called asynchronously if an error occurs
            // or server returns response with an error status.
          });
      }
    };

    //favorite process
    $scope.favoriteProfile = function(){

      var queryString = {"me":currentUser.id, "with": other_user_id, "favorite_status": true};

      if(alreadyExistId){
        //update
        $http.put('/friend/update/'+alreadyExistId+'?',queryString).

          success(function(data, status, headers, config) {
            console.log("successfully updated");
            console.log(data);
            $scope.favorite_status = data.favorite_status;
          }).
          error(function(data, status, headers, config) {
            // called asynchronously if an error occurs
            // or server returns response with an error status.
          });
      }else{
        //create new

        $http.post("/friend/create",queryString).
          success(function(data, status, headers, config) {
            // this callback will be called asynchronously
            // when the response is available
            console.log("friend record created");
            console.log(data);
            $scope.favorite_status = data.favorite_status;
          }).
          error(function(data, status, headers, config) {
            // called asynchronously if an error occurs
            // or server returns response with an error status.
          });
      }
    };

    $scope.unfavoriteProfile = function(){

      var queryString = {"me":currentUser.id,"with":other_user_id,"favorite_status":false};

      if(alreadyExistId){
        //update
        $http.put('/friend/update/'+alreadyExistId+'?',queryString).

          success(function(data, status, headers, config) {
            console.log("successfully updated");
            console.log(data);
            $scope.favorite_status = data.favorite_status;
          }).
          error(function(data, status, headers, config) {
            // called asynchronously if an error occurs
            // or server returns response with an error status.
          });
      }else{
        //create new
        $http.post("/friend/create",queryString).
          success(function(data, status, headers, config) {
            // this callback will be called asynchronously
            // when the response is available
            console.log("friend record removed");
            //console.log(data);

            $scope.favorite_status = data.favorite_status;
          }).
          error(function(data, status, headers, config) {
            // called asynchronously if an error occurs
            // or server returns response with an error status.
          });
      }
    };

    //photo request
    $scope.photoRequest = function(){
      console.log("sending photo request");
      var queryString = {"me": currentUser.id, "with": other_user_id, "show_photo_status": "pending"};

      if(alreadyExistId){
        //update
        $http.put('/friend/update/'+alreadyExistId+'?',queryString).

          success(function(data, status, headers, config) {
            console.log("successfully updated");
            console.log(data);
            $scope.show_photo_status = data.show_photo_status;

          }).
          error(function(data, status, headers, config) {
            // called asynchronously if an error occurs
            // or server returns response with an error status.
          });
      }else {
        //create new

        console.log(queryString);
        $http.post("/friend/create",queryString).
          success(function (data, status, headers, config) {
            // this callback will be called asynchronously
            // when the response is available
            console.log(data);
            $scope.show_photo_status = data.show_photo_status;

          }).
          error(function (data, status, headers, config) {
            // called asynchronously if an error occurs
            // or server returns response with an error status.
          });
      }
    };

    $scope.cancelPhotoRequest = function(){
      console.log("canceling photo request");
      var queryString = {"me": currentUser.id, "with": other_user_id, "show_photo_status": "withdrawn"};

      if(alreadyExistId){
        //update
        $http.put('/friend/update/'+alreadyExistId+'?',queryString).

          success(function(data, status, headers, config) {
            console.log("successfully cancelled");
            //console.log(data);
            $scope.show_photo_status = data.show_photo_status;
          }).
          error(function(data, status, headers, config) {
            // called asynchronously if an error occurs
            // or server returns response with an error status.
          });
      }else {
        //create new

        console.log(queryString);
        $http.post("/friend/create", queryString).
          success(function (data, status, headers, config) {
            // this callback will be called asynchronously
            // when the response is available
            console.log(data);
            $scope.show_photo_status = data.show_photo_status;

          }).
          error(function (data, status, headers, config) {
            // called asynchronously if an error occurs
            // or server returns response with an error status.
          });
      }
    };

    $scope.calculateAge = function calculateAge(dob) { // birthday is a date


      console.log('ami aci');

        var ageDifMs = Date.now() -dob;//.getTime();
        //console.log(dob,"=====",ageDifMs);
        //console.log("=====",Date.now());
        //console.log("=====", ageDifMs);
        // console.log(dob);

        var ageDate = parseInt(ageDifMs/31557600000); // miliseconds from epoch


        return ageDate; //Number(Math.abs(ageDate.getUTCFullYear() - 1970));



  }

    $scope.myPhoto=function myPhoto(gender){

      console.log(gender);

      if(gender==="female"){
        $scope.fileLoc = "images/female avatar.png";
      }
      else{
        $scope.fileLoc = "images/demo-profile-pic.png";

      }

    }

  });
