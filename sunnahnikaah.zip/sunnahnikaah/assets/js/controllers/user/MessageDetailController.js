angular.module('app')
  .controller('MessageDetailController', ['$scope', '$rootScope', '$state', '$stateParams', 'CurrentUser', '$http', '$rootScope', 'Chat', '$filter', function ($scope, $rootScope, $state, $stateParams, CurrentUser, $http, $rootScope, Chat,$filter) {

    console.log($stateParams);
    $scope.username = null;
    $scope.emptyRoster = false;
    $scope.roster_thread_list = [];
    $scope.CurntUser = CurrentUser.user();
    $rootScope.currentChatUser = {};
    $scope.demoAvatar = "images/demo-profile-pic.png";
    $scope.demoAvatarMale = "images/user/profile-pic-male.png";
    $scope.demoAvatarFemale = "images/user/profile-pic-female.png";

    $scope.get_archive_data_cb = function (archiveMsgs) {
      //console.log("archivemsg",archiveMsgs);
      if (archiveMsgs.length) {
        var eachMsg = null;
        //console.log('archiveMsgs',archiveMsgs);

        var chatUserProfilePic = $rootScope.currentChatUser.myprofile_image?$rootScope.currentChatUser.myprofile_image:$rootScope.currentChatUser.gender=='male'?$scope.demoAvatarMale:$scope.demoAvatarFemale;
        var meProfilePic = $scope.CurntUser.myprofile_image?$scope.CurntUser.myprofile_image: $scope.CurntUser.gender=='male'?$scope.demoAvatarMale:$scope.demoAvatarFemale;

        archiveMsgs.forEach(function (item) {
          //console.log(item);

          //eachMsg = "<div class='chat-message'>&lt;";
          //if (item.from == $scope.CurntUser.jid)
          //  eachMsg += "<span class='chat-name me'>"
          //else
          //  eachMsg += "<span class='chat-name'>";
          //
          //eachMsg += Strophe.getNodeFromJid(item.from) +
          //"</span>&gt;<span class='chat-text'>" +
          //item.body +
          //"</span></div>";

          eachMsg = '<div class="media">'+
          '<span class="lastMsgTime">'+$filter('date')(item.createdAt, 'h:mma')+'</span>'+
                    '<div class="media-left">';
          if (item.from == $scope.CurntUser.jid)
            eachMsg +='<img class="media-object img-circle" src="'+meProfilePic+'" >';
          else
            eachMsg +='<img class="media-object img-circle" src="'+chatUserProfilePic+'" >';

          eachMsg +='</div>'+
                    '<div class="media-body">'+
                    '<h4 class="media-heading">'+Strophe.getNodeFromJid(item.from)+'</h4>'+
                    '<p>'+item.body +'</p>'+
                    '</div>'+
                    '</div>';


          $('#chat-message-' + $scope.jid_id).prepend(eachMsg);

        });

        var div = $('#chat-message-' + $scope.jid_id).get(0);
        div.scrollTop = div.scrollHeight;
      }
    };

    $scope.SendMessage = function (ev,sendBtnPress) {
      var jid = $scope.jid;

      if (ev.which === 13 || sendBtnPress) {
        ev.preventDefault();

        //console.log(this);

        var body = $('#chat-input-' + $scope.jid_id).val();
        var msgData = null;

        //console.log($('#chat-input-'+$scope.jid_id));
        //msgid is -1, cause now going to create new message
        Chat.update_message_archive(body, $scope.CurntUser.jid, jid, $scope.threadId, "sendmsg", -1, "notsure-viewing",$scope.SendMessage_cb);

      }
      else {
        var composing = $('#chat-input-' + $scope.jid_id).parent().data('composing');
        if (!composing) {
          var notify = $msg({to: jid, "type": "chat"})
            .c('composing', {xmlns: "http://jabber.org/protocol/chatstates"});
          Chat.connection.send(notify);

          $('#chat-input-' + $scope.jid_id).parent().data('composing', true);
        }
      }
    };

    $scope.SendMessage_cb = function (msgData, message) {
      var jid = $scope.jid;
      var eachMsg = "";

      var meProfilePic = $scope.CurntUser.myprofile_image?$scope.CurntUser.myprofile_image: $scope.CurntUser.gender=='male'?$scope.demoAvatarMale:$scope.demoAvatarFemale;

      var messageStanza = $msg({
        to: jid,
        "type": "chat"
      })
        .c('body').t(message).up()
        .c('active', {xmlns: "http://jabber.org/protocol/chatstates"}).up()
        .c('thread').t($scope.threadId).up()
        .c('msgid').t(msgData.message.id);

      //console.log(messageStanza);
      Chat.connection.send(messageStanza);

      //$('#chat-message-' + $scope.jid_id).append(
      //  "<div class='chat-message'>&lt;" +
      //  "<span class='chat-name me'>" +
      //  Strophe.getNodeFromJid(Chat.connection.jid) +
      //  "</span>&gt;<span class='chat-text'>" +
      //  message +
      //  "</span></div>");

      eachMsg = '<div class="media">'+
                '<span class="lastMsgTime">'+$filter('date')(msgData.message.createdAt, 'h:mma')+'</span>'+
                '<div class="media-left">';
      eachMsg +='<img class="media-object img-circle" src="'+meProfilePic+'" >';

      eachMsg +='</div>'+
                '<div class="media-body">'+
                '<h4 class="media-heading">'+Strophe.getNodeFromJid(Chat.connection.jid)+'</h4>'+
                '<p>'+message +'</p>'+
                '</div>'+
                '</div>';

      $('#chat-message-' + $scope.jid_id).append(eachMsg);


      $scope.$emit('eventLastMessageUpdate', {message: message, jid_id : $scope.jid_id,roster_class:"current-thread-msg",thread:$scope.threadId });

      //scroll chat
      var div = $('#chat-message-' + $scope.jid_id).get(0);
      div.scrollTop = div.scrollHeight;

      $('#chat-input-' + $scope.jid_id).val('');
      $('#chat-input-' + $scope.jid_id).parent().data('composing', false);
    };

    $scope.getMessagesWithSelectedUser = function(username){

      $scope.jid_id = null;
      $scope.threadId = null;

      $http.get("/user?username=" + username)
        .success(function (data, status, headers, config) {
          if (data.length) {

            //saving globally so that we can use from message controller and nav controller
            $rootScope.currentChatUser = data[0];

            $scope.username = data[0].username;
            $scope.jid = data[0].jid;
            $scope.jid_id = Chat.jid_to_id(Strophe.getBareJidFromJid(data[0].jid));
            $('chat-input-' + $scope.jid_id).focus();

            //searching thread
            var search_params = {
              "user1": $scope.CurntUser.id,
              "user2": data[0].id,
              'me_jid': $scope.CurntUser.jid,
              'other_user_jid': data[0].jid,
              'reset_notification':true
            };

            //find thread, if not found then create one
            $http.post("/thread/findThread", search_params)
              .success(function (data2, status, headers, config) {
                console.log("data2",data2);
                //return;

                if (data2) {

                  //console.log(data2);

                  $scope.threadId = data2.id;
                  //console.log($scope.threadId);
                  $scope.$emit("eventDecreaseChatNotification", {thread: data2 }); //for base controller
                  $scope.$emit("eventUpdateThreadAndNotification", {thread: data2 }); //for message controller

                  //console.log("ekhane ki aise evet trigger korar por");
                  Chat.get_archive_data($scope.threadId, 20, 0, $scope.get_archive_data_cb);

                }
                // else{
                //   newThread = {"me": $scope.CurntUser.id, "other_user": data[0].id,'me_jid':$scope.CurntUser.jid,'other_user_jid':data[0].jid};
                //   $http.post("/thread/create",newThread).success(function(data3, status, headers, config){
                //     console.log(data3);
                //     $scope.threadId = data3.id;
                //     $scope.updateRoster(data[0].id, $scope.threadId);
                //   });
                // }

                //$scope.threadId

              });
          }
          else{
            $scope.username = null;
            $scope.emptyRoster = true;
          }
        });
    };

    //find last chat user
    $scope.defaultMessageRouter = function(){
      var currentUser = CurrentUser.user();
      $http.get('/user/' + CurrentUser.user().id)
        .success(function (data) {
          //find threads
          if (data.threads1.length) {
            data.threads1.forEach(function (eachObj) {
              $scope.roster_thread_list.push(eachObj);
            });
          }
          if (data.threads2.length) {
            data.threads2.forEach(function (eachObj) {
              $scope.roster_thread_list.push(eachObj);
            });
          }

          if($scope.roster_thread_list.length){
            //sorting threads based on updatedAt time
            $scope.roster_thread_list.sort($scope.compare);

            $scope.defaultChatUser = $scope.roster_thread_list.shift();

            //console.log($scope.defaultChatUser);
            if($scope.defaultChatUser.me != CurrentUser.user().id){
              $http.get('/user/' + $scope.defaultChatUser.me)
                .success(function (data2) {
                  //$state.go('base.user.messages.detail',{ username: data2.username });
                  $scope.username = data2.username;
                  $scope.getMessagesWithSelectedUser(data2.username);
                  //$stateParams.username = data2.username;
                  //console.log($stateParams);
                });
            }
            else if($scope.defaultChatUser.other_user != CurrentUser.user().id){
              $http.get('/user/' + $scope.defaultChatUser.other_user)
                .success(function (data2) {
                  //$state.go('base.user.messages.detail',{ username: data2.username });
                  $scope.username = data2.username;
                  $scope.getMessagesWithSelectedUser(data2.username);
                  //$stateParams.username = data2.username;
                  //console.log($stateParams);
                });
            }
          }
          else{
            //there is no previous thread so show empty page
            $scope.emptyRoster = false;
          }
        });
    };

    //================chat on message handler=======================//
    $scope.on_message_detail = function (message) {
      console.log('on_message_detail');
      console.log(message);
      var full_jid = $(message).attr('from');
      var jid = Strophe.getBareJidFromJid(full_jid);
      var jid_id = Chat.jid_to_id(jid);
      var chatUserProfilePic = $rootScope.currentChatUser.myprofile_image?$rootScope.currentChatUser.myprofile_image: $scope.currentChatUser.gender=='male'?$scope.demoAvatarMale:$scope.demoAvatarFemale;

      if (jid_id == $scope.jid_id) {
        var composing = $(message).find('composing');
        if (composing.length > 0) {
          $('#chat-message-' + $scope.jid_id).append(
            "<div class='chat-event'>" +
            Strophe.getNodeFromJid(jid) +
            " is typing...</div>");

          //scroll chat
          var div = $('#chat-message-' + $scope.jid_id).get(0);
          div.scrollTop = div.scrollHeight;
        }

        var body = $(message).find("html > body");
        var threadId = $(message).find('thread').text();

        if (body.length === 0) {
          body = $(message).find('body');
          if (body.length > 0) {
            body = body.text()
          } else {
            body = null;
          }
        }
        else {
          body = body.contents();

          var span = $("<span></span>");
          body.each(function () {
            if (document.importNode) {
              $(document.importNode(this, true)).appendTo(span);
            } else {
              // IE workaround
              span.append(this.xml);
            }
          });

          body = span;
        }

        if (body) {
          // remove notifications since user is now active
          $('#chat-message-' + $scope.jid_id + ' .chat-event').remove();

          // add the new message
          //$('#chat-message-' + $scope.jid_id).append(
          //  "<div class='chat-message'>" +
          //  "&lt;<span class='chat-name'>" +
          //  Strophe.getNodeFromJid(jid) +
          //  "</span>&gt;<span class='chat-text'>" +
          //  "</span></div>");
          //
          //$('#chat-message-' + $scope.jid_id + ' .chat-message:last .chat-text')
          //  .append(body);

          eachMsg = '<div class="media">'+
          '<div class="media-left">';
          eachMsg +='<img class="media-object img-circle" src="'+chatUserProfilePic+'" >';

          eachMsg +='</div>'+
          '<div class="media-body">'+
          '<h4 class="media-heading">'+Strophe.getNodeFromJid(jid)+'</h4>'+
          '<p>'+body +'</p>'+
          '</div>'+
          '</div>';

          $('#chat-message-' + $scope.jid_id).append(eachMsg);

          console.log("nishchoi ekhan theke trigger korche");
          $scope.$emit('eventLastMessageUpdate', {message: body, jid_id : $scope.jid_id,roster_class:"current-thread-msg",thread: threadId});

          //scroll chat
          var div = $('#chat-message-' + $scope.jid_id).get(0);
          div.scrollTop = div.scrollHeight;
        }
      }

      return true;
    };

    if(Chat.connection){
      //if(!Chat.handlersObj.hasOwnProperty('m_messagedetailctl_on_message_detail') ){
        var onmsghandler =  Chat.connection.addHandler($scope.on_message_detail, null, "message", "chat");
        if(onmsghandler){
          Chat.handlers.push({m_messagedetailctl_on_message_detail:onmsghandler});
          Chat.handlersObj.m_messagedetailctl_on_message_detail = onmsghandler;
        }
      //}
    }


    //================end of chat on message handler=======================//

    if((!$stateParams.hasOwnProperty("username")) || $stateParams.username == "" ) {
      $scope.defaultMessageRouter();
    }

    if($stateParams.hasOwnProperty("username") && $stateParams.username != ""){
      $scope.getMessagesWithSelectedUser($stateParams.username);
    }

    //Chat.connect_me_now($scope.CurntUser.jid,$scope.CurntUser.jpassword);

    angular.element(document).ready(function () {

      //$(document).on('click', '.roster-contact', function () {
      //  var jid = $(this).find(".roster-jid").text();
      //  var name = $(this).find(".roster-name").text();
      //  var jid_id = Chat.jid_to_id(jid);
      //
      //  if ($('#chat-' + jid_id).length === 0) {
      //    $('.chat-cont-inner2').append('' +
      //    '<div class="chat-area-item2" data-jid="' + jid + '" id="chat-' + jid_id + '">' +
      //    '<h4 class="chat-item-title">' + name + '<span class="btn-icon-remove"><i class="fa fa-remove"></i></span></h4>' +
      //    '<div class="chat-messages" id="chat-message-' + jid_id + '"></div>' +
      //    '<input type="text" class="chat-input" id="chat-input-' + jid_id + '">' +
      //    '</div>');
      //  }
      //
      //  $(".chat-area-item2").each(function () {
      //    $(this).css("display", "none");
      //  });
      //
      //  $('#chat-' + jid_id).css("display", "block");
      //  //$('#chat-' + jid_id).css("height","300px");
      //  //$('#chat-' + jid_id).css("margin-top","-250px");
      //  $('#chat-' + jid_id + ' input').focus();
      //
      //  //place the calculated height for chat area
      //  var chatAreaHeight = $(window).height();// $('.chat-area-item2').height();
      //  chatAreaHeight = chatAreaHeight - $(".chat-area-item2 .chat-item-title").height() - $(".chat-area-item2 .chat-input").height() - $("#main_nav").height() - 28;
      //
      //  $('.chat-area-item2 .chat-messages').height(chatAreaHeight);
      //
      //});

      $('#chat_dialog').dialog({
        autoOpen: false,
        draggable: false,
        modal: true,
        title: 'Start a Chat',
        buttons: {
          "Start": function () {
            var jid = $('#chat-jid').val().toLowerCase();
            var jid_id = Chat.jid_to_id(jid);

            //$('#chat-area').tabs('add', '#chat-' + jid_id, jid);
            $("<li><a href='/remote/tab.html'>New Tab</a></li>")
              .appendTo("#chat-area .ui-tabs-nav");
            $('#chat-area').tabs("refresh");

            $('#chat-' + jid_id).append(
              "<div class='chat-messages'></div>" +
              "<input type='text' class='chat-input'>");

            $('#chat-' + jid_id).data('jid', jid);

            //$('#chat-area').tabs('select', '#chat-' + jid_id);
            $("#chat-area").tabs("option", "active", 2);

            $('#chat-' + jid_id + ' input').focus();


            $('#chat-jid').val('');

            $(this).dialog('close');
          }
        }
      });
    });
  }]);
