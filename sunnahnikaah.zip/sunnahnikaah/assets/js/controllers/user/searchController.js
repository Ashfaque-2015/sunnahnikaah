angular.module('app').controller('SearchController', ['$scope', '$rootScope', '$state', 'LocalService', '$http', 'CurrentUser', '$modal', '$log', function ($scope,$rootScope, $state, LocalService, $http, CurrentUser,$modal,$log) {

  console.log($state.current.data.hideSidebar);
  console.log($rootScope.hideSidebar);


  if ($state.current.data.hideSidebar) {
    $rootScope.hideSidebar = true;
  }

  $scope.search = {};
  $scope.results = {};
  $scope.demoAvatarMale = "images/user/profile-pic-male.png";
  $scope.demoAvatarFemale = "images/user/profile-pic-female.png";
  //var last_search = LocalService.get('last_search');
  //$scope.results = last_search;
  $scope.results = [];
  //$scope.search.salah = 0;

  //Chat.connection.addHandler($scope.on_message2,null, "message", "chat");
  //
  //$scope.on_message2 = function(message){
  //  console.log("message at msg contl",message);
  //  return true;
  //};

  $scope.searchProfiles = function () {



    var tod = new Date().getTime();
    //console.log('toddd',tod);

    //var rdate = new Date(755200800000);
    //var ryear = rdate.getYear();
    //console.log('dob timestamp year',ryear);
    //console.log('dob timestamp year',CurrentUser.user().dob_timestamp);

    //$scope.mx = $scope.search.max_age;
    if ($scope.search.hasOwnProperty('max_age') && $scope.search.max_age !== "") {
        $scope.search.start_date = tod - (86400000 * 365 * $scope.search.max_age);
        //console.log('maxage is f', $scope.search.start_date);
    }

    else{
      if (CurrentUser.user().gender == 'male') {
        $scope.search.start_date = CurrentUser.user().dob_timestamp - (86400000 * 365 * 2);
        console.log('maxage is male', 10);
        //var rdate = new Date($scope.search.start_date);
        //var ryear = rdate.getYear();
        //console.log('start', ryear);
      }
      else {
        $scope.search.start_date = CurrentUser.user().dob_timestamp - (86400000 * 365 * 10);
        //console.log('maxage is female', 10);
      }
    }

    if ($scope.search.hasOwnProperty('min_age') && $scope.search.min_age !== "") {
      $scope.search.end_date = tod - (86400000 * 365 * $scope.search.min_age);
      //console.log('minage is f', $scope.search.end_date);
    }
    else {
      //console.log('minage is',10);
      if (CurrentUser.user().gender == 'male') {
        $scope.search.end_date = CurrentUser.user().dob_timestamp + (86400000 * 365 * 10);
        console.log('minage is male', 2);
        //var rdate = new Date($scope.search.end_date);
        //var ryear = rdate.getYear();
        //console.log('end', ryear);
      }
      else {
        $scope.search.end_date = CurrentUser.user().dob_timestamp + (86400000 * 365 * 2);
        console.log('minage is female', 10);
      }
    }

    //sending current user id with search params
    $scope.search.currentUserId = CurrentUser.user().id;

    if (CurrentUser.user().gender == 'male') {
      $scope.search.gender = 'female';

    }
    else {
      $scope.search.gender = 'male';
    }



    var qryString = $.param($scope.search);
    console.log('query string: ',qryString);

    //$http.get('/user/search?salah='+$scope.search.salah+'&built='+$scope.search.built).
    $http.post('/user/search?' + qryString).
      success(function (data, status, headers, config) {
        //console.log("successfull");
        //console.log(data);
        $scope.results = data;
        console.log('$scope.results',$scope.results);

      }).error(function (data, status, headers, config) {
        console.log('error data',data);
        // called asynchronously if an error occurs
        // or server returns response with an error status.
      });
  };

  $scope.searchProfiles();

  $scope.open = function (size,profileId) {

    var modalInstance = $modal.open({
      animation: true,
      templateUrl: 'templates/user/quick_view_profile.html',
      controller: 'QuickViewProfileController',
      size: size,
      resolve: {
        profId: function () {
          return profileId;
        }
      }
    });

    modalInstance.result.then(function (selectedItem) {
      $scope.selected = selectedItem;
    }, function () {
      $log.info('Modal dismissed at: ' + new Date());
    });
  };



  $scope.favoriteProfileById = function(other_user){

    var queryString = {"me":currentUser.id,"with":other_user.id,"favorite_status":"true"};

    if(alreadyExistId){
      //update
      $http.put('/friend/update/'+alreadyExistId+'?',queryString).

        success(function(data, status, headers, config) {
          //console.log("successfully updated");
          //console.log(data);
          $scope.favorite_status = data.favorite_status;
        }).
        error(function(data, status, headers, config) {
          // called asynchronously if an error occurs
          // or server returns response with an error status.
        });
    }else{
      //create new

      $http.post("/friend/create",queryString).
        success(function(data, status, headers, config) {
          // this callback will be called asynchronously
          // when the response is available
          //console.log("friend record created")
          //console.log(data);
          $scope.favorite_status = data.favorite_status;
        }).
        error(function(data, status, headers, config) {
          // called asynchronously if an error occurs
          // or server returns response with an error status.
        });
    }
  };

  $scope.unfavoriteProfileById = function(other_user){

    var queryString = {"me":currentUser.id,"with":other_user.id,"favorite_status":"false"};

    if(alreadyExistId){
      //update
      $http.put('/friend/update/'+alreadyExistId+'?',queryString).

        success(function(data, status, headers, config) {
          console.log("successfully updated");
          console.log(data);
          $scope.favorite_status = data.favorite_status;
        }).
        error(function(data, status, headers, config) {
          // called asynchronously if an error occurs
          // or server returns response with an error status.
        });
    }else{
      //create new
      $http.post("/friend/create",queryString).
        success(function(data, status, headers, config) {
          // this callback will be called asynchronously
          // when the response is available
          console.log("friend record removed");
          //console.log(data);

          $scope.favorite_status = data.favorite_status;
        }).
        error(function(data, status, headers, config) {
          // called asynchronously if an error occurs
          // or server returns response with an error status.
        });
    }
  };

  //fav end


  angular.element(document).ready(function () {

  });
}]);
