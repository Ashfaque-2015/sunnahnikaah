angular.module('app')
  .controller('MyPhotosController', ['$http', '$scope', '$upload', '$location', 'CurrentUser', function ($http, $scope, $upload,$location,CurrentUser) {

    $scope.fileLoc = [];
    $scope.loggedinUser = {};


    var currentUser = CurrentUser.user();

    $http.post('/user/find?id='+currentUser.id).success(function (data, status, headers, config) {
      $scope.loggedinUser = data;

      //console.log($scope.loggedinUser);
      $scope.myPhotos = [];
      if($scope.loggedinUser.my_photos.length)
        $scope.myPhotos = $scope.loggedinUser.my_photos;
    })
      .error(function (data, status, headers, config) {
      // called asynchronously if an error occurs
      // or server returns response with an error status.
    });

    //file uploading
    $scope.$watch('files', function () {
      $scope.upload($scope.files);
    });

    $scope.upload = function (files) {
      if (files && files.length) {
        for (var i = 0; i < files.length; i++) {
          var file = files[i];
          $upload.upload({
            url: '/file/myphotoupload',
            fields: {
              'userId': currentUser.id
            },
            file: file
          }).progress(function (evt) {
            //  $("#profile-img-cont").empty().html('<i class="fa fa-refresh fa-spin"></i>');
            var progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
            console.log('progress: ' + progressPercentage + '% ' +
            evt.config.file.name);
          }).success(function (data, status, headers, config) {
            //console.log('filename: ' + config.file.name + ' uploaded. Response: ' + JSON.stringify(data));
            $scope.myPhotos.push(data.newImageRecord);
            //console.log($scope.myPhotos);
            //console.log($scope.fileLoc);
          });
        }
        $('#show-success').show().fadeOut(4000);
      }
    };

    //changing profile pic
    $scope.chooseThis = function(imgId){
      console.log(imgId);
    };

    $scope.deleteThis = function(myphoto){
      console.log(myphoto);
      $http.post('/myphotos/deleteImage', {
        "myPhotoId": myphoto.id,
        "myPhotoPath": myphoto.img_path
      }).success(function (data){
        console.log(data);
        var index = $scope.myPhotos.indexOf(myphoto);


        $scope.myPhotos.splice(index, 1);


        console.log($scope.myPhotos);


      });

      //}).error(function (data, status, headers, config) {
      //  // called asynchronously if an error occurs
      //  // or server returns response with an error status.
      //});
    }

  }]);
