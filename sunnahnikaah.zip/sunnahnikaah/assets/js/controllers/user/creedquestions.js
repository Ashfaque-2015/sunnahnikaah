angular.module('app')
  .controller('CreedQuestionsController', ['$scope', 'CurrentUser', '$http', function ($scope, CurrentUser, $http) {

    $scope.alerts = [];

    var currentUser = CurrentUser.user();

    $http.get('/user/' + currentUser.id).success(function (response) {

      $scope.profile = response;
      console.log(response);

    });

    $scope.updateProfile = function () {

      //console.log($scope.profile);

      $scope.creedprof={};
      if($scope.profile.hasOwnProperty('$scope.profile.creedquestion_Celebriting_prophets_birthday')){
        $scope.creedprof.creedquestion_Celebriting_prophets_birthday=$scope.profile.creedquestion_Celebriting_prophets_birthday;
      }
      if($scope.profile.hasOwnProperty('$scope.profile.creedquestion_I_make_dua_to')){
        $scope.creedprof.creedquestion_I_make_dua_to=$scope.profile.creedquestion_I_make_dua_to;
      }
      if($scope.profile.hasOwnProperty('$scope.profile.creedquestion_My_Destiny_is')){
        $scope.creedprof.creedquestion_My_Destiny_is=$scope.profile.creedquestion_My_Destiny_is;
      }
      if($scope.profile.hasOwnProperty('$scope.profile.creedquestion_Where_is_Allah')){
        $scope.creedprof.creedquestion_Where_is_Allah=$scope.profile.creedquestion_Where_is_Allah;
      }
      if($scope.profile.hasOwnProperty('$scope.profile.creedquestion_my_shahada_means')){
        $scope.creedprof.creedquestion_my_shahada_means=$scope.profile.creedquestion_my_shahada_means;
      }

      $http.put('/user/update/' + currentUser.id , $scope.creedprof).

        success(function (data, status, headers, config) {
          //alert($scope.profile.details);
          $scope.alerts.push({
            type: 'success',
            msg: 'Well done! You have successfully updated creed questions for ' + data.username
          });
        }).
        error(function (data, status, headers, config) {
          $scope.alerts.push({type: 'danger', msg: 'Oh snap! Failed to update profile.'});
          //console.log(data);
          //console.log(status);
          //console.log(headers);
          //console.log(config);
        });
    };

    $scope.closeAlert = function (index) {
      $scope.alerts.splice(index, 1);
    };
  }]);
