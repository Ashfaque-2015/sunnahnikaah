angular.module('app')
  .controller('HomeController', ['$scope', '$rootScope', '$state', '$http', 'Auth', 'CurrentUser', '$translate', 'Chat', 'LocalService', '$timeout', 'ngAudio', function ($scope, $rootScope, $state, $http, Auth, CurrentUser, $translate, Chat, LocalService,$timeout,ngAudio) {
  //ui bootstrap carousal
    $scope.myInterval = 5000;
    $scope.noWrapSlides = false;

    //$scope.videoLink = "https://www.youtube.com/watch?v=JjD6igFa6bc";

  }]);
