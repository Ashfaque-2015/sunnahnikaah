angular.module('app')
  .controller('ArticleController', ['$scope', '$http', 'CurrentUser', '$state', '$document', function($scope,$http,CurrentUser,$state,$document) {
    $scope.isLoading = true;
    CurrentUser.setBodyClass();
    $scope.posts = {};
    $scope.currentPosts = {};
    $scope.categories = {};
    $scope.authors = {};
    $scope.tags = {};




    $http.get("/blogcategory").success(function(data, status){
      //console.log('category data: ',data);
      $scope.categories = data;
    });

    $scope.categoryShowHide = function(category){
      if(category.posts.length===0){
        return true;
      }
      return false;
    };

    $http.get("/author").success(function(data, status){
      //console.log('author data: ',data);
      $scope.authors = data;
    });

    $scope.authorShowHide = function(author){
      if(author.author_blogs.length===0){
        return true;
      }
      return false;
    };

    $http.get("/tag").success(function(data, status){
      //console.log('tag data: ',data);
      $scope.tags = data;
    });

    $scope.tagShowHide = function(tag){
      if(tag.blog_tags.length===0){
        return true;
      }
      return false;
    };

    $http.get('/blog').success(function(data, status){
      //console.log('blog data: ',data);
      $scope.posts = data;
      $scope.currentPosts = $scope.posts;
      $scope.isLoading = false;

      //square image
      var cw = $('.article-home-image').width();
      console.log('width',cw);
      $('.article-home-image').css({'height':cw+'px'});
      //
    });



    //$scope.loadArticleByCategory = function(category){
    //  //console.log('clicked Category id',category.id);
    //  $state.go('base.article.category',{cat_id:category.id,cat_slug:category.category_slug});
    //  //$http.get('/blog?post_category='+category.id).success(function(data,status){
    //  //  $scope.currentPosts = data;
    //  //});
    //};
    //
    //$scope.loadArticleByAuthor = function(author){
    //  $state.go('base.article.author',{author_slug:author.author_slug,author_id:author.id});
    //  //$http.get("/blog?post_author="+author.id).success(function(data, status){
    //  //  $scope.currentPosts = data;
    //  //});
    //};

    //$scope.goTo = function(post){
    //  $state.go('base.article.article_detail',{post_id:post.id,post_slug:post.post_title_slug});
    //}
    $scope.oneAtATime = true;

    $scope.groups = [
      {
        title: 'Dynamic Group Header - 1',
        content: 'Dynamic Group Body - 1'
      },
      {
        title: 'Dynamic Group Header - 2',
        content: 'Dynamic Group Body - 2'
      }
    ];

    $scope.items = ['Item 1', 'Item 2', 'Item 3'];

    $scope.addItem = function() {
      var newItemNo = $scope.items.length + 1;
      $scope.items.push('Item ' + newItemNo);
    };
    $scope.accordionStatus = [];
    for(var i = 0; i< 5; i++){
      $scope.accordionStatus[i] = {
        isFirstOpen: true,
        isFirstDisabled: false
      };
    }
    $scope.closeAccordion = function(){
      for(var i = 0; i< $scope.accordionStatus.length; i++){
        if($scope.accordionStatus[i].open){
          $scope.accordionStatus[i].open = false;
        }

      }
    }
    $scope.changeAccordion = function(){
      alert("ok");
    }

  }]);
