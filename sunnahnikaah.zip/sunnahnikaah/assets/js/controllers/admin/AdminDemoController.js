// angular.module('app')
//   .controller('AdminDemoController', function($scope,$http) {
//
//     $scope.gridOptions = {
//       enableFiltering: true,
//       flatEntityAccess: true,
//       showGridFooter: true
//     };
//
//     $scope.gridOptions.columnDefs = [
//       {name:'username'},
//       {name:'email'},
//       {name:'user_group', enableCellEdit: true}
//
//       // { name: 'user_group', displayName: 'user_group', editableCellTemplate: 'ui-grid/dropdownEditor', width: '20%',
//       //    cellFilter: 'mapGender', editDropdownValueLabel: 'name', editDropdownOptionsArray: [
//       //    { id: 1, name: 'user' },
//       //    { id: 2, name: 'admin' }
//       //  ] }
//     ];
//
//     $http.get('user/')
//       .success(function(data) {
//         $scope.gridOptions.data = data;
//       });
//
//     $scope.toggleFlat = function() {
//       $scope.gridOptions.flatEntityAccess = !$scope.gridOptions.flatEntityAccess;
//     }
//
//     });
//     // { name: 'gender', displayName: 'Gender', editableCellTemplate: 'ui-grid/dropdownEditor', width: '20%',
//     //    cellFilter: 'mapGender', editDropdownValueLabel: 'gender', editDropdownOptionsArray: [
//     //    { id: 1, gender: 'user' },
//     //    { id: 2, gender: 'admin' }
//     //  ] },

    // var app = angular.module('app', ['ngTouch', 'ui.grid', 'ui.grid.edit', 'addressFormatter']);
    //
    // angular.module('addressFormatter', []).filter('address', function () {
    //   return function (input) {
    //       return input.street + ', ' + input.city + ', ' + input.state + ', ' + input.zip;
    //   };
    // });

    angular.module('app').
    controller('AdminDemoController', ['$scope', '$http', function ($scope, $http) {
      $scope.gridOptions = {  };

      $scope.storeFile = function( gridRow, gridCol, files ) {
        // ignore all but the first file, it can only select one anyway
        // set the filename into this column
        gridRow.entity.filename = files[0].name;

        // read the file and set it into a hidden column, which we may do stuff with later
        var setFile = function(fileContent){
          gridRow.entity.file = fileContent.currentTarget.result;
          // put it on scope so we can display it - you'd probably do something else with it
          $scope.lastFile = fileContent.currentTarget.result;
          $scope.$apply();
        };
        var reader = new FileReader();
        reader.onload = setFile;
        reader.readAsText( files[0] );
      };

      $scope.gridOptions.columnDefs = [
        // { name: 'id', enableCellEdit: false, width: '10%' },
        // { name: 'name', displayName: 'Name (editable)', width: '20%' },
        // { name: 'age', displayName: 'Age' , type: 'number', width: '10%' },
        {name:'username'},
        {name:'email'},
        { name: 'user_group', displayName: 'Gender', editableCellTemplate: 'ui-grid/dropdownEditor', width: '20%',
          cellFilter: 'mapGender', editDropdownValueLabel: 'gender', editDropdownOptionsArray: [
          { id: 'user', gender: 'user' },
          { id: 'admin', gender: 'admin' }
        ] }
      ];

     $scope.msg = {};

     $scope.gridOptions.onRegisterApi = function(gridApi){
              //set gridApi on scope
              $scope.gridApi = gridApi;
              gridApi.edit.on.afterCellEdit($scope,function(rowEntity, colDef, newValue, oldValue){
                $scope.msg.lastCellEdited = 'edited row id:' + rowEntity.id + ' Column:' + colDef.name + ' newValue:' + newValue + ' oldValue:' + oldValue ;
                var query = {};
                query.user_group = newValue;
                $http.put('/user/update/'+rowEntity.id,query).success(function(data){
                  console.log(data);

                });
                $scope.$apply();
              });
            };

      $http.get('/user')
        .success(function(data) { console.log(data);
          // for(i = 0; i < data.length; i++){
          //   data[i].registered = new Date(data[i].registered);
          //   data[i].gender = data[i].gender==='user' ? 1 : 2;
          //   if (i % 2) {
          //     data[i].pet = 'fish'
          //     data[i].foo = {bar: [{baz: 2, options: [{value: 'fish'}, {value: 'hamster'}]}]}
          //   }
          //   else {
          //     data[i].pet = 'dog'
          //     data[i].foo = {bar: [{baz: 2, options: [{value: 'dog'}, {value: 'cat'}]}]}
          //   }
          // }
          $scope.gridOptions.data = data;
        });
    }])

    .filter('mapGender', function() {
      var genderHash = {
        'user': 'user',
        'admin': 'admin'
      };

      return function(input) {
        if (!input){
          return '';
        } else {
          return genderHash[input];
        }
      };
    })
    ;
