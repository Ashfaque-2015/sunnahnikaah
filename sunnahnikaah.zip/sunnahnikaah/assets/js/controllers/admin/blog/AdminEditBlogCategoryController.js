/**
 * Created by ash on 6/14/15.
 */
angular.module('app')
  .controller('AdminEditBlogCategoryController', ['$scope', '$stateParams', 'uiGridConstants', '$http', '$state', 'Options', function($scope, $stateParams, uiGridConstants, $http,$state,Options) {

    $scope.blog={};
    $scope.blog.category_title = "";
    $scope.blog.category_slug = "";
    console.log($stateParams);
    $scope.categoryAction="Update";

    $scope.alert=[];

    $scope.action=$scope.categoryAction;

    $scope.title="Edit Category";

    $scope.makeTitleSlug = function(){
      $scope.blog.category_slug = Options.convertToSlug( $scope.blog.category_title);
    };

    $http.get('/blogcategory/'+ $stateParams.catid).success (function(data){

      console.log(data);
      $scope.blog = {};
      $scope.category ={};
      $scope.blog.category_title=data.category_title;
      // $scope.blog.video_category=data.category.video_category;

      $scope.blog.category_desc=data.category_desc;

      $scope.makeTitleSlug();
    });



    $scope.saveCategory = function(){
      //var queryString = 'category_title='+$scope.blog.category_title+'&category_slug='+$scope.blog.category_slug+'&category_desc='+$scope.blog.category_desc;
      var queryString = {"category_title":$scope.blog.category_title,"category_slug":$scope.blog.category_slug,"category_desc":$scope.blog.category_desc};

      $http.post('/blogcategory/'+$stateParams.catid,queryString).

        success(function(data, status, headers, config) {
          // this callback will be called asynchronously
          // when the response is available
          console.log("category record created");
          console.log(data);

        })

    }
  }]);
