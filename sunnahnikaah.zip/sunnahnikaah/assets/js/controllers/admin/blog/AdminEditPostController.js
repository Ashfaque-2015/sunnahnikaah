/**
 * Created by ash on 6/15/15.
 */
angular.module('app')
  .controller('AdminEditPostController', ['$scope', '$stateParams', 'uiGridConstants', '$http', '$state', 'Options', function($scope, $stateParams, uiGridConstants, $http,$state, Options) {
    //var edit_category_iteam = $stateParams.edit_category_iteam;
    //var gridOptions= gridOptions;
    //
    //$http.get('/admin/' + $scope.gridOptions.id).success(function(data){
    //
    //  console.log(data);
    //
    //})
    $scope.alerts =[];
    console.log($stateParams);

    $scope.blog={};
    $scope.blog.post_title = "";
    $scope.blog.post_title_slug = "";
    $scope.postAction= "Update";
    $scope.action=$scope.postAction;
    $scope.categories = [];
    $scope.authors = [];

    $scope.makeTitleSlug = function(){
      $scope.blog.post_title_slug = Options.convertToSlug( $scope.blog.post_title);
    };

    $http.get("blogcategory").success(function(data){
      //console.log(data);
      $scope.categories = data;
    });

    $http.get('/author').success(function(data){
      $scope.authors = data;
    });

    $scope.title="Edit Post";

    //tags

    $scope.sourceTags = {};
    $http.get('/tag').success(function(response){
      $scope.sourceTags = response;
      console.log(response);
    });

    $scope.tags = [
      //{
      //  name: 'mahram'
      //},
      //{
      //  name: 'anything'
      //}
    ];



    //end tag



    $http.get('/blog/'+ $stateParams.postid).success (function(data){
      //console.log('data dekha',data);
      $scope.blog = {};
      $scope.blogcategory ={};
      $scope.blog.post_title=data.post_title;
      // $scope.blog.video_category=data.category.video_category;

      $scope.blog.post_desc=data.post_desc;
      $scope.blog.post_category = data.post_category.id;
      $scope.blog.post_author = data.post_author.id;
      $scope.blog.post_image = data.post_image;
    });

    $http.get('blogtag?blog='+$stateParams.postid).success(function(data){
      //console.log('tag data',data);
      data.forEach(function(val){
        val.tag.name = val.tag.tag_title;
        $scope.tags.push(val.tag);
      })

    });


    $scope.savePost = function(){
      //var queryString = 'category_title='+$scope.blog.category_title+'&category_slug='+$scope.blog.category_slug+'&category_desc='+$scope.blog.category_desc;
      var queryString = {"post_title":$scope.blog.post_title,"post_slug":$scope.blog.post_slug, "post_desc":$scope.blog.post_desc,"post_author":$scope.blog.post_author};

      $http.post('/blog/update/'+$stateParams.postid,queryString).

        success(function(data, status, headers, config) {
          // this callback will be called asynchronously
          // when the response is available
          $scope.alerts.push({ type: 'success', msg: 'Well done! You have successfully updated the post' });
          console.log("category record created");
          console.log(data);
        })

    };


    $scope.closeAlert = function (index) {
      $scope.alerts.splice(index, 1);
    };
  }]);
