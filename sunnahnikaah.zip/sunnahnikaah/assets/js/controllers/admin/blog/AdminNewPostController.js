angular.module('app')
  .controller('AdminNewPostController', ['$scope', '$http', '$upload', 'Options', function($scope,$http,$upload,Options) {
    $scope.alerts =[];
    $scope.categories = [];
    $scope.authors = [];
    $scope.postAction= "Add";
    $scope.action=$scope.postAction;
    $scope.title="Add New Post";

    //$scope.postTitleAction ="Add new post";
    //$scope.actionTitle= $scope.postTitleAction;

    $scope.blog={};
    $scope.blog.post_title = "";
    $scope.blog.post_title_slug = "";
    $scope.blog.post_tag=[];
    $scope.blog.post_category=[];
    $scope.blog.post_author = [];
    $scope.blog.post_image = "";
    $scope.makeTitleSlug = function(){
      $scope.blog.post_title_slug = Options.convertToSlug( $scope.blog.post_title);
    };

    $http.get("blogcategory").success(function(data){
      //console.log(data);
      $scope.categories = data;
    });

    $http.get('/author').success(function(data){
      $scope.authors = data;
    });

    //file uploading
    $scope.$watch('files', function () {
      $scope.upload($scope.files);
    });

    $scope.upload = function (files) {
      $scope.files = files;
    };

    //tags

    $scope.sourceTags = {};
      $http.get('/tag').success(function(response){
        $scope.sourceTags = response;
        console.log(response);
      });

    $scope.tags = [
      //{
      //  name: 'mahram'
      //},
      //{
      //  name: 'anything'
      //}
    ];

    //end tag

    console.log('all tags',$scope.tags);
    $scope.savePost = function(){

      $scope.tags.forEach(function(val){
        //console.log('post_tag',$scope.blog.post_tag);
        //console.log('value',val.id);
        $scope.blog.post_tag.push(val.id);
      });
      console.log('tags: ',$scope.blog.post_tag);
      //$scope.blog.post_tag = [];
      //$scope.blog.post_tag = ["55b76e444a856f7f1158c5b0", "55b8b8163ba9dcc51bb7693f"];
      console.log($scope.blog);
      if ($scope.files && $scope.files.length) {
        for (var i = 0; i < $scope.files.length; i++) {
          var file = $scope.files[i];
          console.log("take file");
          console.log($upload);
          $upload.upload({
            url: '/blog/upload',
            fields: $scope.blog,
            file: file
          }).progress(function (evt) {
            //  $("#profile-img-cont").empty().html('<i class="fa fa-refresh fa-spin"></i>');
            var progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
            console.log('progress: ' + progressPercentage + '% ' +
            evt.config.file.name);
          }).success(function (data, status, headers, config) {
            console.log('filename: ' + config.file.name + ' uploaded. Response: ' +
            JSON.stringify(data));
            $scope.image_path=data.data.post_image;
            //console.log(data.data.post_tag);
            $scope.alerts.push({ type: 'success', msg: 'Well done! You have successfully created a post( '+data.data.post_title+' ).' });
          });
        }
      }
      else{
        delete $scope.blog.post_tag; //delete post_tag from req.body
        $http.post("/blog/create",$scope.blog).
          success(function(data, status, headers, config) {
            console.log("blog record created",data);
            addPostTags(data.id);
            $scope.alerts.push({ type: 'success', msg: 'Well done! You have successfully created a post' });
          }).
          error(function(data, status, headers, config) {
            $scope.alerts.push({ type: 'danger', msg: 'Oh snap! Change a few things up and try submitting again.' });
          });

        function addPostTags(blogid){
          $scope.tags.forEach(function(val){
            var btag = {blog:blogid,tag:val.id};
            $http.post("/blogtag/create",btag).success(function(){
              console.log("tag added");
            });

          });
        }
      }


    };

    $scope.addAlert = function() {
      $scope.alerts.push({msg: 'Another alert!'});
    };

    $scope.closeAlert = function(index) {
      $scope.alerts.splice(index, 1);
    };





  }]);
