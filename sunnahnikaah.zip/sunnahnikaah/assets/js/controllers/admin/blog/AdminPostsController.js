angular.module('app')
  .controller('AdminPostsController', ['$scope', '$http', '$state', '$stateParams', function($scope,$http,$state,$stateParams) {

    $scope.gridOptions = {
      enableFiltering: true,
      flatEntityAccess: true,
      showGridFooter: true
    };

    $scope.gridOptions.columnDefs = [
      {name:'post_title'},
      {name:'post_title_slug'},
      {name:'post_desc'},
      {name:'category_action', cellTemplate:'<button class="btn primary" ng-click="grid.appScope.Edit(row)">Edit</button> <button class="btn primary" ng-really-message="Delete this post. Are you sure?" ng-really-click="grid.appScope.Delete(row)">Delete</button>'}
    ];

    //console.log("ashes");

    $http.get('blog/')
      .success(function(data) {
        //console.log(data);
        //console.log(data);
        //for( var i=0; i<3; i++){
        //  data = data.concat(data);
        //}
        $scope.gridOptions.data = data;
      });



    $scope.Delete=function(row){

      //console.log('data dekha',row);
      //console.log('id to delete',row.entity.id);
      var index = $scope.gridOptions.data.indexOf(row.entity);
      //console.log('ki khobor',index);
      $scope.gridOptions.data.splice(index, 1);

      //console.log(row.entity);
      // delete image and destroy post
          $http.post('/blog/deleteImage',row.entity).success(function(data){
            //console.log(data);
          });
      //

      // post destroy
          //$http.post('/blog/destroy/'+row.entity.id).success(function(data){
          //  //console.log(data);
          //});
      //  post destroy end
    };

    $scope.Edit=function(row){
      $state.go("base.admin.edit_post", {postid:row.entity.id});
    };



    $scope.toggleFlat = function() {
      $scope.gridOptions.flatEntityAccess = !$scope.gridOptions.flatEntityAccess;
    }

    }]);
