/**
 * Created by ash on 6/15/15.
 */
angular.module('app')
  .controller('AdminEditFiqhController', ['$scope', '$stateParams', 'uiGridConstants', '$http', '$state', 'Options', function ($scope, $stateParams, uiGridConstants, $http, $state, Options) {
    //var edit_category_iteam = $stateParams.edit_category_iteam;
    //var gridOptions= gridOptions;
    //
    //$http.get('/admin/' + $scope.gridOptions.id).success(function(data){
    //
    //  console.log(data);
    //
    //})

    console.log($stateParams);
    $scope.alerts =[];
    $scope.categories = [];
    $scope.authors = [];

    $scope.fiqh = {};
    $scope.fiqh.fiqh_title = "";
    $scope.fiqh.fiqh_title_slug = "";
    $scope.fiqh.fiqh_author = "";
    $scope.fiqh.fiqh_image = "";
    $scope.fiqhAction = "Update";
    $scope.action = $scope.fiqhAction;

    $scope.makeTitleSlug = function () {
      $scope.fiqh.fiqh_title_slug = Options.convertToSlug($scope.fiqh.fiqh_title);
    };

    $http.get("fiqhcategory").success(function (data) {
      //console.log(data);
      $scope.categories = data;
    });

    $http.get("/author").success(function (data) {
      //console.log(data);
      $scope.authors = data;
    });

    $scope.title = "Edit fiqh";

    //tags

    $scope.sourceTags = {};
    $http.get('/tag').success(function(response){
      $scope.sourceTags = response;
      console.log(response);
    });

    $scope.tags = [
      //{
      //  name: 'mahram'
      //},
      //{
      //  name: 'anything'
      //}
    ];

    //end tag

    $http.get('/fiqh/' + $stateParams.fiqhid).success(function (data) {

      console.log('data dekha', data);
      $scope.fiqh = {};
      $scope.fiqhcategory = {};
      $scope.fiqh.fiqh_title = data.fiqh_title;
      // $scope.blog.video_category=data.category.video_category;

      $scope.fiqh.fiqh_desc = data.fiqh_desc;
      $scope.fiqh.fiqh_category = data.fiqh_category.id;
      $scope.fiqh.fiqh_author = data.fiqh_author.id;
      $scope.fiqh.fiqh_image = data.fiqh_image;
      // $scope.bog=data;




    });

    $http.get('fiqhtag?fiqh='+$stateParams.fiqhid).success(function(data){
      //console.log('tag data',data);
      data.forEach(function(val){
        val.tag.name = val.tag.tag_title;
        $scope.tags.push(val.tag);
      })

    });


    $scope.savePost = function () {
      //var queryString = 'category_title='+$scope.blog.category_title+'&category_slug='+$scope.blog.category_slug+'&category_desc='+$scope.blog.category_desc;
      var queryString = {
        "fiqh_title": $scope.fiqh.fiqh_title,
        "fiqh_slug": $scope.fiqh.fiqh_slug,
        "fiqh_desc": $scope.fiqh.fiqh_desc
      };

      $http.post('/fiqh/' + $stateParams.fiqhid, queryString).

        success(function (data, status, headers, config) {
          // this callback will be called asynchronously
          // when the response is available
          $scope.alerts.push({ type: 'success', msg: 'Fiqh has been successfully updated' });
          console.log("category record updated");
          console.log(data);

        })

    };

    $scope.closeAlert = function(index) {
      $scope.alerts.splice(index, 1);
    };

  }]);
