angular.module('app')
  .controller('AdminFiqhCategoriesController', ['$scope', 'uiGridConstants', '$http', '$state', '$stateParams', function ($scope, uiGridConstants, $http, $state, $stateParams) {

    $scope.gridOptions = {
      enableFiltering: true,
      flatEntityAccess: true,
      showGridFooter: true
    };
    //$scope.gridOptions.enableCellEditOnFocus = true;
    $scope.gridOptions.columnDefs = [
      {name: 'category_title'},
      {name: 'category_slug'},
      {name: 'category_desc'},
      {
        name: 'category_action',
        cellTemplate: '<button class="btn primary" ng-click="grid.appScope.Edit(row)">Edit</button> <button class="btn primary" ng-click="grid.appScope.Delete(row)">Delete</button>'
      },


    ];

    console.log("ashes");


    $http.get('fiqhcategory/')
      .success(function (data) {
        //console.log(data);
        //for( var i=0; i<3; i++){
        //  data = data.concat(data);
        //}
        console.log(data);
        $scope.gridOptions.data = data;
      });


    //delete admin category


    $scope.Delete = function (row) {

      console.log('data dekha', row);
      console.log('id to delete', row.entity.id);
      var index = $scope.gridOptions.data.indexOf(row.entity);
      console.log('ki khobor', index);
      $scope.gridOptions.data.splice(index, 1);


      $http.post('/fiqhcategory/destroy/' + row.entity.id).success(function (data) {
        console.log(data);

      })


    };


    $scope.Edit = function (row) {


      $state.go("base.admin.edit_fiqh_category", {catid: row.entity.id});


    };

    $scope.toggleFlat = function () {
      $scope.gridOptions.flatEntityAccess = !$scope.gridOptions.flatEntityAccess;
    }

  }]);
