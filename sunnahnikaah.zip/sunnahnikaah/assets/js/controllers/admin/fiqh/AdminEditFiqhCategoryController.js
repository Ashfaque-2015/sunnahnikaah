angular.module('app')
  .controller('AdminEditFiqhCategoryController', ['$scope', '$stateParams', 'uiGridConstants', '$http', '$state', 'Options', function($scope, $stateParams, uiGridConstants, $http,$state,Options) {

    $scope.fiqh={};
    $scope.fiqh.category_title = "";
    $scope.fiqh.category_slug = "";
    console.log($stateParams);
    $scope.categoryAction="Update";

    $scope.alerts=[];

    $scope.action=$scope.categoryAction;

    $scope.title="Edit Category";

    $scope.makeTitleSlug = function(){
      $scope.fiqh.category_slug = Options.convertToSlug( $scope.fiqh.category_title);
    };

    $http.get('/fiqhcategory/'+ $stateParams.catid).success (function(data){

      console.log(data);
      $scope.fiqh = {};
      $scope.fiqhcategory ={};
      $scope.fiqh.category_title=data.category_title;
      // $scope.blog.video_category=data.category.video_category;

      $scope.fiqh.category_desc=data.category_desc;


      $scope.makeTitleSlug();
    });

    $scope.saveCategory = function(){
      //var queryString = 'category_title='+$scope.blog.category_title+'&category_slug='+$scope.blog.category_slug+'&category_desc='+$scope.blog.category_desc;
      var queryString = {"category_title":$scope.fiqh.category_title,"category_slug":$scope.fiqh.category_slug,"category_desc":$scope.fiqh.category_desc};

      $http.post('/fiqhcategory/'+$stateParams.catid,queryString).

        success(function(data, status, headers, config) {
          // this callback will be called asynchronously
          // when the response is available
          console.log("category record created");
          console.log(data);
        })
    };

    $scope.closeAlert = function(index) {
      $scope.alerts.splice(index, 1);
    };
  }]);
