angular.module('app')
  .controller('AdminFiqhController', ['$scope', '$http', '$state', '$stateParams', function ($scope, $http, $state, $stateParams) {

    $scope.gridOptions = {
      enableFiltering: true,
      flatEntityAccess: true,
      showGridFooter: true
    };

    $scope.gridOptions.columnDefs = [
      {name: 'fiqh_title'},
      {name: 'fiqh_title_slug'},
      {name: 'fiqh_desc'},
      {
        name: 'category_action',
        cellTemplate: '<button class="btn primary" ng-click="grid.appScope.Edit(row)">Edit</button> <button class="btn primary" ng-click="grid.appScope.Delete(row)">Delete</button>'
      }
    ];

    console.log("ashes");

    $http.get('/fiqh')
      .success(function (data) {
        //console.log(data);
        //console.log(data);
        //for( var i=0; i<3; i++){
        //  data = data.concat(data);
        //}
        $scope.gridOptions.data = data;
      });


    $scope.Delete = function (row) {

      //console.log('data dekha', row);
      //console.log('id to delete', row.entity.id);


      var index = $scope.gridOptions.data.indexOf(row.entity);
      //console.log('ki khobor', index);
      $scope.gridOptions.data.splice(index, 1);

      //console.log(row.entity);
      // delete image and destroy post
      $http.post('/fiqh/deleteImage',row.entity).success(function(data){
        //console.log(data);
      });
      //


      //$http.post('/fiqh/destroy/' + row.entity.id).success(function (data) {
      //  //console.log(data);
      //
      //});


    };

    $scope.Edit = function (row) {


      $state.go("base.admin.edit_fiqh", {fiqhid: row.entity.id});


    };


    $scope.toggleFlat = function () {
      $scope.gridOptions.flatEntityAccess = !$scope.gridOptions.flatEntityAccess;
    }

  }]);
