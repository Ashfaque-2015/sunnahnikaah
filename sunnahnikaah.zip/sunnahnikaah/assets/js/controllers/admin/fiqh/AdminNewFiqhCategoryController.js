angular.module('app')
  .controller('AdminNewFiqhCategoryController', ['$scope', '$http', '$state', 'Options', function($scope,$http,$state,Options) {

    $scope.alerts =[];
    $scope.categoryAction="Add";
    $scope.action=$scope.categoryAction;

    $scope.title="Add New Category";

    $scope.fiqh={};
    $scope.fiqh.category_title = "";
    $scope.fiqh.category_slug = "";
    $scope.makeTitleSlug = function(){
      $scope.fiqh.category_slug = Options.convertToSlug( $scope.fiqh.category_title);
    };

    $scope.saveCategory = function(){
      if(!$scope.fiqh.category_title || !$scope.fiqh.category_slug){
        $scope.alerts.push({ type: 'danger', msg: 'Aah! Please try again filling the title' });
      }
      else{
        //var queryString = 'category_title='+$scope.blog.category_title+'&category_slug='+$scope.blog.category_slug+'&category_desc='+$scope.blog.category_desc;
        var queryString = {"category_title":$scope.fiqh.category_title,"category_slug":$scope.fiqh.category_slug,"category_desc":$scope.fiqh.category_desc};

        $http.post("/fiqhcategory/create",queryString).
          //$http.post("/category/create?"+queryString).
          success(function(data, status, headers, config) {
            // this callback will be called asynchronously
            // when the response is available
            console.log("category record created")
            console.log(data);
            $scope.alerts.push({ type: 'success', msg: 'Well done! You have successfully created a category( '+data.category_title+' ).' });

            $scope.fiqh={} //reset all value
          }).
          error(function(data, status, headers, config) {
            $scope.alerts.push({ type: 'danger', msg: 'Oh snap! Change a few things up and try submitting again.' });
          });
      }

    };

    $scope.addAlert = function() {
      $scope.alerts.push({msg: 'Another alert!'});
    };

    $scope.closeAlert = function(index) {
      $scope.alerts.splice(index, 1);
    };



  }]);
