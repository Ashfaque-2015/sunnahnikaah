angular.module('app')
    .controller('AdminNewFiqhController', ['$scope', '$http', '$upload', 'Options', function($scope,$http,$upload,Options) {
        $scope.alerts =[];
        $scope.categories = [];
        $scope.authors = [];

        $scope.fiqhAction= "Add";
        $scope.action=$scope.fiqhAction;
        $scope.title="Add New Fiqh";

        //$scope.postTitleAction ="Add new post";
        //$scope.actionTitle= $scope.postTitleAction;

        $scope.fiqh={};
        $scope.fiqh.fiqh_title = "";
        $scope.fiqh.fiqh_title_slug = "";
        $scope.fiqh.fiqh_author = "";
        $scope.fiqh.fiqh_tag=[];
        $scope.makeTitleSlug = function(){
            $scope.fiqh.fiqh_title_slug = Options.convertToSlug( $scope.fiqh.fiqh_title);
        };

        $http.get("fiqhcategory").success(function(data){
            //console.log(data);
            $scope.categories = data;
        });

        $http.get("/author").success(function(data){
          //console.log(data);
          $scope.authors = data;
        });

        //file uploading
        $scope.$watch('files', function () {
            $scope.upload($scope.files);
        });

        $scope.upload = function (files) {
            $scope.files = files;
        };

        //tags

        $scope.sourceTags = {};
        $http.get('/tag').success(function(response){
          $scope.sourceTags = response;
          console.log(response);
        });

        $scope.tags = [
          //{
          //  name: 'mahram'
          //},
          //{
          //  name: 'anything'
          //}
        ];

        //end tag

        $scope.savePost = function(){
          $scope.tags.forEach(function(val){
            //console.log('post_tag',$scope.blog.post_tag);
            //console.log('value',val.id);
            $scope.fiqh.fiqh_tag.push(val.id);
          });
          console.log('tags: ',$scope.fiqh.fiqh_tag);

            if ($scope.files && $scope.files.length) {
                for (var i = 0; i < $scope.files.length; i++) {
                    var file = $scope.files[i];
                    console.log("take file");
                    console.log($upload);
                    $upload.upload({
                        url: '/fiqh/upload',
                        fields: $scope.fiqh,
                        file: file
                    }).progress(function (evt) {
                        //  $("#profile-img-cont").empty().html('<i class="fa fa-refresh fa-spin"></i>');
                        var progressPercentage = parseInt(100.0 * evt.loaded / evt.total);
                        console.log('progress: ' + progressPercentage + '% ' +
                            evt.config.file.name);
                    }).success(function (data, status, headers, config) {
                        console.log('filename: ' + config.file.name + ' uploaded. Response: ' +
                            JSON.stringify(data));
                        $scope.image_path=data.data.fiqh_image;
                        $scope.alerts.push({ type: 'success', msg: 'Well done! You have successfully created a post( '+data.data.fiqh_title+' ).' });
                    });
                }
            }
            else{
              delete $scope.fiqh.fiqh_tag;
              $http.post("/fiqh/create",$scope.fiqh).
                success(function(data, status, headers, config) {
                  console.log("fiqh record created",data);
                  addFiqhTags(data.id);
                  $scope.alerts.push({ type: 'success', msg: 'Well done! You have successfully created a fiqh' });
                }).
                error(function(data, status, headers, config) {
                  $scope.alerts.push({ type: 'danger', msg: 'Oh snap! Change a few things up and try submitting again.' });
                });

              function addFiqhTags(fiqhid){
                $scope.tags.forEach(function(val){
                  var ftag = {fiqh:fiqhid,tag:val.id};
                  $http.post("/fiqhtag/create",ftag).success(function(){
                    console.log("tag added");
                  });
                });
              }
            }
        };

        $scope.addAlert = function() {
            $scope.alerts.push({msg: 'Another alert!'});
        };

        $scope.closeAlert = function(index) {
            $scope.alerts.splice(index, 1);
        };

    }]);
