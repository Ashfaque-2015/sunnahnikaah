angular.module('app')
  .controller('AdminNewAuthorController', ['$scope', '$http', '$state', 'Options', function ($scope, $http, $state, Options) {

    $scope.alerts = [];
    $scope.authorAction = "Add";
    $scope.action = $scope.authorAction;

    $scope.title = "Add New Author";

    $scope.author = {};
    $scope.author.author_name = "";
    $scope.author.author_type = "";
    $scope.author.author_slug = "";
    $scope.makeAuthorSlug = function(){
      $scope.author.author_slug = Options.convertToSlug($scope.author.author_name);
    };

    $scope.saveAuthor = function () {
      //var queryString = 'category_title='+$scope.blog.category_title+'&category_slug='+$scope.blog.category_slug+'&category_desc='+$scope.blog.category_desc;
      var queryString = {
        "author_name": $scope.author.author_name,
        "author_type": $scope.author.author_type,
        "author_slug": $scope.author.author_slug
      };
      console.log("query string",queryString);
      $http.post("/author/create", queryString).
        //$http.post("/category/create?"+queryString).
        success(function (data, status, headers, config) {
          // this callback will be called asynchronously
          // when the response is available
          console.log('author record created',data);
          $scope.alerts.push({
            type: 'success',
            msg: 'Well done! You have successfully created a author( ' + data.author_name + ' ).'
          });
        }).
        error(function (data, status, headers, config) {
          $scope.alerts.push({type: 'danger', msg: 'Oh snap! Change a few things up and try submitting again.'});
        });
    };

    $scope.addAlert = function () {
      $scope.alerts.push({ msg: 'Another alert!'});
    };

    $scope.closeAlert = function (index) {
      $scope.alerts.splice(index, 1);
    };


  }]);
