angular.module('app')
  .controller('AdminEditAuthorController', ['$scope', '$stateParams', 'uiGridConstants', '$http', '$state', 'Options', function ($scope, $stateParams, uiGridConstants, $http, $state,Options) {
    console.log('AdminEditAuthorController');
    $scope.author = {};
    $scope.author.author_name = "";
    $scope.author.author_type = "";
    $scope.author.author_slug = "";
    console.log('authorid',$stateParams);
    $scope.authorAction = "Update";

    $scope.alert = [];
    $scope.action = $scope.authorAction;
    $scope.title = "Edit Author";

    $scope.makeAuthorSlug = function(){
      $scope.author.author_slug = Options.convertToSlug($scope.author.author_name);
    };

    $http.get('/author/' + $stateParams.authorid).success(function (data) {

      console.log('authorData: ',data);
      $scope.author.author_name = data.author_name;
      $scope.author.author_type = data.author_type;
      $scope.author.author_slug = data.author_slug;
    });

    $scope.saveAuthor = function () {
      var queryString = {
        "author_name": $scope.author.author_name,
        "author_type": $scope.author.author_type,
        "author_slug": $scope.author.author_slug
      };

      $http.post('/author/' + $stateParams.authorid, queryString).

        success(function (data, status, headers, config) {
          // this callback will be called asynchronously
          // when the response is available
          console.log("author record updated",data);
        });
    }
  }]);
