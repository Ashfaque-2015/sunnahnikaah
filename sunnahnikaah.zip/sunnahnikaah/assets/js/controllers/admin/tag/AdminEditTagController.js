angular.module('app')
  .controller('AdminEditTagController', ['$scope', '$stateParams', 'uiGridConstants', '$http', '$state', function ($scope, $stateParams, uiGridConstants, $http, $state) {

    $scope.tag = {};
    $scope.tag.tag_title = "";
    $scope.tag.tag_slug = "";
    console.log($stateParams);
    $scope.tagAction = "Update";

    $scope.alerts = [];

    $scope.action = $scope.tagAction;

    $scope.title = "Edit tag";

    $http.get('/tag/' + $stateParams.tagid).success(function (data) {

      console.log(data);
      $scope.tag = {};
      $scope.tag = {};
      $scope.tag.tag_title = data.tag_title;
      // $scope.blog.video_tag=data.tag.video_tag;

      $scope.tag.tag_desc = data.tag_desc;

    });

    $scope.saveTag = function () {
      //var queryString = 'tag_title='+$scope.blog.tag_title+'&tag_slug='+$scope.blog.tag_slug+'&tag_desc='+$scope.blog.tag_desc;
      var queryString = {
        "tag_title": $scope.tag.tag_title,
        "tag_slug": $scope.tag.tag_slug,
        "tag_desc": $scope.tag.tag_desc
      };

      $http.post('/tag/' + $stateParams.tagid, queryString).

        success(function (data, status, headers, config) {
          // this callback will be called asynchronously
          // when the response is available
          console.log("tag record created");
          console.log(data);

        })
    };

    $scope.closeAlert = function(index) {
      $scope.alerts.splice(index, 1);
    };
  }]);
