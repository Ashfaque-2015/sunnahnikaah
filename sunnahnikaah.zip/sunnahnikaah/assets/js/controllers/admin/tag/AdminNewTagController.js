angular.module('app')
  .controller('AdminNewTagController', ['$scope', '$http', '$state', 'Options', function($scope,$http,$state,Options) {

    $scope.alerts =[];
    $scope.tagAction="Add";
    $scope.action=$scope.tagAction;

    $scope.title="Add New Tag";

    $scope.tag={};
    $scope.tag.tag_title = "";
    $scope.tag.tag_slug = "";
    $scope.tag.tag_desc = "";
    $scope.makeTitleSlug = function(){
      $scope.tag.tag_slug = Options.convertToSlug( $scope.tag.tag_title);
    };

    $scope.saveTag = function(){
      //var queryString = 'tag_title='+$scope.blog.tag_title+'&tag_slug='+$scope.blog.tag_slug+'&tag_desc='+$scope.blog.tag_desc;
      var queryString = {"tag_title":$scope.tag.tag_title,"tag_slug":$scope.tag.tag_slug,"tag_desc":$scope.tag.tag_desc};
      console.log('queryString',queryString);
      $http.post("/tag/create",queryString).
        //$http.post("/tag/create?"+queryString).
        success(function(data, status, headers, config) {
          // this callback will be called asynchronously
          // when the response is available
          console.log("tag record created");
          console.log(data);
          $scope.alerts.push({ type: 'success', msg: 'Well done! You have successfully created a tag( '+data.tag_title+' ).' });
        }).
        error(function(data, status, headers, config) {
          $scope.alerts.push({ type: 'danger', msg: 'Oh snap! Change a few things up and try submitting again.'});
        });
    };

    $scope.addAlert = function() {
      $scope.alerts.push({msg: 'Another alert!'});
    };

    $scope.closeAlert = function(index) {
      $scope.alerts.splice(index, 1);
    };



  }]);
