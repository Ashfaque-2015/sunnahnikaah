angular.module('app')
  .controller('AdminTagsController', ['$scope', 'uiGridConstants', '$http', '$state', '$stateParams', function ($scope, uiGridConstants, $http, $state, $stateParams) {
    console.log('AdminTagsController');
    $scope.gridOptions = {
      enableFiltering: true,
      flatEntityAccess: true,
      showGridFooter: true
    };
    $scope.gridOptions.columnDefs = [
      {name: 'tag_title'},
      {name: 'tag_slug'},
      {name: 'tag_desc'},
      {
        name: 'tag_action',
        cellTemplate: '<button class="btn primary" ng-click="grid.appScope.Edit(row)">Edit</button> <button class="btn primary" ng-click="grid.appScope.Delete(row)">Delete</button>'
      }
    ];

    $http.get('tag/')
      .success(function (data) {
        console.log(data);
        $scope.gridOptions.data = data;
      });

    //delete admin category

    $scope.Delete = function (row) {
      var index = $scope.gridOptions.data.indexOf(row.entity);
      $scope.gridOptions.data.splice(index, 1);
      $http.post('/tag/destroy/' + row.entity.id).success(function (data) {
        console.log(data);
      });
    };

    $scope.Edit = function (row) {
      $state.go("base.admin.edit_tag", {tagid: row.entity.id});
    };

    $scope.toggleFlat = function () {
      $scope.gridOptions.flatEntityAccess = !$scope.gridOptions.flatEntityAccess;
    }

  }]);
