angular.module('app')
  .controller('AdminDashboardController', ['$scope', '$rootScope', 'AccessLevels', '$state', 'CurrentUser', 'LocalService', function($scope,$rootScope,AccessLevels,$state, CurrentUser,LocalService) {
    CurrentUser.setBodyClass();

    if (CurrentUser.user()) {
      if(CurrentUser.user().user_group!="admin"){
        $state.go('base.user.dashboard');
        //console.log("aise ekhane");
      }
    }

    $scope.oneAtATime = true;

    $scope.status = {
      isFirstOpen: true,
      isFirstDisabled: false
    };

    }]);
