/**
 * Created by ash on 6/15/15.
 */
angular.module('app')
  .controller('AdminEditVideoController', ['$scope', '$stateParams', 'uiGridConstants', '$http', '$state', 'Options', function ($scope, $stateParams, uiGridConstants, $http, $state, Options) {
    console.log($stateParams);
    $scope.alerts =[];
    $scope.videoAction = "Update";
    $scope.action = $scope.videoAction;
    $scope.categories = [];
    $scope.authors = [];
    $scope.title = "Edit video";
    $scope.video = {};
    $scope.video.video_title = "";
    $scope.video.video_slug = "";
    $scope.video.video_author = "";
    $scope.makeTitleSlug = function () {
      $scope.video.video_slug = Options.convertToSlug($scope.video.video_title);
    };

    $http.get("videocategory").success(function (data) {
      //console.log(data);
      $scope.categories = data;
    });

    $http.get("/author").success(function(data){
      //console.log(data);
      $scope.authors = data;
    });

    //tags

    $scope.sourceTags = {};
    $http.get('/tag').success(function(response){
      $scope.sourceTags = response;
      console.log(response);
    });

    $scope.tags = [
      //{
      //  name: 'mahram'
      //},
      //{
      //  name: 'anything'
      //}
    ];

    //end tag

    $http.get('/video/' + $stateParams.videoid).success(function (data) {

      console.log('hmm', data);
      $scope.video = {};
      $scope.videocategory = {};
      $scope.video.video_title = data.video_title;
      // $scope.video.video_category=data.category.video_category;

      $scope.video.video_desc = data.video_desc;
      $scope.video.video_type = data.video_type;
      $scope.video.video_link = data.video_link;
      $scope.video.video_category = data.video_category.id;
      $scope.video.video_author = data.video_author.id;

      // $scope.video=data;
    });


    $http.get('videotag?video='+$stateParams.videoid).success(function(data){
      //console.log('tag data',data);
      data.forEach(function(val){
        val.tag.name = val.tag.tag_title;
        $scope.tags.push(val.tag);
      })

    });



    $scope.saveVideo = function () {
      //var queryString = 'category_title='+$scope.video.category_title+'&category_slug='+$scope.video.category_slug+'&category_desc='+$scope.video.category_desc;
      var queryString = {
        "video_title": $scope.video.video_title,
        "video_slug": $scope.video.video_slug,
        "video_desc": $scope.video.video_desc
      };

      $http.post('/video/' + $stateParams.videoid, queryString).

        success(function (data, status, headers, config) {

          $scope.alerts.push({ type: 'success', msg: 'Video has been successfully updated' });
          // this callback will be called asynchronously
          // when the response is available
          console.log("category record created");
          console.log(data);

        })

    };

    $scope.closeAlert = function(index) {
      $scope.alerts.splice(index, 1);
    };

  }]);
