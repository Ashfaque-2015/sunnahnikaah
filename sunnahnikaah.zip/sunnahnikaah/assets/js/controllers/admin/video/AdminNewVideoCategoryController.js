angular.module('app')
  .controller('AdminNewVideoCategoryController', ['$scope', '$http', '$state', 'Options', function ($scope, $http, $state, Options) {

    $scope.alerts = [];
    $scope.categoryAction = "Add";
    $scope.action = $scope.categoryAction;

    $scope.title = "Add New Video Category";

    $scope.video = {};
    $scope.video.category_title = "";
    $scope.video.category_slug = "";
    $scope.makeTitleSlug = function () {
      $scope.video.category_slug = Options.convertToSlug($scope.video.category_title);
    };

    $scope.saveCategory = function () {
      if(!$scope.video.category_title || !$scope.video.category_slug){
        $scope.alerts.push({ type: 'danger', msg: 'Aah! Please try again filling the title' });
      }
      else{
        //var queryString = 'category_title='+$scope.blog.category_title+'&category_slug='+$scope.blog.category_slug+'&category_desc='+$scope.blog.category_desc;
        var queryString = {
          "category_title": $scope.video.category_title,
          "category_slug": $scope.video.category_slug,
          "category_desc": $scope.video.category_desc
        };

        $http.post("/VideoCategory/create", queryString).
          //$http.post("/category/create?"+queryString).
          success(function (data, status, headers, config) {
            // this callback will be called asynchronously
            // when the response is available
            //console.log("category record created");
            //console.log(data);
            $scope.alerts.push({
              type: 'success',
              msg: 'Well done! You have successfully created a category( ' + data.category_title + ' ).'
            });
            $scope.video = {}; //reset video
          }).
          error(function (data, status, headers, config) {
            $scope.alerts.push({type: 'danger', msg: 'Oh snap! Change a few things up and try submitting again.'});
          });
      }

    };

    $scope.addAlert = function () {
      $scope.alerts.push({msg: 'Another alert!'});
    };

    $scope.closeAlert = function (index) {
      $scope.alerts.splice(index, 1);
    };


  }]);
