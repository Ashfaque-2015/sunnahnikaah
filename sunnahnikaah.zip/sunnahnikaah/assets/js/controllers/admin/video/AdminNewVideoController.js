angular.module('app')
  .controller('AdminNewVideoController', ['$scope', '$http', '$upload', 'Options', function($scope,$http,$upload,Options) {
    $scope.alerts =[];
    $scope.categories = [];
    $scope.authors = [];

    $scope.videoAction="Add";
    $scope.title="Add New Video";

    $scope.video={};
    $scope.video.video_title = "";
    $scope.video.video_slug = "";
    $scope.video.video_author = "";
    //$scope.video.video_tag=[];
    $scope.makeTitleSlug = function(){
      $scope.video.video_slug = Options.convertToSlug($scope.video.video_title);
    };

    //tags

    $scope.sourceTags = {};
    $http.get('/tag').success(function(response){
      $scope.sourceTags = response;
      console.log(response);
    });

    $scope.tags = [
      //{
      //  name: 'mahram'
      //},
      //{
      //  name: 'anything'
      //}
    ];

    //end tag

    $http.get("/videocategory").success(function(data){
      //console.log(data);
      $scope.categories = data;
    });

    $http.get("/author").success(function(data){
      //console.log(data);
      $scope.authors = data;
    });

    $scope.saveVideo = function(){
      //var queryString = {"video_title":$scope.video.video_title,"video_slug":$scope.video.video_slug,"video_desc":$scope.video.video_desc};

      //$scope.tags.forEach(function(val){
      //  //console.log('post_tag',$scope.blog.post_tag);
      //  //console.log('value',val.id);
      //  $scope.video.video_tag.push(val.id);
      //});
      //console.log('video: ',$scope.video);
      //var video_tag = $scope.video.video_tag;
      //delete $scope.video.video_tag; //delete video_tag from video
      //console.log('video: ',$scope.video);

      $http.post("/video/create",$scope.video).
        success(function(data, status, headers, config) {
          console.log("video record created");
          console.log(data);
          addVideoTags(data.id);
          $scope.alerts.push({ type: 'success', msg: 'Well done! You have successfully created a video link( '+data.video_title+' ).' });
        }).
        error(function(data, status, headers, config) {
          $scope.alerts.push({ type: 'danger', msg: 'Oh snap! Change a few things up and try submitting again.' });
        });

      function addVideoTags(videoid){
        $scope.tags.forEach(function(val){
          //$scope.video.video_tag.push(val.id);
          var vtag = {video:videoid,tag:val.id};
          $http.post("/videotag/create",vtag).success(function(){
            console.log("tag added");
          });

        });
      }
    };

    $scope.addAlert = function() {
      $scope.alerts.push({msg: 'Another alert!'});
    };

    $scope.closeAlert = function(index) {
      $scope.alerts.splice(index, 1);
    };

    $scope.clearAllField = function(){
      $scope.video.video_title = "";
      $scope.video.video_slug = "";
      $scope.video.video_link = "";
      $scope.video.video_type = "";
      $scope.video.video_desc = "";
      $scope.video.video_category = "";
      $scope.tags = [
        //{
        //  name: 'mahram'
        //},
        //{
        //  name: 'anything'
        //}
      ];
    }

  }]);
