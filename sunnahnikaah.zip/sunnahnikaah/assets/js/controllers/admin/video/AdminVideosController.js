angular.module('app')
  .controller('AdminVideosController', ['$scope', '$http', '$state', '$stateParams', function($scope,$http,$state,$stateParams) {

    $scope.gridOptions = {
      enableFiltering: true,
      flatEntityAccess: true,
      showGridFooter: true
    };

    $scope.gridOptions.columnDefs = [
      {name:'video_title'},
      {name:'video_slug'},
      {name:'video_link'},
      {name:'video_action', cellTemplate:'<button class="btn primary" ng-click="grid.appScope.Edit(row)">Edit</button> <button class="btn primary" ng-click="grid.appScope.Delete(row)">Delete</button>'}
    ];

    $http.get('video/')
      .success(function(data) {
        console.log(data)
        //console.log(data);
        //for( var i=0; i<3; i++){
        //  data = data.concat(data);
        //}
        $scope.gridOptions.data = data;
      });


    $scope.Delete=function(row) {

      console.log('data dekha', row);
      console.log('id to delete', row.entity.id);
      var index = $scope.gridOptions.data.indexOf(row.entity);
      console.log('ki khobor', index);
      $scope.gridOptions.data.splice(index, 1);


      $http.post('/video/destroy/' + row.entity.id).success(function (data) {
        console.log(data);


      })

    };


    $scope.Edit=function(row){


      $state.go("base.admin.edit_video", {videoid:row.entity.id});



    };


    $scope.toggleFlat = function() {
      $scope.gridOptions.flatEntityAccess = !$scope.gridOptions.flatEntityAccess;
    }

    }]);
