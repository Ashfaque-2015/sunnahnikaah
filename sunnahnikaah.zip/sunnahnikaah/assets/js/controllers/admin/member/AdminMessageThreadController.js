angular.module('app')
  .controller('AdminMessageThreadController', ['$scope', 'uiGridConstants', '$http', '$state', '$stateParams', function ($scope, uiGridConstants, $http, $state, $stateParams) {

    $scope.gridOptions = {
      enableFiltering: true,
      flatEntityAccess: true,
      showGridFooter: true
    };
    //$scope.gridOptions.enableCellEditOnFocus = true;
    $scope.gridOptions.columnDefs = [
      {name: 'id'},
      {name: 'me'},
      {name: 'other_user'},
      {name: 'last_message'},
      {
        name: 'Thread action',
        cellTemplate: '<button class="btn primary" ng-click="grid.appScope.viewMessage(row)">View messages</button>'
      }
      //{name:'category_action', cellTemplate:'<button class="btn primary" ng-click="grid.appScope.Edit(row)">Edit</button> <button class="btn primary" ng-click="grid.appScope.Delete(row)">Delete</button>'},


    ];

    console.log("ashes");

    $scope.messageGridOptions = {
      enableFiltering: true,
      flatEntityAccess: true,
      showGridFooter: true
    };
    $scope.messageGridOptions.columnDefs = [
      {name: 'from'},
      {name: 'to'},
      {name: 'body'},
      {name: 'createdAt'},
      {name: 'updatedAt'},
      {name: 'updatedAt'},
      {name: "is_deleted"},
      {
        name: 'Chat action',
        cellTemplate: '<button class="btn btn-primary" ng-click="grid.appScope.softDeleteChat(row)"><span ng-show="row.entity.is_deleted">Undo Delete</span><span ng-hide="row.entity.is_deleted">Delete</span></button>'
      }

      //{name:'last_message'},
      //{name:'Thread action', cellTemplate:'<button class="btn primary" ng-click="grid.appScope.viewMessage(row)">View messages</button>'}
      //{name:'category_action', cellTemplate:'<button class="btn primary" ng-click="grid.appScope.Edit(row)">Edit</button> <button class="btn primary" ng-click="grid.appScope.Delete(row)">Delete</button>'},


    ];


    $http.get('/thread')
      .success(function (data) {
        //console.log(data);
        //for( var i=0; i<3; i++){
        //  data = data.concat(data);
        //}
        console.log(data);
        $scope.gridOptions.data = data;
      });


    //delete admin category


    $scope.Delete = function (row) {

      console.log('data dekha', row);
      console.log('id to delete', row.entity.id);
      var index = $scope.gridOptions.data.indexOf(row.entity);
      console.log('ki khobor', index);
      $scope.gridOptions.data.splice(index, 1);


      $http.post('/category/destroy/' + row.entity.id).success(function (data) {
        console.log(data);

      })


    };


    $scope.Edit = function (row) {


      $state.go("base.admin.edit_category", {catid: row.entity.id});


    };
    $scope.viewMessage = function (row) {
      console.log(row.entity.id);
      $http.post('/message/get20Message', {'threadId': row.entity.id, 'limit': 20, 'skip': 0})
        .success(function (data, status, headers, config) {
          console.log(data);
          $scope.messageGridOptions.data = data;
          // get_archive_data_cb(data);
        })
        .error(function (data, status, headers, config) {
          console.log("message archive result failed");
          // get_archive_data_cb([]);
        });
      //$state.go("base.admin.edit_category", {catid:row.entity.id});


    };
    $scope.softDeleteChat = function (row) {
      // body...
      console.log(row);
      var is_up = {};

      if (row.entity.hasOwnProperty('is_deleted')) {
        if (row.entity.is_deleted) {
          is_up = {"is_deleted": false};

        } else {
          is_up = {"is_deleted": true};

        }
      }
      else {
        is_up = {"is_deleted": true};
      }
      console.log(is_up);
      $http.put('/message/' + row.entity.id, is_up)
        .success(function (data) {
          // body...
          console.log(data);
          row.entity.is_deleted = data.is_deleted;

        })
    };
    $scope.toggleFlat = function () {
      $scope.gridOptions.flatEntityAccess = !$scope.gridOptions.flatEntityAccess;
    }

  }]);
