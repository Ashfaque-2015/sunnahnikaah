angular.module('app')
  .controller('RegisterController', ['$scope', '$state', 'Auth', '$http', 'LocalService', 'Chat', 'CurrentUser', function($scope, $state, Auth, $http, LocalService,Chat,CurrentUser) {

    CurrentUser.setBodyClass();

    $scope.alerts =[];
    $scope.user = {};

    $scope.isRegLoading = false;
    $scope.isFullLoading = false;

    $scope.isDisable = false;

    $scope.successfullyRegistered = false;

    //if (LocalService.get('auth_token')) {
    //  if (angular.fromJson(LocalService.get('auth_token')).user.user_group == "admin") {
    //    $state.go('base.admin');
    //    //console.log("aise ekhane");
    //  } else {
    //    $state.go('base.user.dashboard');
    //  }
    //}

    var usernameFound = false;

    $scope.register = function() {
      console.log($scope.dt);
      $scope.isRegLoading = true;
      $scope.isDisable = true; //disable button

      $scope.alerts =[];
      $scope.user.dob = $scope.dt;
      $scope.user.dob_timestamp = new Date($scope.dt).getTime();
      $scope.user.user_group = "user";

      //edited
      var checkEmpty = false;

      if(!$scope.user.hasOwnProperty("username") || $scope.user.username=="")  {
        $scope.alerts.push({ type: 'danger', msg: 'Empty username' });
        checkEmpty = true;
      }
      else if(/\s/g.test($scope.user.username)){
        $scope.alerts.push({ type: 'danger', msg: 'Username cannot have space' });
        checkEmpty = true;
      }
      else if ($scope.user.username!="")  {

        var nameRegex = /^[a-zA-Z0-9]*/;
        //var validUsername ;//= $scope.user.username.match(nameRegex);
        if(!$scope.user.username.match(nameRegex)){
          $scope.alerts.push({type:'danger', msg:'Your Username is not valid. Only charascters A-Z, a-z and 0-9 are acceptable.'});
          $scope.isRegLoading = false;
        return false;
        }
      }

      if ((!$scope.user.hasOwnProperty("first_name"))|| $scope.user.first_name== "")  {
        $scope.alerts.push({ type: 'danger', msg: 'Empty firstname' });
        checkEmpty = true;
      }
      if ((! $scope.user.hasOwnProperty("email"))||$scope.user.email=="")  {
        $scope.alerts.push({ type: 'danger', msg: 'Empty Email' });
        checkEmpty = true;
      }
      if ((!$scope.user.hasOwnProperty("password")) || $scope.user.password=="")  {
        $scope.alerts.push({ type: 'danger', msg: 'Empty password' });
        checkEmpty = true;
      }
      if ((!$scope.user.hasOwnProperty("confirmPassword")) || $scope.user.confirmPassword=="")  {
        $scope.alerts.push({ type: 'danger', msg: 'confirm password' });
        checkEmpty = true;
      }
      if ($scope.user.password && $scope.user.confirmPassword)  {
        if ($scope.user.password !== $scope.user.confirmPassword)  {
          $scope.alerts.push({ type: 'danger', msg: 'Password and Confirm Password does not match' });
          checkEmpty = true;
        }
      }
      if ((!$scope.user.hasOwnProperty("dob"))|| $scope.user.dob=="")  {
       $scope.alerts.push({ type: 'danger', msg: 'Empty date of birth' });
        checkEmpty = true;
      }
      else{
        var ageDifMs = Date.now() - $scope.user.dob.getTime();
        var ageDate = new Date(ageDifMs); // miliseconds from epoch
        var age = Math.abs(ageDate.getUTCFullYear() - 1970);
        if(age < 16){
          checkEmpty = true;
          $scope.alerts.push({ type: 'danger', msg: 'You have to be at least 16' });
        }

      }
      if ((!$scope.user.hasOwnProperty("country")) || $scope.user.country=="") {
        $scope.alerts.push({ type: 'danger', msg: 'Empty country field' });
        checkEmpty = true;
      }
      if ((! $scope.user.hasOwnProperty("account_openning_for")) || $scope.user.account_openning_for== "")  {
        $scope.alerts.push({ type: 'danger', msg: 'Empty account opening field' });
        checkEmpty = true;
      }
      if ((!$scope.user.hasOwnProperty("gender"))|| $scope.user.gender== "")  {
        $scope.alerts.push({ type: 'danger', msg: 'Empty gender' });
        checkEmpty = true;
      }
      if ((!$scope.user.hasOwnProperty("observe_salah_completely")) || $scope.user.observe_salah_completely == "")  {
        $scope.alerts.push({ type: 'danger', msg: 'Empty observe salah' });
        checkEmpty = true;
      }
      //--------------------------------------------------
      if($("#email-chk").text() !== 'Available'){
        checkEmpty = true;
        $scope.alerts.push({ type: 'danger', msg: 'This email is not available' });
      }
      if($("#username-chk").text() !== 'Available'){
        checkEmpty = true;
        $scope.alerts.push({ type: 'danger', msg: 'This username is not available' });
      }
      //$("#email-chk").html('Available');
      //
      //$("#username-chk").html('Available');
      //---------------------------------------------------


      if(checkEmpty){
        $scope.isDisable = false; //reset register button

        $scope.isRegLoading = false;
        $(window).scrollTop(0);
        return 0;
      }
      //Chat.register_me($scope.user.username,"1234");
      //Chat.setChatLogin();
      //$('.chat-login-form').hide();
      //$('.chat-logout-form').show();



      Auth.register($scope.user)
      .success(function(data, status, headers, config) {

          console.log(data,status);
        //registering automatically to xmpp-jabberd server
        Chat.register_me(data.user.id, $scope.user.username, $scope.user.password, $scope.insertChatCredential,data.token);
        $scope.isDisable = false; //reset register button

      // success msg
          $scope.alerts.push({ type: 'success', msg: 'Registration successful.' });
          $(window).scrollTop(0);
          $scope.isRegLoading = false;
          $scope.isFullLoading = true;
      //

      })
      .error(function(data, status, headers, config) {
        console.log(data, status, headers, config);
          $scope.alerts.push({ type: 'danger', msg: 'Failed to register' });
          $scope.isRegLoading = false;
          $scope.isDisable = false; //reset register button
      });

      //Auth.register($scope.user).then(function(data) {
      //  if(data){
      //
      //  }
      //
      //});

    };

    //register callback to update jabberd credential into mongodb > user (jid and pass)
    $scope.insertChatCredential = function (userId, jid, password,token){
      //console.log("successfully ejabber e register hoye callback e esheche");
      var queryString = {"jid" : jid, "jpassword" : password};
      $http.put('/user/update/'+userId+'?',queryString).
        success(function(data, status, headers, config) {
          //console.log("successfully updated user");
          //console.log(data);
          //LocalService.set('auth_token', JSON.stringify({'user':data,'token':token}));
          //redirecting to user page
          //$state.go('base.user.dashboard');

          $scope.successfullyRegistered = true;
          $scope.isFullLoading = false;

        }).
        error(function(data, status, headers, config) {
          console.log("failed to updated user");
        })
    };

    $scope.goForLogin = function(){
      $state.go('base.login');
    }

    //datepicker
    $scope.today = function() {
      $scope.dt = new Date();
    };
    //$scope.today();
    $scope.clear = function () {
      $scope.dt = null;
    };
    // Disable weekend selection
    //$scope.disabled = function(date, mode) {
    //  return ( mode === 'day' && ( date.getDay() === 0 || date.getDay() === 6 ) );
    //};
    $scope.toggleMin = function() {
      $scope.minDate = $scope.minDate ? null : new Date();
    };
    $scope.toggleMin();
    $scope.open = function($event) {
      $event.preventDefault();
      $event.stopPropagation();
      $scope.opened = true;
    };
    $scope.dateOptions = {
      formatYear: 'yy',
      startingDay: 1
    };
    $scope.formats = ['dd-MMMM-yyyy','yyyy/MM/dd','dd.MM.yyyy','dd/MM/yyyy','shortDate'];
    $scope.format = $scope.formats[3];


    //dropdown country
    $scope.items = ["Afghanistan","Armenia","Azerbaijan","..."];
    $scope.status = {
      isopen: false
    };
    $scope.toggled = function(open) {
      $log.log('Dropdown is now: ', open);
    };
    $scope.toggleDropdown = function($event) {
      $event.preventDefault();
      $event.stopPropagation();
      $scope.status.isopen = !$scope.status.isopen;
    };

    $scope.findUniqueUsername = function(){

      if($scope.user.username){
        $scope.user.username = $scope.user.username.trim();
      }

    //check unique username
      if(!$scope.user.hasOwnProperty("username") || $scope.user.username === "" || (typeof $scope.user.username==='undefined')){
        $("#username-chk").html('Check Availabilty');
        $("#frm-register-username").removeClass("has-success");
        $("#frm-register-username").removeClass("has-error");
        return 0;
      }

      $("#username-chk").html('<i class="fa fa-refresh fa-spin"></i>');
      $("#frm-register-username").removeClass("has-success");
      $("#frm-register-username").removeClass("has-error");

    $http.post('/user/find?username='+$scope.user.username).
      success(function (data, status, headers, config) {
        console.log("successfull");
        console.log(data);
        if(data.length){
          usernameFound = true;
          //$scope.alerts.push({ type: 'danger', msg: 'Username already exist.' });
          $("#username-chk").html('Not Available');
          $("#frm-register-username").addClass("has-error");

          //if(!$scope.user.hasOwnProperty("username") || $scope.user.username === ""){
          //  $("#username-chk").html('empty');
          //  $("#frm-register-username").addClass("has-error");
          //}
        }else{
          //$scope.alerts.push({ type: 'success', msg: 'Username available' });
          $("#username-chk").html('Available');
          $("#frm-register-username").addClass("has-success");

          //if(!$scope.user.hasOwnProperty("username") || $scope.user.username === ""){
          //  $("#username-chk").html('empty');
          //  $("#frm-register-username").addClass("has-error");
          //}
        }
      }).
      error(function (err, data, status, headers, config) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
      });

      //if(!$scope.user.hasOwnProperty("username") || $scope.user.username === ""){
      //  $("#username-chk").html('empty');
      //  $("#frm-register-username").addClass("has-error");
      //}

    };

     $scope.findUniqueEmail = function(){


    //check unique username

        $("#frm-register-email").removeClass("has-success");
        $("#frm-register-email").removeClass("has-error");

       //check empty
        var empt = document.forms["registerForm"]["email"].value;
        if ( empt== "")  {
          //console.log("ekhane aise");
          $("#frm-register-email").removeClass("has-success");
          $("#frm-register-email").removeClass("has-error");
          $("#email-chk").html('Check Available');
          $scope.alerts.push({ type: 'danger', msg: 'Empty email' });
          return 0;
        }

       //check vaild email
       var mailFormat= /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
       if(!registerForm.email.value.match(mailFormat) ){
         $scope.alerts.push({ type: 'danger', msg: 'invalid email' });
         //return 0;
       }

        $("#email-chk").html('<i class="fa fa-refresh fa-spin"></i>');
          $http.post('/user/find?email='+$scope.user.email)
            .success(function (data, status, headers, config) {
              console.log("successfull");
              console.log(data);
              if(data.length){
                emailFound = true;
                //$scope.alerts.push({ type: 'danger', msg: 'Username already exist.' });
                $("#email-chk").html('Not Available');
                $("#frm-register-email").addClass("has-error");
              }
              else{
                //$scope.alerts.push({ type: 'success', msg: 'Username available' });
                $("#email-chk").html('Available');
                $("#frm-register-email").addClass("has-success");

              }
            })
            .error(function (err, data, status, headers, config) {
          // called asynchronously if an error occurs
          // or server returns response with an error status.
          });

    };

    $scope.closeAlert = function (index) {
      $scope.alerts.splice(index, 1);
    };

  }]);
