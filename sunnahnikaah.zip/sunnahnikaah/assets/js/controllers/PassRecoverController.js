angular.module('app')
  .controller('PassRecoverController', ['$scope', '$state', '$stateParams', '$http', 'Auth', 'CurrentUser', 'LocalService', 'Chat', function ($scope, $state, $stateParams, $http, Auth, CurrentUser, LocalService, Chat) {

    CurrentUser.setBodyClass();

    $scope.errors = [];

    var currentUser = CurrentUser.user();

    $scope.passcode = $stateParams.recovercode;


    //---Forget Pass Mail send --start---

    $http.post('/user/fprecover',{passcode : $stateParams.recovercode})
      .success(function (data, status, headers, config) {
        console.log("Query success");
        console.log(data);
        if(data.length) {
          console.log("pass code found");
          //$scope.alerts.push({type: 'success', msg: 'Email exist.'});


          $scope.user.uid = data[0].id;
          console.log($scope.user.uid);

        } else{
          //$scope.alerts.push({ type: 'danger', msg: 'Email Not exist.' });
          console.log("pass code Not found");

          $scope.$broadcast('PassCodeNotFound', {message: "current-thread-msg" });
          $state.go('base.forgotpassword',{'codeerr':'codeerror'});


        }
      })
      .error(function (err, data, status, headers, config) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
        console.log("Error");
      });


    //---Forget pass mail send ---end---




    $scope.PassChange = function() {
      $scope.alerts =[];


      //edited
      var checkEmpty = false;

      if ((!$scope.user.hasOwnProperty("password")) || $scope.user.password=="")  {
        $scope.alerts.push({ type: 'danger', msg: 'Empty password' });
        checkEmpty = true;
      }
      if ((!$scope.user.hasOwnProperty("confirmPassword")) || $scope.user.confirmPassword=="")  {
        $scope.alerts.push({ type: 'danger', msg: 'confirm password' });
        checkEmpty = true;
      }



      if(checkEmpty){
        return 0;
      }

      //---Forget Pass Mail send --start---

      $http.post('/user/passwordchange',$scope.user)
        .success(function (data, status, headers, config) {
          console.log("successfull send mail");
          console.log(data);

          if(data.hasOwnProperty('err') && data.err !=''){
            $scope.alerts.push({ type: 'danger', msg: data.err});
          }
          else{
            $state.go('base.login');
          }
        })
        .error(function (err, data, status, headers, config) {
          console.log(data, status, headers, config);
          $scope.alerts.push({ type: 'danger', msg: 'Failed to Change Pass' });
        });


      //---Forget pass mail send ---end---




      //Auth.register($scope.user)
      //  .success(function(data, status, headers, config) {
      //    //console.log(data,status);
      //    //registering automatically to xmpp-jabberd server
      //    Chat.register_me(data.user.id, $scope.user.username, $scope.user.password, $scope.insertChatCredential,data.token);
      //  })
      //  .error(function(data, status, headers, config) {
      //    console.log(data, status, headers, config);
      //    $scope.alerts.push({ type: 'danger', msg: 'Failed to register' });
      //  });



    }




    console.log($scope.passcode);

    $scope.closeAlert = function (index) {
      $scope.alerts.splice(index, 1);
    };


  }]);
