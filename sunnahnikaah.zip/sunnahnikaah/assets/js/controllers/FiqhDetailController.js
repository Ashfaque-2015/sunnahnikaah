angular.module('app')
  .controller('FiqhDetailController', ['$scope', '$stateParams', '$http', '$state', '$sce', '$location', function ($scope, $stateParams, $http,$state,$sce,$location) {
    //console.log('Fiqh Detail Controller - params',$stateParams.fiqh_id);
    $scope.fiqh = {};
    $http.get('/fiqh/'+$stateParams.fiqh_id).success(function(data, status){
      $scope.fiqh = data;
      //console.log($scope.fiqh);
    });

    $scope.renderHtml = function(code)
    {
      //code = '<img src="'+$scope.fiqh.fiqh_image+ '" class="pull-right" alt=""/>'+code;
      return $sce.trustAsHtml(code);
    };

    $scope.currentUrl = $location.path();

  }]);
