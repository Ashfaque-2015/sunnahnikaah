angular.module('app')
  .controller('ArticleCategoryController', ['$scope', '$http', 'CurrentUser', '$state', function($scope,$http,CurrentUser,$state) {
    //console.log('LibraryCategory Controller - state cat_slug',$state.params.cat_slug);
    //console.log('LibraryCategory Controller - state cat_id',$state.params.cat_id);
    $scope.catPosts = {};


    $http.get('/blog?post_category='+$state.params.cat_id).success(function(data, status){
      //console.log('blog data', data);
      $scope.catPosts = data;
    });

  }]);
