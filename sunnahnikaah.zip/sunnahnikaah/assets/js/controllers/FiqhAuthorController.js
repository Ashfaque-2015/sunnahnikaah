angular.module('app')
  .controller('FiqhAuthorController', ['$scope', '$http', 'CurrentUser', '$state', function($scope,$http,CurrentUser,$state) {
    console.log('FiqhAuthor Controller - state author_slug',$state.params.author_slug);
    console.log('FiqhAuthor Controller - state author_id',$state.params.author_id);
    $scope.authorFiqhs = {};


    $http.get('/fiqh?fiqh_author='+$state.params.author_id).success(function(data, status){
      $scope.authorFiqhs = data;
    });

  }]);
