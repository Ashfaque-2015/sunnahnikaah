angular.module('app')
  .controller('BlogDetailController', ['$scope', '$stateParams', '$http', function($scope, $stateParams, $http) {

    var blog_id = $stateParams.blog_id;

    console.log("blog detail controller");
    $http.get("blog/"+blog_id).success(function(data, status){
      console.log(status);
      console.log(data);
      $scope.blog = data;
    });
    }]);
