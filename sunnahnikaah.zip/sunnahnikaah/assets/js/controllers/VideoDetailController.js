angular.module('app')
  .controller('VideoDetailController', ['$scope', '$stateParams', '$http', '$state', function ($scope, $stateParams, $http,$state) {
    //console.log('Video Detail Controller - params',$stateParams.video_id);
    $scope.video = {};
    $http.get('/video/'+$stateParams.video_id).success(function(data, status){
      $scope.video = data;
      //console.log($scope.video);
    });
  }]);
