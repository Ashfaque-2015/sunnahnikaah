/**
 * Created by rbn-imac on 8/5/15.
 */
angular.module('app')
  .controller('ArticleTagController', ['$scope', '$http', 'CurrentUser', '$state', function($scope,$http,CurrentUser,$state) {
    //console.log('ArticleTag Controller - state tag_name',$state.params.tag_title);
    //console.log('ArticleTag Controller - state tag_id',$state.params.tag_id);



    $scope.tagPosts = {};
    $http.get('/blog?where={tag_blogs:{tag:'+$state.params.tag_id+'}}').success(function(data, status){
      $scope.tagPosts = data;
      //console.log('post by tag: ',data);
    });
  }]);

