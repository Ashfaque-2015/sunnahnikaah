angular.module('app')
  .controller('LoginController', ['$scope', '$state', 'Auth', 'CurrentUser', 'LocalService', 'Chat', function ($scope, $state, Auth, CurrentUser, LocalService, Chat) {
    CurrentUser.setBodyClass();

    $scope.isFullLoading = false;

    $scope.errors = [];

    var currentUser = CurrentUser.user();

    if (LocalService.get('auth_token')) {
      if (angular.fromJson(LocalService.get('auth_token')).user.user_group == "admin") {
        $state.go('base.admin');
        //console.log("aise ekhane");
      } else {
        $state.go('base.user.dashboard');
      }
    }

    $scope.login = function () {
      $scope.isFullLoading = true;
      $scope.errors = [];
      Auth.login($scope.user).success(function (result) {

        //console.log("aise ekhane");

        //chat login now added at messageController
        //result.user.jid = "ash2@sunnahnikaah.com";
        //result.user.jpassword = "1234";


        //now chat server login is accomplished at basecontroller so no need here
        //if(result.user.hasOwnProperty("jid") && result.user.jid != "" && result.user.hasOwnProperty("jpassword") && result.user.jpassword != ""){
        //  Chat.connect_me_now(result.user.jid, result.user.jpassword);
        //  //initialize roster
        //  $scope.$emit("eventInitializeRoster");
        //}

        //console.log(result);

        if (LocalService.get('auth_token')) {

          if (angular.fromJson(LocalService.get('auth_token')).user.user_group == "admin") {
            $state.go('base.admin');
            //console.log("aise ekhane");
          } else {
            console.log("ekhane aise");
            $state.go('base.user.dashboard');
          }
        }
      })
        .error(function (err) {
          $scope.isFullLoading = false;
          $scope.errors.push(err);
        });
    };

    $scope.closeAlert = function (index) {
      $scope.errors.splice(index, 1);
    };

  }])
  .directive('autoFocus', ['$timeout', function($timeout) {
    return {
      restrict: 'AC',
      link: function(_scope, _element) {
        $timeout(function(){
          _element[0].focus();
        }, 0);
      }
    };
  }]);
