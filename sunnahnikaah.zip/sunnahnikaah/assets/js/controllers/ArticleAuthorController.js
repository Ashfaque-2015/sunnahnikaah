angular.module('app')
  .controller('ArticleAuthorController', ['$scope', '$http', 'CurrentUser', '$state', function($scope,$http,CurrentUser,$state) {
    //console.log('ArticleAuthor Controller - state author_slug',$state.params.author_slug);
    //console.log('ArticleAuthor Controller - state author_id',$state.params.author_id);
    $scope.authorPosts = {};


    $http.get('/blog?post_author='+$state.params.author_id).success(function(data, status){
      $scope.authorPosts = data;
    });

  }]);
