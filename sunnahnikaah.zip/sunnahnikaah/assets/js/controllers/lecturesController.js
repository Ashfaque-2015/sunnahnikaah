angular.module('app')
  .controller('LecturesController', ['$scope', function($scope) {









    }]);
