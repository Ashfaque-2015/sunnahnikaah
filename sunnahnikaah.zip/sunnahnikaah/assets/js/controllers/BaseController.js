angular.module('app')
  .controller('BaseController', ['$scope', '$rootScope', '$state', '$http', 'Auth', 'CurrentUser', '$translate', 'Chat', 'LocalService', '$timeout', 'ngAudio', '$modal', '$log','toastr', function ($scope, $rootScope, $state, $http, Auth, CurrentUser, $translate, Chat, LocalService,$timeout,ngAudio,$modal,$log,toastr) {
    console.log("base controller");


      console.log("janar");

    document.mast = $scope;

    if($state.current.data.access == 0)
      $rootScope.bodyclass = "guest-body";
    else if($state.current.data.access == 1)
      $rootScope.bodyclass = "user-body";
    else if($state.current.data.access == 2)
      $rootScope.bodyclass = "admin-body";

    //
    $scope.fallbackimage = "/images/others/placeholder.jpg";
    //


    $scope.showSpinner = true;
    $scope.emptyThread = false;
    $scope.notification_count = 0;
    $scope.roster_thread_list = [];
    $scope.demoAvatar = "images/demo-profile-pic.png";
    $scope.demoAvatarMale = "images/user/profile-pic-male.png";
    $scope.demoAvatarFemale = "images/user/profile-pic-female.png";
    $scope.sound = ngAudio.load("sounds/blop.wav");


    $rootScope.$watch('online', function(newValue, oldValue) {
      console.log(oldValue,newValue);

      //chat disconnect modal
      if(!newValue){
        //$scope.animationsEnabled = true;
        //
        //var modalInstance = $modal.open({
        //  animation: $scope.animationsEnabled,
        //  //templateUrl: 'templates/other/modalChatDisconnect.html',
        //  template: '<h2>Chat Server Disconnected</h2><p>Please check internet connection</p>',
        //  controller: 'ChatDisconnectModalInstanceCtrl',
        //  resolve: {
        //    items: function () {
        //      return [];
        //    }
        //  }
        //});
        //
        //
        //modalInstance.result.then(function (selectedItem) {
        //  $scope.selected = selectedItem;
        //}, function () {
        //  $log.info('Modal dismissed at: ' + new Date());
        //});

        //toastr.success('Chat Server Disconnected...','Disconnect!');

      }else{
        //Chat.connect_me_now();
        console.log("Chat.connected");
        console.log(Chat.connected);
      }
    });


    $scope.unread_notify = function(){
      console.log("unread_notify");
      $scope.sound.play();
    };

    $scope.unread_notify2 = function(){
      console.log("unread_notify2");
      $scope.sound.stop();
    };
    //window.MY_SCOPE = $scope;
    //window.chatObj = Chat;
    $translate.use('en_EN'); //setting english as default

    $scope.isCollapsed = true;
    $scope.auth = Auth;
    var CurntUser = $scope.user = CurrentUser.user();

    //================chat on message handler=======================//
    $scope.update_message_archive_cb = function (msgData, message) {
      if($scope.roster_thread_list.length){
        $timeout(function(){
          for(var index in $scope.roster_thread_list) {
            if($scope.roster_thread_list[index].id==msgData.thread[0].id){
              msgData.thread[0].totalNotification = 0;
              if (CurntUser.id != msgData.thread[0].me && CurntUser.id == msgData.thread[0].other_user) {
                if(msgData.thread[0].hasOwnProperty('other_user_unread_notification') && msgData.thread[0].other_user_unread_notification){
                  msgData.thread[0].totalNotification = msgData.thread[0].other_user_unread_notification;
                }
              }
              else if (CurntUser.id == msgData.thread[0].me && CurntUser.id != msgData.thread[0].other_user) {
                if(msgData.thread[0].hasOwnProperty('me_unread_notification') && msgData.thread[0].me_unread_notification){
                  msgData.thread[0].totalNotification = msgData.thread[0].me_unread_notification;
                }
              }

              $scope.roster_thread_list[index] = msgData.thread[0];
              //console.log($scope.roster_thread_list);
              $scope.showNotification();
            }
          }
        });
      }
      $scope.$broadcast('unread_message_notification', {threadmsg:msgData});

    };
    //received message will be updated in mongodb and the status will as read
    $scope.on_message_nav = function (message) {

      console.log("on_message_nav");
      console.log(message);

      var full_jid = $(message).attr('from');
      var from_jid = Strophe.getBareJidFromJid(full_jid);
      //var jid_id = jid.match(/^([^@]*)@/)[1];
      var jid_id = Chat.jid_to_id(from_jid);
      var me_jid = Strophe.getBareJidFromJid($(message).attr('to'));

      var from_jid_msg_viewing = "";

      //when user at chat detail page and chatting with same user
      if ($state.current.name == 'base.user.messages.detail' && $rootScope.currentChatUser.hasOwnProperty("jid") && $rootScope.currentChatUser.jid == from_jid) {
        //console.log("ami currently er ("+$rootScope.currentChatUser.jid+") shathei chat korchi");
        from_jid_msg_viewing = "viewing";
        console.log("eto para dey keno",from_jid_msg_viewing);
      }
      // when user at chat detail page but not chatting with or not at chat detail page
      else{// if ($state.current.name == 'base.user.messages.detail' && $rootScope.currentChatUser.hasOwnProperty("jid") && $rootScope.currentChatUser.jid != from_jid) {
        //console.log("ami currently er ("+$rootScope.currentChatUser.jid+") shathe chat korchi na");
        from_jid_msg_viewing = "not-viewing";
        //console.log("eto para dey keno",from_jid_msg_viewing);
      }


      //place the calculated height for chat area
      var body = $(message).find("html > body");
      var recMessages = [];

      if (body.length === 0) {
        //console.log("body.lenth === 0");
        body = $(message).find('body');
        if (body.length > 0) {
          body = body.text();
          recMessages.push(body);
        }
        else {
          body = null;
        }
      }
      else {
        body = body.contents();
        //var span = $("<span></span>");
        body.each(function () {
          if (document.importNode) {
            //$(document.importNode(this, true)).appendTo(span);
            recMessages.push(this);
            recMessages.push("ash");
          }
          else {
            // IE workaround
            span.append(this.xml);
            recMessages.push(this.xml);
            recMessages.push("dash");
          }
        });

        //body = span;
      }

      //console.log("recMessages.length",recMessages.length);

      if (recMessages.length) {
        var msgThread = $(message).find("thread");
        var msgidText = $(message).find("msgid");
        var threadId = -1, msgid = -1;

        //console.log(msgThread,msgidText);
        //console.log(msgThread.text(), msgidText.text());

        //login imposed, only those chat message will be saved which will be under sunnahnikaah web or mobile app
        if (msgThread.text() && msgidText.text()) {
          threadId = msgThread.text();
          msgid = msgidText.text();

          //console.log('threadId:',threadId,'msgid:',msgid);

          if (threadId != -1 && msgid != -1) {
            Chat.update_message_archive(recMessages, from_jid, me_jid, threadId, "receivemsg", msgid, from_jid_msg_viewing, $scope.update_message_archive_cb);
            if(from_jid_msg_viewing == "not-viewing"){
              $scope.sound.play();
            }
          }
        }
      }

      return true;
    };

    //if (Chat.connection && !Chat.notification_handler) {
    //  console.log('on_message_nav handler add korte aise');
    //  Chat.notification_handler = Chat.connection.addHandler($scope.on_message_nav, null, "message", "chat");
    //}

    if(Chat.connection){

      if(!Chat.handlersObj.hasOwnProperty('m_basectl_on_message_nav') ){
        console.log('on_message_nav handler add korte aise user loggedin and just refresh the page');
        var onmsghandler =  Chat.connection.addHandler($scope.on_message_nav, null, "message", "chat");
        if(onmsghandler){
          Chat.handlers.push({m_basectl_on_message_nav:onmsghandler});
          Chat.handlersObj.m_basectl_on_message_nav = onmsghandler;
        }
      }

    }
    //================end of chat on message handler=======================//

    //================event handler=======================//
    $scope.eventDecreaseChatNotification_cb = function (event, args) {
      $timeout(function () {
        for (var index in $scope.roster_thread_list) {
          //console.log("index", index);

          if ($scope.roster_thread_list[index].id == args.thread.id) {
            $scope.roster_thread_list[index].me_unread_notification = args.thread.me_unread_notification;
            $scope.roster_thread_list[index].other_user_unread_notification = args.thread.other_user_unread_notification;
            $scope.roster_thread_list[index].totalNotification = 0;
          }
        }
        $scope.showNotification();
      });

    };
    $scope.$on("eventDecreaseChatNotification", $scope.eventDecreaseChatNotification_cb);
    //================end of event handler=======================//

    $scope.logout = function () {
      Auth.logout();
      //LocalService.unset('auth_chat_token');
      Chat.disconnect_me();
      LocalService.unset('auth_chat_token');
      $rootScope.bodyclass = "guest-body";
      $state.go('base');
    }

    //$(window).bind('beforeunload',function(ev){
    //  return false;
    //});

    $scope.compare = function (a, b) {
      return new Date(b.updatedAt) - new Date(a.updatedAt); //sorting as descending order
    };

    $scope.showNotification = function(){
      //console.log($scope.roster_thread_list);

      $scope.notification_count = 0;
      $scope.roster_thread_list.forEach(function(eachThread){
        //console.log("eachThread.totalNotification",eachThread.totalNotification);
        if(eachThread.totalNotification)
          $scope.notification_count++;
      });
      //console.log($scope.notification_count);
    }

    $scope.getRosterContactDetail = function (eachThread, roster_user_list) {
      //console.log(eachThread, roster_user_list);
      roster_user_list.forEach(function (eachUser) {
        if ((eachUser.id != eachThread.me && eachUser.id == eachThread.other_user) || (eachUser.id != eachThread.other_user && eachUser.id == eachThread.me)) {
          eachThread.roster_contact_detail = eachUser;
          eachThread.roster_contact_detail.jid_class = Chat.jid_to_id(eachThread.roster_contact_detail.jid);
        }
      });
    };

    $scope.getRosterContacts = function (limit) {
      $scope.showSpinner = true;
      $scope.emptyThread = false;
      //console.log("getRosterContacts");
      var CurntUser = CurrentUser.user();
      $http.post('/thread/populateMyRosterContacts',{userId:CurntUser.id,count:limit}).success(function(data){
        console.log(data);
        if(data.length){
          $scope.roster_thread_list = data;

          for (var index in $scope.roster_thread_list) {
            $scope.roster_thread_list[index].totalNotification = 0
            if (CurntUser.id != $scope.roster_thread_list[index].me.id && CurntUser.id == $scope.roster_thread_list[index].other_user.id) {
              $scope.roster_thread_list[index].roster_contact_detail = $scope.roster_thread_list[index].me;
              if($scope.roster_thread_list[index].hasOwnProperty('other_user_unread_notification') && $scope.roster_thread_list[index].other_user_unread_notification){
                $scope.roster_thread_list[index].totalNotification = $scope.roster_thread_list[index].other_user_unread_notification;
              }
            }
            else if (CurntUser.id == $scope.roster_thread_list[index].me.id && CurntUser.id != $scope.roster_thread_list[index].other_user.id) {

              $scope.roster_thread_list[index].roster_contact_detail = $scope.roster_thread_list[index].other_user;
              if($scope.roster_thread_list[index].hasOwnProperty('me_unread_notification') && $scope.roster_thread_list[index].me_unread_notification){
                $scope.roster_thread_list[index].totalNotification = $scope.roster_thread_list[index].me_unread_notification;
              }
            }
            $scope.showSpinner = false;
          }

          $scope.showNotification();
        }
        else{
          $scope.showSpinner = false;
          $scope.emptyThread = true;
        }

      });
    }

    //$scope.getRosterContacts_old = function () {
    //  $scope.showSpinner = true;
    //  $scope.emptyThread = false;
    //
    //  $http.get('/user/' + CurntUser.id)
    //    .success(function (data) {
    //      //find threads
    //      if (data.threads1.length) {
    //        data.threads1.forEach(function (eachObj) {
    //          $scope.roster_thread_list.push(eachObj);
    //        });
    //      }
    //      if (data.threads2.length) {
    //        data.threads2.forEach(function (eachObj) {
    //          $scope.roster_thread_list.push(eachObj);
    //        });
    //      }
    //
    //      //sorting threads based on updatedAt time
    //      if($scope.roster_thread_list.length){
    //        $scope.roster_thread_list.sort($scope.compare);
    //
    //        var myContacts = [];
    //
    //        for (var index in $scope.roster_thread_list) {
    //          $scope.roster_thread_list[index].totalNotification = 0
    //          if (CurntUser.id != $scope.roster_thread_list[index].me && CurntUser.id == $scope.roster_thread_list[index].other_user) {
    //            myContacts.push($scope.roster_thread_list[index].me);
    //            if($scope.roster_thread_list[index].hasOwnProperty('other_user_unread_notification') && $scope.roster_thread_list[index].other_user_unread_notification){
    //              $scope.roster_thread_list[index].totalNotification = $scope.roster_thread_list[index].other_user_unread_notification;
    //            }
    //          }
    //          else if (CurntUser.id == $scope.roster_thread_list[index].me && CurntUser.id != $scope.roster_thread_list[index].other_user) {
    //            myContacts.push($scope.roster_thread_list[index].other_user);
    //            if($scope.roster_thread_list[index].hasOwnProperty('me_unread_notification') && $scope.roster_thread_list[index].me_unread_notification){
    //              $scope.roster_thread_list[index].totalNotification = $scope.roster_thread_list[index].me_unread_notification;
    //            }
    //          }
    //          $scope.showSpinner = false;
    //        }
    //
    //        $scope.showNotification();
    //
    //        //get roster contacts detail from user model
    //        $http.get('/user?where={"id":' + JSON.stringify(myContacts) + '}')
    //          .success(function (result) {
    //            //console.log("roster list ", result);
    //            $scope.roster_user_list = result;
    //
    //            //map thread and user
    //            $scope.roster_thread_list.forEach(function (eachThread) {
    //              $scope.getRosterContactDetail(eachThread, $scope.roster_user_list);
    //            });
    //          });
    //      }
    //      else{
    //        $scope.showSpinner = false;
    //        $scope.emptyThread = true;
    //      }
    //
    //    })
    //    .error(function (err) {
    //      console.log(err);
    //    });
    //};

    //this function is invoking from main navigation > message and rendering roster contacts on dropdown
    $scope.loadThread = function () {
      console.log('loadThread-----');
      $scope.roster_thread_list = [];
      $scope.getRosterContacts(10);
    }


    //initially render notification
    if(Auth.isAuthenticated()){
      $scope.getRosterContacts(10);
      console.log("Auth.isAuthenticated()----");
    }


    $scope.$on("eventInitializeRoster",function(){
      console.log("eventInitializeRoster---");

      if(Chat.connection){
        if(!Chat.handlersObj.hasOwnProperty('m_basectl2_on_message_nav') ){
          console.log('on_message_nav handler add korte aise after login');
          var onmsghandler =  Chat.connection.addHandler($scope.on_message_nav, null, "message", "chat");
          if(onmsghandler){
            Chat.handlers.push({m_basectl2_on_message_nav:onmsghandler});
            Chat.handlersObj.m_basectl2_on_message_nav = onmsghandler;
          }
        }

      }

      $scope.getRosterContacts(10);
    });

    //////////////////homecontroller////////////////////////////
    $scope.toggleLang = function () {
      $translate.use() === 'en_EN'? $translate.use('de_DE') : $translate.use('en_EN');
      console.log($translate.use());
    };
















      CurrentUser.setBodyClass();

      $scope.isFullLoading = false;

      $scope.errors = [];

      var currentUser = CurrentUser.user();

      if (LocalService.get('auth_token')) {
        if (angular.fromJson(LocalService.get('auth_token')).user.user_group == "admin") {
          $state.go('base.admin');
          //console.log("aise ekhane");
        } else {
          $state.go('base.user.dashboard');
        }
      }

      $scope.login = function () {
        $scope.isFullLoading = true;
        $scope.errors = [];
        Auth.login($scope.user).success(function (result) {

          //console.log("aise ekhane");

          //chat login now added at messageController
          //result.user.jid = "ash2@sunnahnikaah.com";
          //result.user.jpassword = "1234";


          //now chat server login is accomplished at basecontroller so no need here
          //if(result.user.hasOwnProperty("jid") && result.user.jid != "" && result.user.hasOwnProperty("jpassword") && result.user.jpassword != ""){
          //  Chat.connect_me_now(result.user.jid, result.user.jpassword);
          //  //initialize roster
          //  $scope.$emit("eventInitializeRoster");
          //}

          //console.log(result);

          if (LocalService.get('auth_token')) {

            if (angular.fromJson(LocalService.get('auth_token')).user.user_group == "admin") {
              $state.go('base.admin');
              //console.log("aise ekhane");
            } else {
              console.log("ekhane aise");
              $state.go('base.user.dashboard');
            }
          }
        })
            .error(function (err) {
              $scope.isFullLoading = false;
              toastr.error('Username and Password Required', 'Error');
              //$scope.errors.push(err);
            });
      };

      $scope.closeAlert = function (index) {
        $scope.errors.splice(index, 1);
      };


    }]);
