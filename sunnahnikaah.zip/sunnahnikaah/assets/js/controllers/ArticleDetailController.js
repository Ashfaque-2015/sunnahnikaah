angular.module('app')
  .controller('ArticleDetailController', ['$scope', '$stateParams', '$http', '$state', '$sce', '$location', function ($scope, $stateParams, $http,$state,$sce,$location) {
    //console.log('Library Detail Controller - params',$stateParams.post_id);
    $scope.post = {};
    $http.get('/blog/'+$stateParams.post_id).success(function(data, status){
      $scope.post = data;
      //console.log($scope.post);
    });

    $scope.renderHtml = function(code)
    {
      //code = '<img src="'+$scope.post.post_image+ '" class="pull-right" alt=""/>'+code;
      return $sce.trustAsHtml(code);
    };


    $scope.currentUrl = $location.path();
    console.log('current url',$scope.currentUrl);


    //var category_id = $stateParams.category_id;
    //
    //
    //console.log("library detail controller");
    //$http.get("category/" + category_id).success(function (data, status) {
    //  console.log(status);
    //  console.log(data);
    //  $scope.category = data;
    //});

  }]);
