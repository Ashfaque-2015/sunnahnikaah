angular.module('app')
  .controller('VideoAuthorController', ['$scope', '$http', 'CurrentUser', '$state', function($scope,$http,CurrentUser,$state) {
    console.log('VideoAuthor Controller - state author_slug',$state.params.author_slug);
    console.log('VideoAuthor Controller - state author_id',$state.params.author_id);
    $scope.authorVideos = {};

    $http.get('/video?video_author='+$state.params.author_id).success(function(data, status){
      $scope.authorVideos = data;
      console.log('authorVideos',data);
    });

  }]);
