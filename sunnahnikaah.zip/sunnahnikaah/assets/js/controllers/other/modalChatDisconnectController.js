angular.module('app').controller('ChatDisconnectModalInstanceCtrl', ['$scope', '$modalInstance', 'items', function ($scope, $modalInstance, items) {

  $scope.items = items;
  $scope.selected = {
    item: $scope.items[0]
  };

  $scope.connectNow = function () {
    $modalInstance.close($scope.selected.item);
  };

  $scope.logout = function () {
    $modalInstance.dismiss('cancel');
  };
}]);
