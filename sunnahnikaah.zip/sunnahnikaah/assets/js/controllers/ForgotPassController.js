angular.module('app')
  .controller('ForgotPassController', ['$scope', '$state', '$stateParams', '$http', 'Auth', 'CurrentUser', 'LocalService', 'Chat', function ($scope, $state, $stateParams, $http, Auth, CurrentUser, LocalService, Chat) {
    CurrentUser.setBodyClass();
    $scope.errors = [];

    var currentUser = CurrentUser.user();

    $scope.errcodemsg = $stateParams.codeerr;
    $scope.alerts = [];
    if ($scope.errcodemsg == 'codeerror') {
      $scope.alerts.push({type: 'danger', msg: 'Your link is invalied please send again'});
    }

    $scope.shomsg = false;
    $scope.shofrm = true;

    //$scope.ForgotPassSendMail = function(){
    //  //check unique username
    //
    //
    //  $scope.alerts =[];
    //
    //
    //  $("#frm-forgot-email").removeClass("has-success");
    //  $("#frm-forgot-email").removeClass("has-error");
    //
    //  //check empty
    //  var empt = document.forms["forgotpassForm"]["uemail"].value;
    //  if ( empt== "")  {
    //    //console.log("ekhane aise");
    //    $("#frm-forgot-email").removeClass("has-success");
    //    $("#frm-forgot-email").removeClass("has-error");
    //    $("#email-chk").html('Check Available');
    //    $scope.alerts.push({ type: 'danger', msg: 'Empty email' });
    //    return 0;
    //  }
    //
    //  //check vaild email
    //  var mailFormat= /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    //  if(!forgotpassForm.uemail.value.match(mailFormat) ){
    //    $scope.alerts.push({ type: 'danger', msg: 'invalid email' });
    //    //return 0;
    //  }
    //
    //
    //  $http.post('/user/find?email='+$scope.user.email)
    //    .success(function (data, status, headers, config) {
    //      console.log("successfull");
    //      console.log(data);
    //      if(data.length){
    //        emailFound = true;
    //        $scope.alerts.push({ type: 'success', msg: 'Email exist.' });
    //        $("#frm-forgot-email").addClass("has-success");
    //
    //        //---Forget Pass Mail send --start---
    //
    //        $http.post('/user/forpassmail?email='+$scope.user)
    //          .success(function (data, status, headers, config) {
    //            console.log("successfull send mail");
    //            console.log(data);
    //
    //
    //              //$scope.alerts.push({ type: 'success', msg: 'Email exist.' });
    //              //$("#frm-forgot-email").addClass("has-success");
    //
    //
    //
    //          })
    //          .error(function (err, data, status, headers, config) {
    //            // called asynchronously if an error occurs
    //            // or server returns response with an error status.
    //          });
    //
    //
    //        //---Forget pass mail send ---end---
    //
    //
    //
    //
    //
    //
    //
    //      }
    //      else{
    //        $scope.alerts.push({ type: 'danger', msg: 'Email Not exist.' });
    //        //$("#email-chk").html('Not Available');
    //        $("#frm-forgot-email").addClass("has-error");
    //
    //
    //      }
    //    })
    //    .error(function (err, data, status, headers, config) {
    //      // called asynchronously if an error occurs
    //      // or server returns response with an error status.
    //    });
    //
    //}

    $scope.ForgotPassSendMail = function () {
      //check unique username


      $scope.alerts = [];


      $("#frm-forgot-email").removeClass("has-success");
      $("#frm-forgot-email").removeClass("has-error");

      //check empty
      var empt = document.forms["forgotpassForm"]["uemail"].value;
      if (empt == "") {
        //console.log("ekhane aise");
        $("#frm-forgot-email").removeClass("has-success");
        $("#frm-forgot-email").removeClass("has-error");

        $scope.alerts.push({type: 'danger', msg: 'Empty email'});
        return 0;
      }

      //check vaild email
      var mailFormat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
      if (!forgotpassForm.uemail.value.match(mailFormat)) {
        $scope.alerts.push({type: 'danger', msg: 'invalid email'});
        //return 0;
      }


      //---Forget Pass Mail send --start---

      $http.post('/user/forpassmail', {userEmail: $scope.user.email})
        .success(function (data, status, headers, config) {
          console.log("successfull send mail");
          console.log(data);
          if (data.length) {
            emailFound = true;
            //$scope.alerts.push({type: 'success', msg: 'Please check Email'});

            $scope.shomsg = true;
            $scope.shofrm = false;


            $("#frm-forgot-email").addClass("has-success");
          } else {
            $scope.alerts.push({type: 'danger', msg: 'Email Not exist.'});
            //$("#email-chk").html('Not Available');
            $("#frm-forgot-email").addClass("has-error");
          }
        })
        .error(function (err, data, status, headers, config) {
          // called asynchronously if an error occurs
          // or server returns response with an error status.
        });


      //---Forget pass mail send ---end---


    }

    $scope.$on('PassCodeNotFound', function (event, args) {
      console.log('hello hello');


    });

    $scope.closeAlert = function (index) {
      $scope.alerts.splice(index, 1);
    };

  }]);
