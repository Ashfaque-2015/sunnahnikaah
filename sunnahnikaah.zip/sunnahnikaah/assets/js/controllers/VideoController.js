angular.module('app')
  .controller('VideoController', ['$scope', '$http', 'CurrentUser', function($scope,$http,CurrentUser) {
    console.log('VideoController');

    $scope.isLoading = true;

    CurrentUser.setBodyClass();
    $scope.videos = {};
    $scope.currentVideos = {};
    $scope.categories = {};
    $scope.authors = {};
    $scope.tags = {};




    $http.get("/videocategory").success(function(data, status){
      //console.log('category data: ',data);
      $scope.categories = data;
    });

    $scope.categoryShowHide = function(category){
      if(category.videos.length===0){
        return true;
      }
      return false;
    };

    $http.get("/author").success(function(data, status){
      //console.log('author data: ',data);
      $scope.authors = data;
    });

    $scope.authorShowHide = function(author){
      if(author.author_videos.length===0){
        return true;
      }
      return false;
    };

    $http.get("/tag").success(function(data, status){
      //console.log('tag data: ',data);
      $scope.tags = data;
    });

    $scope.tagShowHide = function(tag){
      if(tag.video_tags.length===0){
        return true;
      }
      return false;
    };

    $http.get('/video').success(function(data, status){
      //console.log('video data: ',data);
      $scope.videos = data;
      //console.log('current Videos',$scope.currentVideos);
      $scope.isLoading = false;
    });


  }]);
