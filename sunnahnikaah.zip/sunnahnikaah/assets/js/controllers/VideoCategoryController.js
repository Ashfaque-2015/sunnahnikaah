angular.module('app')
  .controller('VideoCategoryController', ['$scope', '$http', 'CurrentUser', '$state', function($scope,$http,CurrentUser,$state) {
    console.log('VideoCategory Controller - state cat_slug',$state.params.cat_slug);
    console.log('VideoCategory Controller - state cat_id',$state.params.cat_id);
    $scope.catVideos = {};


    $http.get('/video?video_category='+$state.params.cat_id).success(function(data, status){
      $scope.catVideos = data;
    });

  }]);
