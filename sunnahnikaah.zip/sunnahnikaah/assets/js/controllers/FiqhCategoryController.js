angular.module('app')
  .controller('FiqhCategoryController', ['$scope', '$http', 'CurrentUser', '$state', function($scope,$http,CurrentUser,$state) {
    console.log('FiqhCategory Controller - state cat_slug',$state.params.cat_slug);
    console.log('FiqhCategory Controller - state cat_id',$state.params.cat_id);
    $scope.catFiqhs = {};


    $http.get('/fiqh?fiqh_category='+$state.params.cat_id).success(function(data, status){
      $scope.catFiqhs = data;
    });

  }]);
