angular.module('app')
  .controller('FiqhController', ['$scope', '$http', 'CurrentUser', function($scope,$http,CurrentUser) {
    CurrentUser.setBodyClass();
    $scope.isLoading = true;
    $scope.fiqhs = {};
    $scope.currentPosts = {};
    $scope.categories = {};
    $scope.authors = {};
    $scope.tags = {};




    $http.get("/fiqhcategory").success(function(data, status){
      //console.log('category data: ',data);
      $scope.categories = data;
    });

    $scope.categoryShowHide = function(category){
      if(category.fiqhs.length===0){
        return true;
      }
      return false;
    };

    $http.get("/author").success(function(data, status){
      //console.log('author data: ',data);
      $scope.authors = data;
    });

    $scope.authorShowHide = function(author){
      if(author.author_fiqhs.length===0){
        return true;
      }
      return false;
    };

    $http.get("/tag").success(function(data, status){
      //console.log('tag data: ',data);
      $scope.tags = data;
    });

    $scope.tagShowHide = function(tag){
      if(tag.fiqh_tags.length===0){
        return true;
      }
      return false;
    };

    $http.get('/fiqh').success(function(data, status){
      //console.log('fiqh data: ',data);
      $scope.fiqhs = data;

      $scope.isLoading = false;
    });

    //$scope.loadArticleByCategory = function(category){
    //  console.log('clicked Category id',category.id);
    //
    //  $http.get('/fiqh?fiqh_category='+category.id).success(function(data,status){
    //    $scope.currentPosts = data;
    //  });
    //};
    //
    //$scope.loadArticleByAuthor = function(author){
    //  $http.get("/fiqh?fiqh_author="+author.id).success(function(data, status){
    //    $scope.currentPosts = data;
    //  });
    //};

    //var a = 1;
    //$scope.getAuthorName = function(post){
    //  a +=1;
    //  console.log(a+' AuthorName',post);
    //  return "hello"
    //};



  }]);
