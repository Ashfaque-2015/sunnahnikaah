angular.module('app')
  .config(['$stateProvider', '$urlRouterProvider', 'AccessLevels', function($stateProvider, $urlRouterProvider, AccessLevels) {

    $stateProvider
      .state('base', {
        url: '',
        //abstract: true,
        //template: '<ui-view/>',
        templateUrl: 'templates/base.html',
        controller: 'BaseController',
        data: {
          access: AccessLevels.anon
        }
      })

      .state('base.anon', {
        url: '/',
        templateUrl: 'templates/home.html',
        controller: 'HomeController',
        data: {
          access: AccessLevels.anon
        }
      })

      .state('base.login', {
        url: '/login',
        templateUrl: 'templates/auth/login.html',
        controller: 'LoginController'
      })

      .state('base.forgotpassword', {
        url: '/forgotpassword/:codeerr',
        templateUrl: 'templates/auth/forgotpass.html',
        controller: 'ForgotPassController'
      })

      .state('base.passrecover', {
        url: '/passrecover/:recovercode',
        templateUrl: 'templates/auth/passrecover.html',
        controller: 'PassRecoverController'
      })

      .state('base.register', {
        url: '/register',
        templateUrl: 'templates/auth/register.html',
        controller: 'RegisterController'
      })

      .state('base.article', {
        url: '/articles',
        templateUrl: 'templates/article.html',
        controller: 'ArticleController'
      })
      .state('base.article.category', {
        url: '/category/:cat_id/:cat_slug',
        templateUrl: 'templates/article-by-category.html',
        controller: 'ArticleCategoryController'
      })
      .state('base.article.author', {
        url: '/author/:author_id/:author_slug',
        templateUrl: 'templates/article-by-author.html',
        controller: 'ArticleAuthorController'
      })
      .state('base.article.tag', {
        url: '/tag/:tag_id/:tag_title',
        templateUrl: 'templates/article-by-tag.html',
        controller: 'ArticleTagController'
      })
      .state('base.article.article_detail', {
        url: '/:post_id/:post_slug',
        templateUrl: 'templates/article-detail.html',
        controller: 'ArticleDetailController'
      })
      //--not using
      //.state('base.article.blog_detail', {
      //  url: '/blog/:blog_id',
      //  templateUrl: 'templates/blog-detail.html',
      //  controller: 'BlogDetailController'
      //})
      //--not using
      //.state('base.article.video_detail', {
      //  url: '/video/:video_id',
      //  templateUrl: 'templates/video-detail.html',
      //  controller: 'VideoDetailController'
      //})
      //video start
      .state('base.video', {
        url: '/video',
        templateUrl: 'templates/video.html',
        controller: 'VideoController'
      })
      .state('base.video.category', {
        url: '/category/:cat_id/:cat_slug',
        templateUrl: 'templates/video-by-category.html',
        controller: 'VideoCategoryController'
      })
      .state('base.video.author', {
        url: '/author/:author_id/:author_slug',
        templateUrl: 'templates/video-by-author.html',
        controller: 'VideoAuthorController'
      })
      .state('base.video.tag', {
        url: '/tag/:tag_id/:tag_title',
        templateUrl: 'templates/video-by-tag.html',
        controller: 'VideoTagController'
      })
      .state('base.video.video_detail', {
        url: '/:video_id/:video_slug',
        templateUrl: 'templates/video-detail.html',
        controller: 'VideoDetailController'
      })
      //video end
      //fiqh start
      .state('base.fiqh', {
        url: '/fiqh',
        templateUrl: 'templates/fiqh.html',
        controller: 'FiqhController'
      })
      .state('base.fiqh.category', {
        url: '/category/:cat_id/:cat_slug',
        templateUrl: 'templates/fiqh-by-category.html',
        controller: 'FiqhCategoryController'
      })
      .state('base.fiqh.author', {
        url: '/author/:author_id/:author_slug',
        templateUrl: 'templates/fiqh-by-author.html',
        controller: 'FiqhAuthorController'
      })
      .state('base.fiqh.tag', {
        url: '/tag/:tag_id/:tag_title',
        templateUrl: 'templates/fiqh-by-tag.html',
        controller: 'FiqhTagController'
      })
      .state('base.fiqh.fiqh_detail', {
        url: '/:fiqh_id/:fiqh_slug',
        templateUrl: 'templates/fiqh-detail.html',
        controller: 'FiqhDetailController'
      })
      //fiqh end

      //.state('base.user.view_other_profile', {
      //  url: '/view_other_profile/:other_user_id',
      //  templateUrl: 'templates/user/view_profile.html',
      //  controller: 'ViewProfileController'
      //
      //})
      .state('base.user', {
        url: '/user',
        //abstract: true,
        templateUrl: 'templates/user/myaccount.html',
        //controller: 'MyaccountController',
        controller: 'MyaccountDashboardController',
        data: {
          access: AccessLevels.user
        },
        onEnter: ['$rootScope', function($rootScope){
          $rootScope.hideSidebar = false;
        }]

      })

      .state('base.user.dashboard', {
        url: '/dashboard',
        //templateUrl: 'templates/user/myaccount-dashboard.html',
        //controller: 'MyaccountController',
        data: {
          access: AccessLevels.user
        },
        onEnter: ['$rootScope', function($rootScope){
          $rootScope.hideSidebar = false;
        }],
        views:{
          "sidebarMenu": {
            templateUrl: 'templates/sidebarmenu.html'
          },
          "mainContent": {
            templateUrl: 'templates/user/myaccount-dashboard.html',
            controller: 'MyaccountDashboardController'
          }
        }
      })

      .state('base.user.search', {
        url: '/search',
        //templateUrl: 'templates/user/search.html',
        //controller: 'SearchController',
        onEnter: ['$rootScope', function($rootScope){
          $rootScope.hideSidebar = true;
          console.log('$rootScope.hideSidebar',$rootScope.hideSidebar);
        }],
        views:{
          "sidebarMenu": {
            templateUrl: 'templates/sidebarmenu.html'
          },
          "mainContent": {
            templateUrl: 'templates/user/search.html',
            controller: 'SearchController'
          }
        }
      })

      .state('base.user.messages', {
        url: '/messages',
        //templateUrl: 'templates/user/messages.html',
        //controller: 'MessageController',
        onEnter: ['$rootScope', function($rootScope){
          $rootScope.hideSidebar = true;
        }],
        views:{
          "sidebarMenu": {
            templateUrl: 'templates/sidebarmenu.html'
          },
          "mainContent": {
            templateUrl: 'templates/user/messages.html',
            controller: 'MessageController'
          }
        }
      })

      .state('base.user.messages.detail', {
        url: '/d/:username',
        templateUrl: 'templates/user/messagesDetail.html',
        controller: 'MessageDetailController',
        onEnter: ['$rootScope', function($rootScope){
          $rootScope.hideSidebar = true;
        }]
      })

      .state('base.user.myprofile', {
        url: '/myprofile',
        //templateUrl: 'templates/user/myprofile.html',
        //controller: 'MyProfileController'
        onEnter: ['$rootScope', function($rootScope){
          $rootScope.hideSidebar = false;
        }],
        views:{
          "sidebarMenu": {
            templateUrl: 'templates/sidebarmenu.html'
          },
          "mainContent": {
            templateUrl: 'templates/user/myprofile.html',
            controller: 'MyProfileController'
          }
        }
      })

      .state('base.user.looking_for', {
        url: '/looking_for',
        //templateUrl: 'templates/user/lookingfor.html',
        //controller: 'LookingForController'
        onEnter: ['$rootScope', function($rootScope){
          $rootScope.hideSidebar = false;
        }],
        views:{
          "sidebarMenu": {
            templateUrl: 'templates/sidebarmenu.html'
          },
          "mainContent": {
            templateUrl: 'templates/user/lookingfor.html',
            controller: 'LookingForController'
          }
        }
      })

      .state('base.user.creed_questions', {
        url: '/creed_questions',
        //templateUrl: 'templates/user/creedquestions.html',
        //controller: 'CreedQuestionsController'
        onEnter: ['$rootScope', function($rootScope){
          $rootScope.hideSidebar = false;
        }],
        views:{
          "sidebarMenu": {
            templateUrl: 'templates/sidebarmenu.html'
          },
          "mainContent": {
            templateUrl: 'templates/user/creedquestions.html',
            controller: 'CreedQuestionsController'
          }
        }
      })

      .state('base.user.profile_image', {
        url: '/profile_image',
        //templateUrl: 'templates/user/profileimage.html',
        //controller: 'ProfileImageController'
        onEnter: ['$rootScope', function($rootScope){
          $rootScope.hideSidebar = false;
        }],
        views:{
          "sidebarMenu": {
            templateUrl: 'templates/sidebarmenu.html'
          },
          "mainContent": {
            templateUrl: 'templates/user/profileimage.html',
            controller: 'ProfileImageController'
          }
        }
      })

      .state('base.user.my_photos', {
        url: '/my_photos',
        //templateUrl: 'templates/user/myphotos.html',
        //controller: 'MyPhotosController'
        onEnter: ['$rootScope', function($rootScope){
          $rootScope.hideSidebar = false;
        }],
        views:{
          "sidebarMenu": {
            templateUrl: 'templates/sidebarmenu.html'
          },
          "mainContent": {
            templateUrl: 'templates/user/myphotos.html',
            controller: 'MyPhotosController'
          }
        }
      })

      .state('base.user.photo_request', {
        url: '/photo_request',
        //templateUrl: 'templates/user/photorequest.html',
        //controller: 'PhotoRequestController'
        onEnter: ['$rootScope', function($rootScope){
          $rootScope.hideSidebar = false;
        }],
        views:{
          "sidebarMenu": {
            templateUrl: 'templates/sidebarmenu.html'
          },
          "mainContent": {
            templateUrl: 'templates/user/photorequest.html',
            controller: 'PhotoRequestController'
          }
        }
      })

      .state('base.user.favorite_profiles', {
        url: '/favorite_profiles',
        //templateUrl: 'templates/user/favoriteprofiles.html',
        //controller: 'FavoriteProfilesController'
        onEnter: ['$rootScope', function($rootScope){
          $rootScope.hideSidebar = false;
        }],
        views:{
          "sidebarMenu": {
            templateUrl: 'templates/sidebarmenu.html'
          },
          "mainContent": {
            templateUrl: 'templates/user/favoriteprofiles.html',
            controller: 'FavoriteProfilesController'
          }
        }
      })
      .state('base.user.invitations', {
        url: '/invitations',
        //templateUrl: 'templates/user/invitations.html',
        //controller: 'InvitationsController'
        onEnter: ['$rootScope', function($rootScope){
          $rootScope.hideSidebar = false;
        }],
        views:{
          "sidebarMenu": {
            templateUrl: 'templates/sidebarmenu.html'
          },
          "mainContent": {
            templateUrl: 'templates/user/invitations.html',
            controller: 'InvitationsController'
          }
        }
      })
      .state('base.user.settings', {
        url: '/settings',
        //templateUrl: 'templates/user/settings.html',
        //controller: 'SettingsController'
        onEnter: ['$rootScope', function($rootScope){
          $rootScope.hideSidebar = false;
        }],
        views:{
          "sidebarMenu": {
            templateUrl: 'templates/sidebarmenu.html'
          },
          "mainContent": {
            templateUrl: 'templates/user/settings.html',
            controller: 'SettingsController'
          }
        }
      })
      .state('base.user.view_other_profile', {
        url: '/view_other_profile/:other_user_id',
        //templateUrl: 'templates/user/view_profile.html',
        //controller: 'ViewProfileController'
        onEnter: ['$rootScope', function($rootScope){
          $rootScope.hideSidebar = false;
        }],
        views:{
          "sidebarMenu": {
            templateUrl: 'templates/sidebarmenu.html'
          },
          "mainContent": {
            templateUrl: 'templates/user/view_profile.html',
            controller: 'ViewProfileController'
          }
        }
      })
      .state('base.admin',{
        url: '/admin',
        templateUrl: 'templates/admin/dashboard.html',
        controller: 'AdminDashboardController',
        data: {
          access: AccessLevels.admin
        }
      })
      .state('base.admin.posts', {
        url: '/posts',
        templateUrl: 'templates/admin/blog/posts.html',
        controller: 'AdminPostsController'
      })
      .state('base.admin.new_post', {
        url: '/new-post',
        templateUrl: 'templates/admin/blog/new-post.html',
        controller: 'AdminNewPostController'
      })
      .state('base.admin.edit_post', {
        url: '/edit-post/:postid',
        templateUrl: 'templates/admin/blog/new-post.html',
        controller: 'AdminEditPostController'
      })
      .state('base.admin.blog_categories', {
        url: '/post-categories',
        templateUrl: 'templates/admin/blog/blog-categories.html',
        controller: 'AdminBlogCategoriesController'
      })
      .state('base.admin.new_blog_category', {
        url: '/new-blog-category',
        templateUrl: 'templates/admin/blog/new-category.html',
        controller: 'AdminNewBlogCategoryController'
      })
      .state('base.admin.edit_blog_category', {
        url: '/edit-blog-category/:catid',
        templateUrl: 'templates/admin/blog/new-category.html',
        controller: 'AdminEditBlogCategoryController'
      })
      .state('base.admin.videos', {
        url: '/videos',
        templateUrl: 'templates/admin/video/videos.html',
        controller: 'AdminVideosController'
      })
      .state('base.admin.new_video', {
        url: '/new-video',
        templateUrl: 'templates/admin/video/new-video.html',
        controller: 'AdminNewVideoController'
      })
      .state('base.admin.edit_video', {
        url: '/edit-video/:videoid',
        templateUrl: 'templates/admin/video/new-video.html',
        controller: 'AdminEditVideoController'
      })
      .state('base.admin.video_categories', {
        url: '/video-categories',
        templateUrl: 'templates/admin/video/video-categories.html',
        controller: 'AdminVideoCategoryController'
      })
      .state('base.admin.new_video_category', {
        url: '/new-video-category',
        templateUrl: 'templates/admin/video/new-video-category.html',
        controller: 'AdminNewVideoCategoryController'
      })
      .state('base.admin.edit_video_category', {
        url: '/edit-video-category/:videocatid',
        templateUrl: 'templates/admin/video/new-video-category.html',
        controller: 'AdminEditVideoCategoryController'
      })
      .state('base.admin.fiqh', {
        url: '/fiqh',
        templateUrl: 'templates/admin/Fiqh/fiqh.html',
        controller: 'AdminFiqhController'
      })
      .state('base.admin.new_fiqh', {
        url: '/new-fiqh',
        templateUrl: 'templates/admin/Fiqh/new-fiqh.html',
        controller: 'AdminNewFiqhController'
      })
      .state('base.admin.fiqh_categories', {
        url: '/fiqh-categories',
        templateUrl: 'templates/admin/Fiqh/fiqh-categories.html',
        controller: 'AdminFiqhCategoriesController'
      })
      .state('base.admin.edit_fiqh', {
        url: '/edit-fiqh/:fiqhid',
        templateUrl: 'templates/admin/Fiqh/new-fiqh.html',
        controller: 'AdminEditFiqhController'
      })
      .state('base.admin.new_fiqh_category', {
        url: '/new-fiqh-category',
        templateUrl: 'templates/admin/Fiqh/new-fiqh-category.html',
        controller: 'AdminNewFiqhCategoryController'
      })
      .state('base.admin.edit_fiqh_category', {
        url: '/edit-fiqh-category/:catid',
        templateUrl: 'templates/admin/Fiqh/new-fiqh-category.html',
        controller: 'AdminEditFiqhCategoryController'
      })
      .state('base.admin.tags', {
        url: '/tags',
        templateUrl: 'templates/admin/tag/tags.html',
        controller: 'AdminTagsController'
      })
      .state('base.admin.new_tag', {
        url: '/new-tag',
        templateUrl: 'templates/admin/tag/new-tag.html',
        controller: 'AdminNewTagController'
      })
      .state('base.admin.edit_tag', {
        url: '/edit-tag/:tagid',
        templateUrl: 'templates/admin/tag/new-tag.html',
        controller: 'AdminEditTagController'
      })
      .state('base.admin.authors', {
        url: '/authors',
        templateUrl: 'templates/admin/author/authors.html',
        controller: 'AdminAuthorsController'
      })
      .state('base.admin.new_author', {
        url: '/new-author',
        templateUrl: 'templates/admin/author/new-author.html',
        controller: 'AdminNewAuthorController'
      })
      .state('base.admin.edit_author', {
        url: '/edit-author/:authorid',
        templateUrl: 'templates/admin/author/new-author.html',
        controller: 'AdminEditAuthorController'
      })
      .state('base.admin.message_thread', {
        url: '/message-thread',
        templateUrl: 'templates/admin/blog/message-thread.html',
        controller: 'AdminMessageThreadController'
      })
      .state('base.admin.members', {
        url: '/members',
        templateUrl: 'templates/admin/member/members.html',
        controller: 'AdminMembersController'
      })
      .state('base.admin.new_members', {
        url: '/new-member',
        templateUrl: 'templates/admin/member/new-member.html',
        controller: 'AdminNewMemberController'
      })
      .state('base.admin.demo', {
        url: '/demo',
        templateUrl: 'templates/admin/member/demo.html',
        controller: 'AdminDemoController'
      })
    //.state('base.admin.fiqh_categories', {
    //  url: '/fiqh-categories',
    //  templateUrl: 'templates/admin/Fiqh/fiqh-categories.html',
    //  controller: 'AdminFiqhCategoriesController'
    //})
//      .state('base.admin.fiqh', {
//        url: '/fiqh',
//        templateUrl: 'templates/admin/Fiqh/fiqh.html',
//        controller: 'AdminFiqhController'
//      })
//
//      .state('base.admin.new_fiqh', {
//        url: '/new-fiqh',
//        templateUrl: 'templates/admin/Fiqh/new-fiqh.html',
//        controller: 'AdminNewFiqhController'
//      })
//
//      .state('base.admin.fiqh_categories', {
//        url: '/fiqh-categories',
//        templateUrl: 'templates/admin/Fiqh/fiqh-categories.html',
//        controller: 'AdminFiqhCategoriesController'
//      });

    //if(AccessLevels.admin ==2)
    //  $urlRouterProvider.otherwise('/admin');
    //else
    $urlRouterProvider.otherwise('');


  }]);
