/**
 * grunt/pipeline.js
 *
 * The order in which your css, javascript, and template files should be
 * compiled and linked from your views and static HTML files.
 *
 * (Note that you can take advantage of Grunt-style wildcard/glob/splat expressions
 * for matching multiple files.)
 */



// CSS files to inject in order
//
// (if you're using LESS with the built-in default config, you'll want
//  to change `assets/styles/importer.less` instead.)
var cssFilesToInject = [
  'styles/**/*.css'
];


// Client-side javascript files to inject in order
// (uses Grunt-style wildcard/glob/splat expressions)
var jsFilesToInject = [
  
  // Load sails.io before everything else



    <script src="/js/dependencies/angular.js"></script>

    <script src="/js/dependencies/angular-ui-router.min.js"></script>
    <script src="/js/dependencies/jquery.min.js"></script>
 
    <script src="/bower_components/angular-translate/angular-translate.js"></script>

 
    <script src="/js/dependencies/bootstrap.min.js"></script>
 
    <script src="/vendors/angular-ui-grid/angular-touch.js"></script>
    <script src="/vendors/angular-ui-grid/angular-animate.js"></script>
    <script src="/vendors/angular-ui-grid/ui-grid.js"></script>

    <script src="/js/dependencies/wow.min.js"></script>
    <script src="/js/app.js"></script>
    <script src="/js/controllers/ChatController.js"></script>
    <script src="/js/controllers/HomeController.js"></script>
    <script src="/js/controllers/LibraryController.js"></script>
    <script src="/js/controllers/LibraryDetailController.js"></script>
    <script src="/js/controllers/BlogDetailController.js"></script>
    <script src="/js/controllers/VideoDetailController.js"></script>


    <script src="/js/controllers/MessageBoxController.js"></script>
    <script src="/js/controllers/articlesController.js"></script>
    <script src="/js/controllers/creedquestions.js"></script>
    <script src="/js/controllers/favoriteprofilesController.js"></script>
    <script src="/js/controllers/invitationsController.js"></script>
    <script src="/js/controllers/lecturesController.js"></script>
    <script src="/js/controllers/loginController.js"></script>
    <script src="/js/controllers/lookingforController.js"></script>
    <script src="/js/controllers/my_profileController.js"></script>
    <script src="/js/controllers/myaccountController.js"></script>
    <script src="/js/controllers/myphotosController.js"></script>
    <script src="/js/controllers/photorequestController.js"></script>
    <script src="/js/controllers/myprofileController.js"></script>
    <script src="/js/controllers/navController.js"></script>
    <script src="/js/controllers/profileimageController.js"></script>
    <script src="/js/controllers/registerController.js"></script>
    <script src="/js/controllers/searchController.js"></script>
    <script src="/js/controllers/searchresultController.js"></script>
    <script src="/js/controllers/settingsController.js"></script>
    <script src="/js/controllers/view_profileController.js"></script>
    <script src="/js/controllers/admin/AdminDashboardController.js"></script>
    <script src="/js/controllers/admin/AdminPostsController.js"></script>
    <script src="/js/controllers/admin/AdminNewPostController.js"></script>
    <script src="/js/controllers/admin/AdminPostCategoriesController.js"></script>
    <script src="/js/controllers/admin/AdminNewCategoryController.js"></script>
    <script src="/js/controllers/admin/AdminVideosController.js"></script>
    <script src="/js/controllers/admin/AdminNewVideoController.js"></script>
    <script src="/js/controllers/admin/AdminMembersController.js"></script>
    <script src="/js/jquery-1.11.2.min.js"></script>
    <script src="/js/routes.js"></script>
    <script src="/js/services/accessLevels.js"></script>
    <script src="/js/services/auth.js"></script>
    <script src="/js/services/currentUser.js"></script>
    <script src="/js/services/localStorage.js"></script>
    <script src="/js/services/options.js"></script>


    <script src="/js/localization/en_EN.js"></script>
    <script src="/js/localization/bn_BN.js"></script>

    <script src="/vendors/ng-youtube/youtube.js"></script>
    <script src="/vendors/xmpp-ejabberd-strophe/strophe.min.js"></script>
    <script src="/vendors/xmpp-ejabberd-strophe/gab.js"></script>


    <script src="/bower_components/angular-bootstrap/ui-bootstrap.min.js"></script>
    <script src="/bower_components/angular-bootstrap/ui-bootstrap-tpls.min.js"></script>

    <script src="/bower_components/ng-file-upload/angular-file-upload-shim.min.js"></script>
    <script src="/bower_components/ng-file-upload/angular-file-upload.min.js"></script>
    <script src="/bower_components/moment/min/moment.min.js"></script>
    <script src="js/dependencies/wow.min.js"></script>





  // Dependencies like jQuery, or Angular are brought in here
  // i commented this 
  // 'js/dependencies/**/*.js',

  // All of the rest of your client-side js files
  // will be injected here in no particular order.
 //
 // uncomment this to allow auto loading from js directory
 //   'js/**/*.js'
];


// Client-side HTML templates are injected using the sources below
// The ordering of these templates shouldn't matter.
// (uses Grunt-style wildcard/glob/splat expressions)
//
// By default, Sails uses JST templates and precompiles them into
// functions for you.  If you want to use jade, handlebars, dust, etc.,
// with the linker, no problem-- you'll just want to make sure the precompiled
// templates get spit out to the same file.  Be sure and check out `tasks/README.md`
// for information on customizing and installing new tasks.
var templateFilesToInject = [
  'templates/**/*.html'
];



// Prefix relative paths to source files so they point to the proper locations
// (i.e. where the other Grunt tasks spit them out, or in some cases, where
// they reside in the first place)
module.exports.cssFilesToInject = cssFilesToInject.map(function(path) {
  return '.tmp/public/' + path;
});
module.exports.jsFilesToInject = jsFilesToInject.map(function(path) {
  return '.tmp/public/' + path;
});
module.exports.templateFilesToInject = templateFilesToInject.map(function(path) {
  return 'assets/' + path;
});
