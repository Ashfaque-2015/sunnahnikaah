/**
 * grunt/pipeline.js
 *
 * The order in which your css, javascript, and template files should be
 * compiled and linked from your views and static HTML files.
 *
 * (Note that you can take advantage of Grunt-style wildcard/glob/splat expressions
 * for matching multiple files.)
 */



// CSS files to inject in order
//
// (if you're using LESS with the built-in default config, you'll want
//  to change `assets/styles/importer.less` instead.)
var cssFilesToInject = [
  'styles/**/*.css'
];


// Client-side javascript files to inject in order
// (uses Grunt-style wildcard/glob/splat expressions)
var jsFilesToInject = [

// Load sails.io before everything else

// Dependencies like jQuery, or Angular are brought in here
// i commented this
// 'js/dependencies/**/*.js',

  //'/js/dependencies/sails.io.js',
  //'/bower_components/angular-ui-router/release/angular-ui-router.min.js',
  //'/bower_components/angular-sails/dist/angular-sails.min.js',
  //
  //'/bower_components/angular-ui-grid/ui-grid.min.js',
  //'/vendors/wowjs/wow.min.js',
  //
  //'/vendors/ng-youtube/youtube.js',
  //'/vendors/xmpp-ejabberd-strophe/strophe.min.js',
  //'/vendors/xmpp-ejabberd-strophe/strophe.register.js',
  //'/vendors/xmpp-ejabberd-strophe/strophe.roster.js',
  //'/vendors/xmpp-ejabberd-strophe/strophe.rsm.js',
  //'/vendors/xmpp-ejabberd-strophe/strophe.archive.js',
  //
  //
  //'/vendors/angular-tags/angular-tags-0.3.1.min.js',
  //'/vendors/angular-tags/angular-tags-0.3.1-tpls.min.js',
  //'/vendors/angular-tags/ui-bootstrap-tpls.js',
  //'/bower_components/angular-bootstrap/ui-bootstrap.min.js',
  //'/bower_components/angular-bootstrap/ui-bootstrap-tpls.min.js',
  //
  //'/bower_components/angular-loading-bar/build/loading-bar.js',
  //'/bower_components/ng-file-upload/angular-file-upload-shim.min.js',
  //'/bower_components/ng-file-upload/angular-file-upload.min.js',
  //'/bower_components/moment/min/moment.min.js',
  //'/bower_components/angular-audio/app/angular.audio.js',
  //'/bower_components/ngDialog/js/ngDialog.min.js',
  //'/bower_components/angular-img-fallback/angular.dcb-img-fallback.min.js',
  //'/bower_components/angular-socialshare/dist/angular-socialshare.min.js',
  //'/bower_components/angularUtils-pagination/dirPagination.js',
  //'/bower_components/angular-translate/angular-translate.js',

// All of the rest of your client-side js files
// will be injected here in no particular order.
//
// uncomment this to allow auto loading from js directory
//  '/js/alljs.js',

   'js/**/*.js'
];


// Client-side HTML templates are injected using the sources below
// The ordering of these templates shouldn't matter.
// (uses Grunt-style wildcard/glob/splat expressions)
//
// By default, Sails uses JST templates and precompiles them into
// functions for you.  If you want to use jade, handlebars, dust, etc.,
// with the linker, no problem-- you'll just want to make sure the precompiled
// templates get spit out to the same file.  Be sure and check out `tasks/README.md`
// for information on customizing and installing new tasks.
var templateFilesToInject = [
  'templates/**/*.html'
];



// Prefix relative paths to source files so they point to the proper locations
// (i.e. where the other Grunt tasks spit them out, or in some cases, where
// they reside in the first place)
module.exports.cssFilesToInject = cssFilesToInject.map(function(path) {
  return '.tmp/public/' + path;
});
module.exports.jsFilesToInject = jsFilesToInject.map(function(path) {
  return '.tmp/public/' + path;
});
module.exports.templateFilesToInject = templateFilesToInject.map(function(path) {
  return 'assets/' + path;
});
