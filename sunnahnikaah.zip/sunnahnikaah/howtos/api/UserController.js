/**
 * UserController
 *
 * @description :: Server-side logic for managing users
 * @help        :: See http://links.sailsjs.org/docs/controllers
 */

var fs = require('fs')
  , path = require('path');

var nodemailer = require('nodemailer');

module.exports = {
  // Doing a DELETE /user/:parentid/message/:id will not delete the message itself
  // We do that here.
	remove: function(req, res) {
    var relation = req.options.alias;
    switch (relation) {
      case 'messages':
        destroyMessage(req, res);
    }
  },

  create: function(req, res) {
    res.json(301, 'To create a user go to /auth/register');
  },

  search: function(req, res, next) {

    //this code temporarily placed and need to be placed at config/bootstrap.js folder
    var postsSource = path.join(process.cwd(), 'uploads')
      , postsDest = path.join(process.cwd(), '.tmp/public/uploads');

    fs.symlink(postsSource, postsDest, function(err) {
      //cb(err);
    });


    var searchParams = {};

    var today = new Date();
    var end_time = new Date((today.getFullYear() - 12), 0, 0, 0, 0, 0, 0).getTime();
    var start_date = new Date(1970, 0, 1, 6, 0, 0, 0);
    var start_time = new Date(1970, 0, 1, 6, 0, 0, 0).getTime();

    var end_time = new Date((today.getFullYear() - 12), 0, 0, 0, 0, 0, 0).getTime();

    //var start_time =  req.query[key]['start_date'];
    //var end_time = req.query[key]['end_date'];



    searchParams["dob_timestamp"]={};
    searchParams["dob_timestamp"][">"]=start_time;
    searchParams["dob_timestamp"]["<"]=end_time;

    Object.keys(req.query).forEach(function (key) {
      //
      //if(key=="max_age" && req.query[key]!==""){
      //  var max_year = today.getFullYear()- req.query[key];
      //  start_time = new Date(max_year, 0, 0, 0, 0, 0, 0).getTime();
      //  searchParams["dob_timestamp"][">"]=start_time;
      //}
      //else{
      //  start_time =  req.query[key]['start_date'];
      //  searchParams["dob_timestamp"][">"]=start_time;
      //}
      //
      //if(key=="min_age" && req.query[key]!==""){
      //  var min_year = today.getFullYear()- req.query[key];
      //  end_time = new Date(min_year, 0, 0, 0, 0, 0, 0).getTime();
      //  searchParams["dob_timestamp"]["<"]=end_time;
      //}
      //else{
      //  end_time = req.query[key]['end_date'];
      //  searchParams["dob_timestamp"]["<"]=end_time;
      //}

      if(key=="gender" && req.query[key]!==""){
        searchParams["gender"]=req.query[key];
        User.find().where({ "gender": req.query[key]})
      }
      if(key=="country" && req.query[key]!==""){
        searchParams["country"]=req.query[key];
        User.find().where({ "country": req.query[key]})
      }
      if(key=="myprofile_ethnicity" && req.query[key]!==""){
        searchParams["myprofile_ethnicity"]=req.query[key];
        User.find().where({ "country": req.query[key]})
      }
      if(key=="profession" && req.query[key]!==""){
        searchParams["myprofile_profession"]=req.query[key];
      }
      if(key=="education" && req.query[key]!==""){
        searchParams["myprofile_education"]=req.query[key];
      }
      if(key=="marital_status" && req.query[key]!==""){
        searchParams["myprofile_marital_status"]=req.query[key];
      }
      if(key=="salah" && req.query[key]!==""){
        searchParams["myprofile_salah"]=req.query[key];
      }
      if(key=="religiousness" && req.query[key]!==""){
        searchParams["myprofile_religious_strictness"]=req.query[key];
      }
      if(key=="build" && req.query[key]!==""){
        searchParams["myprofile_build"]=req.query[key];
      }
    });

    //User.find()
    //  .where({key : req.query[key]})
    //  .where()
    //  .limit(100)
    //  .exec(function(err, users){
    //    if (err) return next(err);
    //    res.json(data);
    //  });

    //User.find()
    //  .where({ id: { '>': 100 }})
    //  .where({ age: 21 })
    //  .limit(100)
    //  .sort('name')
    //  .exec(function(err, users) {
    //    // Do stuff here
    //  });

    User.find(searchParams)
      .where({ id: { not: req.query["currentUserId"]}})//,'>=': req.query['start_date']}})
      .exec(function(err, data) {
        if (err) return next(err);
        res.json(data);
      });

  },
  rosterlist: function(req, res) {

    //res.json(301, 'To create a user go to /auth/register');
  }

};
