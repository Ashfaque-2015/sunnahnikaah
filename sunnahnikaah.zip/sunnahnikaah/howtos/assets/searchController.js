angular.module('app').controller('SearchController', function ($scope, LocalService, $http, CurrentUser) {
  $scope.search = {};
  $scope.results = {};
  $scope.demoAvatar = "images/demo-profile-pic.png";
  //var last_search = LocalService.get('last_search');
  //$scope.results = last_search;
  $scope.results = [];
  //$scope.search.salah = 0;

  //Chat.connection.addHandler($scope.on_message2,null, "message", "chat");
  //
  //$scope.on_message2 = function(message){
  //  console.log("message at msg contl",message);
  //  return true;
  //};

  $scope.abc = CurrentUser.user().dob_timestamp;


  $scope.searchProfiles = function () {

    $scope.search = {};

    //console.log( $scope.search);
    //return;

    //$scope.search.forEach(function(){
    //  console.log(this);
    //});

    //Object.keys($scope.search).forEach(function (key) {
    //  console.log(key + ' = ' + $scope.search[key]);
    //});
    var today = new Date();
    var start_date = new Date('1970', 0, 1, 0, 0, 0, 0);
    var end_date = new Date((today.getFullYear() - 10), 0, 0, 0, 0, 0, 0);

    //start_date = moment(start_date).format('YYYY-MM-DD');
    //end_date = moment(end_date).format('YYYY-MM-DD');



    //console.log($scope.search.max_age);
    //console.log($scope.search.min_age);


    if($scope.search.max_age && $scope.search.max_age !==""){

      //$scope.search.start_date = start_date; //max_age


      var max_year = today.getFullYear()- $scope.search.max_age;
      $scope.search.start_date = moment(new Date(max_year, 0, 0, 0, 0, 0, 0)).format('YYYY-MM-DD');
      //console.log('start date-------');
     // console.log($scope.search.start_date);
    }



    if($scope.search.min_age && $scope.search.min_age !==""){

      //$scope.search.end_date = end_date; //min_age
      var min_year = today.getFullYear() - $scope.search.min_age;
      $scope.search.end_date =  moment( new Date(min_year, 0, 0, 0, 0, 0, 0)).format('YYYY-MM-DD');
      //console.log('end date------');
      //console.log($scope.search.end_date);
    }

    //console.log(start_date);
    //console.log($scope.search.start_date);
    //console.log(end_date);
    //console.log($scope.search.end_date);

    //sending current user id with search params
    $scope.search.currentUserId = CurrentUser.user().id;


    //---Arf---Start-------
   if( CurrentUser.user().gender =='male'){

     $scope.search.gender = 'female';
     $scope.search.start_date =null;
     $scope.search.end_date  = null;

     if($scope.search.min_age == null){
         $scope.search.start_date =  CurrentUser.user().dob_timestamp - (86400000 * 365 * 10);
       //consol.log('start', $scope.search.start_date);
     }

     if($scope.search.max_age ==null){
       $scope.search.end_date  =  CurrentUser.user().dob_timestamp + (86400000 * 365 * 2);
     }



   }

    if( CurrentUser.user().gender =='female'){

      $scope.search.gender = 'male';

      if($scope.search.min_age == null){
        $scope.search.start_date =  CurrentUser.user().dob_timestamp + (86400000 * 365 * 10);

      }

      if($scope.search.max_age ==null){
        $scope.search.end_date  =  CurrentUser.user().dob_timestamp - (86400000 * 365 * 2);

      }
    }

    //---Arf--End-------





    var qryString = $.param($scope.search);
    console.log( qryString );


    //$http.get('/user/search?salah='+$scope.search.salah+'&built='+$scope.search.built).
    $http.post('/user/search?'+qryString).
      success(function (data, status, headers, config) {
        console.log("successfull");
        console.log(data);
        $scope.results = data;

        $('#ma_search_menu').height($(document).height() - $("#main_nav").height() );
      }).
      error(function (data, status, headers, config) {
        // called asynchronously if an error occurs
        // or server returns response with an error status.
      });
  };

  angular.element(document).ready(function() {
    //setting search bar height
    $('#ma_search_menu').height($(window).height() - $("#main_nav").height() - 50);
    $('#search-result-cont').height($(window).height() - $("#main_nav").height() - 50);
    $('#ma_search_container').height($(window).height() - $("#main_nav").height() - $("#ma_fixed_menu").height() - 50 + 13);

    $( window ).resize(function() {
      $('#ma_search_menu').height($(document).height() - $("#main_nav").height() );
    });

  });
});
